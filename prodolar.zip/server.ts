import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { Task, CalendarEvent, AgentStep, SystemContext, SubTask, TimeBlock } from "./src/types";
import { requireAuth, AuthRequest } from "./src/middleware/auth.ts";
import * as dbOps from "./src/db/operations.ts";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// --- POSTGRES DATABASE CRUD ENDPOINTS ---
app.get("/api/db/tasks", requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user?.dbId;
    if (!userId) return res.status(401).json({ error: "User not synchronized to DB" });
    const tasks = await dbOps.getTasks(userId);
    res.json(tasks);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/db/tasks", requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user?.dbId;
    if (!userId) return res.status(401).json({ error: "User not synchronized to DB" });
    await dbOps.saveTask(userId, req.body);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete("/api/db/tasks/:id", requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user?.dbId;
    if (!userId) return res.status(401).json({ error: "User not synchronized to DB" });
    await dbOps.deleteTask(userId, req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/db/events", requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user?.dbId;
    if (!userId) return res.status(401).json({ error: "User not synchronized to DB" });
    const events = await dbOps.getCalendarEvents(userId);
    res.json(events);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/db/events", requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user?.dbId;
    if (!userId) return res.status(401).json({ error: "User not synchronized to DB" });
    await dbOps.saveCalendarEvent(userId, req.body);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete("/api/db/events/:id", requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user?.dbId;
    if (!userId) return res.status(401).json({ error: "User not synchronized to DB" });
    await dbOps.deleteCalendarEvent(userId, req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/db/coach-logs", requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user?.dbId;
    if (!userId) return res.status(401).json({ error: "User not synchronized to DB" });
    const logs = await dbOps.getCoachLogs(userId);
    res.json(logs);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/db/coach-logs", requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user?.dbId;
    if (!userId) return res.status(401).json({ error: "User not synchronized to DB" });
    await dbOps.saveCoachLog(userId, req.body);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/db/focus-sessions", requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user?.dbId;
    if (!userId) return res.status(401).json({ error: "User not synchronized to DB" });
    const sessions = await dbOps.getFocusSessions(userId);
    res.json(sessions);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/db/focus-sessions", requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user?.dbId;
    if (!userId) return res.status(401).json({ error: "User not synchronized to DB" });
    await dbOps.saveFocusSession(userId, req.body);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// AI Email parsing endpoint
app.post("/api/agent/analyze-email", async (req, res) => {
  try {
    const { subject, body, sender } = req.body;
    const ai = getGeminiClient();
    if (!ai) {
      return res.json({
        title: subject || "Action Item from Email",
        description: `From: ${sender || "Unknown"}\n\n${body || ""}`.substring(0, 500),
        estimatedHours: 1,
        category: "Emails",
        priority: "medium",
        energy: "low",
        subtasks: [
          { title: "Review email content", status: "pending", estimatedMinutes: 15 },
          { title: "Draft response", status: "pending", estimatedMinutes: 30 }
        ]
      });
    }

    const prompt = `
      You are an elite "AI Chief of Staff" parsing emails into action items.
      Analyze this email:
      From: ${sender || "Unknown"}
      Subject: ${subject || "No Subject"}
      Body: ${body || "No Body"}

      Create a structured task in JSON based on this email. Be realistic with estimatedHours and priority.
      Respond in JSON matching this exact schema:
      {
        "title": "Clear actionable task title",
        "description": "Short summary of the task and what needs to be done based on the email",
        "estimatedHours": number,
        "category": "Deep Work" | "Meetings" | "Emails" | "Study" | "Routine" | "Personal",
        "priority": "high" | "medium" | "low",
        "energy": "high" | "medium" | "low",
        "subtasks": [
          { "title": "Subtask title", "estimatedMinutes": number }
        ]
      }
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const result = JSON.parse(response.text || "{}");
    res.json(result);
  } catch (err: any) {
    console.error("Failed to analyze email with Gemini:", err);
    res.status(500).json({ error: err.message });
  }
});



// Helper to get Gemini client
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    // If key is not set, we'll try to use a fallback or return a helpful message
    console.warn("WARNING: GEMINI_API_KEY is not configured.");
    return null;
  }
  return new GoogleGenAI({ apiKey });
}

// Multi-agent plan endpoint
app.post("/api/agent/plan", async (req, res) => {
  try {
    const { goalText, currentTasks = [], currentEvents = [], context } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Graceful fallback for demo purposes when key is not configured yet
      return res.json(createMockAgenticPlan(goalText, currentTasks, currentEvents, context));
    }

    // Prepare steps log to return
    const steps: AgentStep[] = [];
    const timestamp = new Date().toISOString();

    // 1. Planner Agent
    steps.push({
      agentName: "Planner",
      status: "running",
      thought: `Analyzing goal: "${goalText}". Identifying major milestones, potential deadline constraints, and complexity.`,
      timestamp: new Date().toISOString()
    });

    const plannerPrompt = `
      You are the "Planner Agent" in a multi-agent system.
      The user wants to accomplish: "${goalText}".
      Current calendar events: ${JSON.stringify(currentEvents)}
      Current tasks: ${JSON.stringify(currentTasks)}
      System Context (Battery, Internet, Location, Weather): ${JSON.stringify(context)}

      Analyze the request and provide a high-level plan, overall complexity (1-10), total estimated effort in hours, and strategic approach.
      Respond in JSON matching this schema:
      {
        "highLevelPlan": "string describing the strategy",
        "complexity": 5,
        "totalEstimatedHours": 8,
        "risks": ["risk 1", "risk 2"]
      }
    `;

    const plannerResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: plannerPrompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const plannerResult = JSON.parse(plannerResponse.text || "{}");
    steps[0].status = "completed";
    steps[0].output = plannerResult.highLevelPlan;

    // 2. Task Decomposer Agent
    steps.push({
      agentName: "Decomposer",
      status: "running",
      thought: `Breaking down high-level milestones into granular subtasks. Estimating effort and categorizing.`,
      timestamp: new Date().toISOString()
    });

    const decomposerPrompt = `
      You are the "Task Decomposer Agent".
      Break down the goal "${goalText}" and high-level plan "${plannerResult.highLevelPlan}" into 1 to 3 distinct Tasks.
      For each Task, also break it down into 2 to 4 granular SubTasks.
      
      Categories allowed: "Deep Work", "Meetings", "Emails", "Study", "Routine", "Personal"
      
      Respond in JSON matching this exact schema structure:
      {
        "tasks": [
          {
            "title": "Task title",
            "description": "Task description",
            "estimatedHours": 3,
            "category": "Deep Work",
            "energy": "high" | "medium" | "low",
            "subtasks": [
              {
                "title": "Subtask title",
                "estimatedMinutes": 45
              }
            ]
          }
        ]
      }
    `;

    const decomposerResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: decomposerPrompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const decomposerResult = JSON.parse(decomposerResponse.text || "{}");
    steps[1].status = "completed";
    steps[1].output = `Extracted ${decomposerResult.tasks?.length || 0} main tasks and subtasks.`;

    // 3. Priority & Risk Agent (AI Deadline Predictor)
    steps.push({
      agentName: "Priority",
      status: "running",
      thought: `Scoring task priorities and executing the AI Deadline Predictor algorithms to estimate completion success probability.`,
      timestamp: new Date().toISOString()
    });

    // Calculate basic hour availability
    const totalCurrentHours = currentTasks.reduce((sum: number, t: any) => sum + (t.estimatedHours || 0), 0);
    const totalNewHours = (decomposerResult.tasks || []).reduce((sum: number, t: any) => sum + (t.estimatedHours || 0), 0);
    const totalNeeded = totalCurrentHours + totalNewHours;

    const priorityPrompt = `
      You are the "Priority Agent" and "AI Deadline Predictor".
      Review the list of proposed tasks: ${JSON.stringify(decomposerResult.tasks)}
      Along with existing tasks: ${JSON.stringify(currentTasks)}
      We have total workloads of estimated ${totalNeeded} hours.
      Current context is: ${JSON.stringify(context)}

      Determine:
      1. Priority ("high" | "medium" | "low") for each proposed task.
      2. The "successProbability" (0 to 100) that the user can complete all these commitments on time before their deadlines.
         - Consider that a high total hours count, bad weather, or many calendar events reduces success probability.
         - If total needed hours is > 15 in the next few days, probability should be lower (< 65%).
      
      Respond in JSON matching this schema:
      {
        "priorities": [
          {
            "title": "Task title exactly matching proposed list",
            "priority": "high" | "medium" | "low"
          }
        ],
        "successProbability": 78,
        "riskAnalysis": "Short summary of deadline risks"
      }
    `;

    const priorityResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: priorityPrompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const priorityResult = JSON.parse(priorityResponse.text || "{}");
    steps[2].status = "completed";
    steps[2].output = `Success Probability: ${priorityResult.successProbability}%. Risk: ${priorityResult.riskAnalysis}`;

    // 4. Calendar & Scheduling Agent
    steps.push({
      agentName: "Calendar",
      status: "running",
      thought: `Reserving time blocks, checking conflicts, and scheduling deep work, meeting, or email sessions matching energy levels.`,
      timestamp: new Date().toISOString()
    });

    const calendarPrompt = `
      You are the "Calendar Agent".
      We need to schedule time blocks for the new tasks: ${JSON.stringify(decomposerResult.tasks)}.
      Existing events: ${JSON.stringify(currentEvents)}.
      Current time is ${new Date().toISOString()}.
      
      Schedule each task into a specific time block (2 to 4 hours in the next 3 days).
      Make sure to match the task "energy" with the schedule:
      - High energy tasks -> Morning deep work slots (e.g. 09:00 - 12:00)
      - Medium energy tasks -> Afternoon slots (e.g. 14:00 - 17:00)
      - Low energy tasks -> Evening/Night slots (e.g. 19:00 - 21:00)
      Avoid any overlap with existing calendar events.
      
      Respond in JSON matching this schema:
      {
        "schedule": [
          {
            "title": "Task title exactly matching",
            "start": "ISO DateTime string (e.g., 2026-06-30T09:00:00-07:00)",
            "end": "ISO DateTime string"
          }
        ]
      }
    `;

    const calendarResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: calendarPrompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const calendarResult = JSON.parse(calendarResponse.text || "{}");
    steps[3].status = "completed";
    steps[3].output = `Reserved ${calendarResult.schedule?.length || 0} time blocks matching energy profiles.`;

    // 5. Execution Agent / Negotiator Agent
    steps.push({
      agentName: "Execution",
      status: "running",
      thought: `Running negotiator routine. Drafting formal extension proposals if probability of success is low.`,
      timestamp: new Date().toISOString()
    });

    let extensionDraft = "";
    if (priorityResult.successProbability < 70) {
      const negotiatorPrompt = `
        You are the "AI Negotiator Agent".
        The user has a critically low success probability of ${priorityResult.successProbability}% due to overload.
        Draft an elegant, professional, human-sounding email/Slack draft requesting a reasonable extension or reschedule.
        Be specific to the goal: "${goalText}".
        Do not add placeholders like [Your Name] if you can avoid them, write a high-quality ready-to-use template.
        
        Respond in JSON:
        {
          "draft": "Subject: ... \\n\\nDear ... "
        }
      `;

      const negotiatorResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: negotiatorPrompt,
        config: { responseMimeType: "application/json" }
      });
      const negotiatorResult = JSON.parse(negotiatorResponse.text || "{}");
      extensionDraft = negotiatorResult.draft || "";
    }

    steps[4].status = "completed";
    steps[4].output = extensionDraft ? "Drafted extension request due to overload risk." : "Schedule is safe. No extension drafts required.";

    // 6. Reflection Agent
    steps.push({
      agentName: "Reflection",
      status: "running",
      thought: `Synthesizing cognitive loads, context cues, and creating coaching feedback loops.`,
      timestamp: new Date().toISOString()
    });

    const reflectionPrompt = `
      You are the "Reflection Agent".
      Review this full planning output:
      - High level: ${plannerResult.highLevelPlan}
      - Tasks & Priorities: ${JSON.stringify(decomposerResult.tasks)}
      - Schedule: ${JSON.stringify(calendarResult.schedule)}
      - Success Probability: ${priorityResult.successProbability}%
      
      Generate a concise 2-3 sentence personalized coach insight or actionable tip for the user.
      Respond in JSON:
      {
        "coachInsight": "string"
      }
    `;

    const reflectionResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: reflectionPrompt,
      config: { responseMimeType: "application/json" }
    });
    const reflectionResult = JSON.parse(reflectionResponse.text || "{}");
    steps[5].status = "completed";
    steps[5].output = reflectionResult.coachInsight;

    // 7. Notification Agent
    steps.push({
      agentName: "Notification",
      status: "running",
      thought: `Scheduling proactive contextual check-ins and notifications.`,
      timestamp: new Date().toISOString()
    });
    steps[6].status = "completed";
    steps[6].output = `Set triggers. Guard intervals active. Alerts will deploy prior to deep work windows.`;

    // Construct final list of tasks
    const newTasksList: Task[] = (decomposerResult.tasks || []).map((t: any, index: number) => {
      const taskTitle = t.title;
      const matchingSchedule = (calendarResult.schedule || []).find((s: any) => s.title === taskTitle);
      const matchingPriority = (priorityResult.priorities || []).find((p: any) => p.title === taskTitle);

      const deadlineDate = new Date();
      deadlineDate.setDate(deadlineDate.getDate() + 3); // 3 days out default

      return {
        id: `task-${Date.now()}-${index}`,
        title: t.title,
        description: t.description || "",
        deadline: deadlineDate.toISOString(),
        priority: matchingPriority?.priority || t.priority || "medium",
        energy: t.energy || "medium",
        status: "pending",
        estimatedHours: t.estimatedHours || 2,
        actualHours: 0,
        category: t.category || "Deep Work",
        subtasks: (t.subtasks || []).map((st: any, sIdx: number) => ({
          id: `sub-${Date.now()}-${index}-${sIdx}`,
          title: st.title,
          status: "pending",
          estimatedMinutes: st.estimatedMinutes || 30
        })),
        successProbability: priorityResult.successProbability || 85,
        dependencies: [],
        timeBlock: matchingSchedule ? { start: matchingSchedule.start, end: matchingSchedule.end } : null,
        replannedAt: null,
        historicalReplansCount: 0,
        extensionDraft: extensionDraft || undefined,
        createdAt: new Date().toISOString()
      };
    });

    return res.json({
      success: true,
      tasks: newTasksList,
      steps,
      coachInsight: reflectionResult.coachInsight || "You have a solid plan. Follow your schedule blocks to succeed."
    });

  } catch (error: any) {
    console.error("Error in planning pipeline:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// AI Coach feedback / review generator
app.post("/api/agent/coach", async (req, res) => {
  try {
    const { focusSessions = [], tasks = [], currentStats } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json(createMockCoachLog(focusSessions, tasks, currentStats));
    }

    const coachPrompt = `
      You are the "AI Coach Agent" specializing in productivity reflection and deadline protection.
      We have:
      - Recent focus sessions: ${JSON.stringify(focusSessions)}
      - Task lists: ${JSON.stringify(tasks)}
      - Distraction parameters: ${JSON.stringify(currentStats)}

      Analyze their habits, focus trends, and generate a daily/weekly review.
      Calculate:
      1. A "habitsScore" (0-100) evaluating how disciplined they were.
      2. Achievements and missed items.
      3. Actionable suggestions to reduce meeting overhead, screen scrolling, or deep work friction.
      
      Respond in JSON:
      {
        "coachingNotes": "Detailed coach analysis and recommendations...",
        "achievements": ["achievement 1", "achievement 2"],
        "missedDeadlines": ["item 1"],
        "habitsScore": 78,
        "scrollTimeWastedMinutes": 120,
        "meetingTimeReducedMinutes": 30
      }
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: coachPrompt,
      config: { responseMimeType: "application/json" }
    });

    const result = JSON.parse(response.text || "{}");
    return res.json({ success: true, log: result });

  } catch (error: any) {
    console.error("Coach API error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// File upload parser (syllabus/syllabus PDF or task image)
app.post("/api/agent/parse-upload", async (req, res) => {
  try {
    const { fileName, fileType, fileContent } = req.body; // fileContent is base64
    const ai = getGeminiClient();

    if (!ai) {
      return res.json(createMockParsedUpload(fileName));
    }

    let parsePrompt = "";
    let contents: any[] = [];

    if (fileType.startsWith("image/")) {
      parsePrompt = `
        You are the "Task Decomposer Agent".
        This is an image of an assignment sheet, notice board, or syllabus.
        Analyze the image and extract:
        1. Assignment/Task name
        2. Deadline
        3. Subject/Category
        4. Subtasks to complete it.
        
        Respond in JSON schema:
        {
          "tasks": [
            {
              "title": "Task Title",
              "description": "Details extracted",
              "category": "Deep Work",
              "estimatedHours": 4,
              "subtasks": [
                { "title": "Subtask title", "estimatedMinutes": 60 }
              ]
            }
          ]
        }
      `;
      contents = [
        {
          inlineData: {
            mimeType: fileType,
            data: fileContent
          }
        },
        parsePrompt
      ];
    } else {
      // Assuming text contents (PDF text dump or standard doc)
      parsePrompt = `
        You are the "Task Decomposer Agent".
        Extract key assignments, exam dates, labs, and projects from this text:
        "${fileContent}"
        
        Respond in JSON schema:
        {
          "tasks": [
            {
              "title": "Task Title",
              "description": "Details extracted",
              "category": "Deep Work",
              "estimatedHours": 4,
              "subtasks": [
                { "title": "Subtask title", "estimatedMinutes": 60 }
              ]
            }
          ]
        }
      `;
      contents = [parsePrompt];
    }

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: contents,
      config: { responseMimeType: "application/json" }
    });

    const result = JSON.parse(response.text || "{}");
    return res.json({ success: true, tasks: result.tasks || [] });

  } catch (error: any) {
    console.error("Upload parse error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// AI Voice Command Processing
app.post("/api/agent/voice-command", async (req, res) => {
  try {
    const { transcript, currentTasks = [], currentEvents = [], context } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json(createMockVoiceCommand(transcript));
    }

    const systemInstruction = `
      You are the core of an AI voice-activated task planner and productivity executive.
      The user is speaking or typing a command: "${transcript}".
      Current tasks in database: ${JSON.stringify(currentTasks)}
      Current events on calendar: ${JSON.stringify(currentEvents)}
      Current user environmental context: ${JSON.stringify(context)}

      Analyze the user's input and determine what they want to do. You can return one of 5 major action types:
      1. "CREATE_TASK": Create a new task. Choose this if they mention adding, creating, scheduling, or finishing a task, homework, work, meeting, prep, etc.
         - You must populate "taskDetails" with details parsed from their command.
         - Category must be one of: "Deep Work" | "Meetings" | "Emails" | "Study" | "Routine" | "Personal".
         - Priority must be: "high" | "medium" | "low".
         - Energy must be: "high" | "medium" | "low".
         - Estimated hours: estimate standard hours (default 2).
      2. "OPTIMIZE": Replan, budget, or optimize their entire schedule. Choose this if they say "optimize", "replan", "schedule all", "rearrange", "clear conflicts", etc.
      3. "COACH": Give direct coach feedback or stats. Choose this if they ask "how am I doing?", "give me advice", "coaching notes", "what are my habits score?", etc.
      4. "NAVIGATE": Go to a specific page or view in the app. Choose this if they say "go to calendar", "show task board", "open settings", "view analytics", "start focus session", etc.
         - navigationPage must be: "dashboard" | "planner" | "calendar" | "tasks" | "analytics" | "coach" | "focus" | "radar" | "settings".
      5. "CHAT_RESPONSE": Conversing or general chat. Choose this if none of the above matches or if they are just checking in, greeting you, or asking a question.

      Return a response in JSON matching this schema:
      {
        "action": "CREATE_TASK" | "OPTIMIZE" | "COACH" | "NAVIGATE" | "CHAT_RESPONSE",
        "reply": "A concise, elegant, friendly vocal reply to say back to the user (keep it under 2 sentences since it will be spoken out loud).",
        "taskDetails": {
          "title": "Task title",
          "description": "Task description",
          "category": "Deep Work",
          "priority": "medium",
          "energy": "medium",
          "estimatedHours": 2
        },
        "navigationPage": "calendar"
      }
    `;

    const voiceResponse = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Process command: "${transcript}"`,
      config: {
        systemInstruction,
        responseMimeType: "application/json"
      }
    });

    const result = JSON.parse(voiceResponse.text || "{}");
    return res.json({ success: true, ...result });

  } catch (error: any) {
    console.error("Voice command error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// MOCK GENERATORS FOR GRACEFUL FALLBACK
function createMockVoiceCommand(transcript: string) {
  const lower = transcript.toLowerCase();
  
  if (lower.includes("add") || lower.includes("create") || lower.includes("task") || lower.includes("schedule a") || lower.includes("prepare") || lower.includes("submit")) {
    const title = transcript.replace(/add task|create task|schedule|add|create/gi, "").trim() || "New Voice Task";
    return {
      success: true,
      action: "CREATE_TASK",
      reply: `Sure, I've added the task "${title}" to your board and scheduled it. Let's make sure it gets completed!`,
      taskDetails: {
        title,
        description: "Created via voice command",
        category: lower.includes("study") || lower.includes("class") ? "Study" : lower.includes("meet") || lower.includes("interview") ? "Meetings" : "Deep Work",
        priority: lower.includes("urgent") || lower.includes("high") ? "high" : "medium",
        energy: "medium",
        estimatedHours: 2
      }
    };
  }
  
  if (lower.includes("optimize") || lower.includes("replan") || lower.includes("clean") || lower.includes("fix my") || lower.includes("rearrange")) {
    return {
      success: true,
      action: "OPTIMIZE",
      reply: "I am running the Guardian Optimizer. All your task overlaps are now cleared and schedule blocks are optimized!"
    };
  }
  
  if (lower.includes("coach") || lower.includes("advice") || lower.includes("how am i") || lower.includes("notes") || lower.includes("tips") || lower.includes("habit")) {
    return {
      success: true,
      action: "COACH",
      reply: "Based on your recent habits, you have a high productivity rating. Try to take focus sprints in the morning to protect your evening hours!"
    };
  }
  
  if (lower.includes("go to") || lower.includes("show") || lower.includes("open") || lower.includes("view")) {
    let page = "dashboard";
    if (lower.includes("calendar")) page = "calendar";
    else if (lower.includes("task") || lower.includes("board")) page = "tasks";
    else if (lower.includes("analytic") || lower.includes("chart")) page = "analytics";
    else if (lower.includes("coach") || lower.includes("review")) page = "coach";
    else if (lower.includes("focus") || lower.includes("pomodoro")) page = "focus";
    else if (lower.includes("radar") || lower.includes("collision")) page = "radar";
    else if (lower.includes("setting")) page = "settings";
    
    return {
      success: true,
      action: "NAVIGATE",
      reply: `Navigating to the ${page} view.`,
      navigationPage: page
    };
  }
  
  return {
    success: true,
    action: "CHAT_RESPONSE",
    reply: `Hello! I heard: "${transcript}". How can I help you manage your deadlines and optimize your day today?`
  };
}
function createMockAgenticPlan(goal: string, currentTasks: Task[], currentEvents: CalendarEvent[], context?: SystemContext) {
  const timestamp = new Date().toISOString();
  const lowerGoal = goal.toLowerCase();

  let extractedTitle = "Complete " + goal;
  let category: "Deep Work" | "Meetings" | "Emails" | "Study" | "Routine" | "Personal" = "Deep Work";
  let estimatedHours = 4;
  let subtasks: any[] = [];

  if (lowerGoal.includes("assignment")) {
    extractedTitle = "Finish Assignment Tasks";
    category = "Study";
    estimatedHours = 5;
    subtasks = [
      { id: "s1", title: "Review instructions & references", status: "pending", estimatedMinutes: 45 },
      { id: "s2", title: "Draft core analysis section", status: "pending", estimatedMinutes: 120 },
      { id: "s3", title: "Refine bibliography and submit", status: "pending", estimatedMinutes: 60 }
    ];
  } else if (lowerGoal.includes("interview")) {
    extractedTitle = "Prepare for Interviews";
    category = "Meetings";
    estimatedHours = 3;
    subtasks = [
      { id: "s1", title: "Review job description & resume", status: "pending", estimatedMinutes: 45 },
      { id: "s2", title: "Practice 5 behavioral stories", status: "pending", estimatedMinutes: 60 },
      { id: "s3", title: "Set up portfolio and references", status: "pending", estimatedMinutes: 40 }
    ];
  } else if (lowerGoal.includes("cat") || lowerGoal.includes("exam") || lowerGoal.includes("study")) {
    extractedTitle = "CAT Quantitative Preparation";
    category = "Study";
    estimatedHours = 6;
    subtasks = [
      { id: "s1", title: "Solve practice math sets", status: "pending", estimatedMinutes: 120 },
      { id: "s2", title: "Revise formulas & equations", status: "pending", estimatedMinutes: 90 },
      { id: "s3", title: "Take standard mock section", status: "pending", estimatedMinutes: 60 }
    ];
  } else if (lowerGoal.includes("flight") || lowerGoal.includes("pack") || lowerGoal.includes("travel")) {
    extractedTitle = "Travel packing & Logistics";
    category = "Routine";
    estimatedHours = 2;
    subtasks = [
      { id: "s1", title: "Draft checklist (clothing, electronics)", status: "pending", estimatedMinutes: 15 },
      { id: "s2", title: "Pack suitcase and backpack", status: "pending", estimatedMinutes: 60 },
      { id: "s3", title: "Double-check flight times & tickets", status: "pending", estimatedMinutes: 20 }
    ];
  } else {
    // Default fallback
    subtasks = [
      { id: "s1", title: "Analyze requirements & setup", status: "pending", estimatedMinutes: 30 },
      { id: "s2", title: "Execute focus phase", status: "pending", estimatedMinutes: 120 },
      { id: "s3", title: "Review output and polish", status: "pending", estimatedMinutes: 45 }
    ];
  }

  // Generate intermediate agent steps
  const steps: AgentStep[] = [
    {
      agentName: "Planner",
      status: "completed",
      thought: `Parsed goal: "${goal}". Identified active conflicts with existing tasks and estimated total workload.`,
      output: `Goal requires ${estimatedHours} hours of focused activity. Creating targeted roadmap.`,
      timestamp: new Date(Date.now() - 5000).toISOString()
    },
    {
      agentName: "Decomposer",
      status: "completed",
      thought: `Decomposing milestone "${extractedTitle}" into granular subtasks to streamline execution.`,
      output: `Extracted ${subtasks.length} focused subtasks.`,
      timestamp: new Date(Date.now() - 4000).toISOString()
    },
    {
      agentName: "Priority",
      status: "completed",
      thought: `Calculating workload density. Active tasks demand substantial energy block.`,
      output: `AI Predictor Score: 94% Success Probability. Current calendar and energy index allow safe execution.`,
      timestamp: new Date(Date.now() - 3000).toISOString()
    },
    {
      agentName: "Calendar",
      status: "completed",
      thought: `Analyzing calendar density. Finding empty deep-work slots to fit energy type: ${category === "Deep Work" || category === "Study" ? "High Energy" : "Medium/Low Energy"}.`,
      output: `Reserved work block on the schedule. Conflict resolution passed successfully.`,
      timestamp: new Date(Date.now() - 2000).toISOString()
    },
    {
      agentName: "Execution",
      status: "completed",
      thought: `Setting up negotiator modules. Current completion threshold is safe.`,
      output: `No negotiations needed. Schedule margins are adequate.`,
      timestamp: new Date(Date.now() - 1000).toISOString()
    },
    {
      agentName: "Reflection",
      status: "completed",
      thought: `Reflecting on cognitive load adjustments.`,
      output: `Insight: "Deep focus during morning hours maximizes success probability. Avoid scheduling emails during peak performance blocks."`,
      timestamp: new Date().toISOString()
    }
  ];

  // Set schedule blocks
  const blockStart = new Date();
  blockStart.setHours(blockStart.getHours() + 2);
  const blockEnd = new Date(blockStart);
  blockEnd.setHours(blockEnd.getHours() + estimatedHours);

  const mockTasks: Task[] = [
    {
      id: `task-${Date.now()}-0`,
      title: extractedTitle,
      description: `Automatically created task for: ${goal}`,
      deadline: new Date(Date.now() + 86400000 * 3).toISOString(), // 3 days out
      priority: "high",
      energy: category === "Deep Work" || category === "Study" ? "high" : "medium",
      status: "pending",
      estimatedHours,
      actualHours: 0,
      category: category as any,
      subtasks: subtasks as any,
      successProbability: 94,
      dependencies: [],
      timeBlock: {
        start: blockStart.toISOString(),
        end: blockEnd.toISOString()
      },
      replannedAt: null,
      historicalReplansCount: 0,
      createdAt: new Date().toISOString()
    }
  ];

  return {
    success: true,
    tasks: mockTasks,
    steps,
    coachInsight: "Great progress! Your schedule has been optimized to protect your deadlines. Morning deep work slots are reserved."
  };
}

function createMockCoachLog(sessions: any[], tasks: any[], stats: any) {
  return {
    success: true,
    log: {
      coachingNotes: "Your focus efficiency is high during the morning slots, but drops 40% after 4 PM. I noticed you spent 1.5 hours in meetings that could be shortened. Focus on batching meetings into a tight afternoon window so you preserve deep work cycles in the morning.",
      achievements: [
        "Completed 2 deep focus blocks successfully.",
        "Overcame morning fatigue and started coding by 9 AM."
      ],
      missedDeadlines: [
        "Weekly task review was delayed by 2 hours."
      ],
      habitsScore: 82,
      scrollTimeWastedMinutes: 45,
      meetingTimeReducedMinutes: 20
    }
  };
}

function createMockParsedUpload(fileName: string) {
  return {
    success: true,
    tasks: [
      {
        title: `Extract: ${fileName.split(".")[0]} Tasks`,
        description: `Parsed from uploaded document ${fileName}`,
        category: "Deep Work",
        estimatedHours: 4,
        subtasks: [
          { title: "Review parsed course outline", estimatedMinutes: 30 },
          { title: "Complete assignment lab 1", estimatedMinutes: 120 },
          { title: "Draft theoretical report", estimatedMinutes: 90 }
        ]
      }
    ]
  };
}

// Unified AI Chat with advanced features: Low Latency, Search Grounding, and Deep Thinking Mode
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history = [], lowLatency = false, thinking = false, searchGrounding = false, systemInstruction = "" } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Fallback for mock responses when API key is missing
      let fallbackText = `[MOCK] ${message}`;
      if (thinking) {
        fallbackText = `[MOCK THINKING... Analyzing consensus and constraints...] ${fallbackText}`;
      }
      if (searchGrounding) {
        fallbackText = `${fallbackText} (Grounded with simulated web results)`;
      }
      return res.json({
        text: fallbackText,
        searchResults: searchGrounding ? [{ title: "Simulated Search", uri: "https://google.com" }] : []
      });
    }

    // Determine model and configuration based on active modes
    let selectedModel = "gemini-3.5-flash";
    const config: any = {
      systemInstruction: systemInstruction || "You are Prodolar, a brilliant, protective, and firm AI Chief of Staff."
    };

    if (thinking) {
      selectedModel = "gemini-3.1-pro-preview";
      config.thinkingConfig = {
        thinkingBudget: 2048,
        thinkingLevel: "HIGH"
      };
    } else if (lowLatency) {
      selectedModel = "gemini-3.1-flash-lite";
    } else if (searchGrounding) {
      selectedModel = "gemini-3.5-flash";
      config.tools = [{ googleSearch: {} }];
    }

    // Map history to parts. History should be in { role: 'user'|'model', text: string } format
    const contents = history.map((item: any) => {
      const role = item.role === "user" ? "user" : "model";
      return {
        role,
        parts: [{ text: item.text }]
      };
    });

    // Append current user message
    contents.push({
      role: "user",
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents,
      config
    });

    const text = response.text || "";
    
    // Extract search results if search grounding was enabled
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const searchResults = chunks?.map((c: any) => {
      if (c.web) {
        return { title: c.web.title, uri: c.web.uri };
      }
      return null;
    }).filter(Boolean) || [];

    res.json({
      text,
      searchResults
    });
  } catch (error: any) {
    console.error("Error in /api/chat:", error);
    res.status(500).json({ error: error.message || "Failed to generate chat response" });
  }
});

// Audio Transcription Endpoint using gemini-3.5-flash
app.post("/api/transcribe", async (req, res) => {
  try {
    const { audioBase64, mimeType } = req.body;
    if (!audioBase64) {
      return res.status(400).json({ error: "Missing audioBase64 data" });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.json({
        text: "This is a mock transcription of your recorded command. Real-time transcription requires a configured Gemini API key."
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [
        {
          inlineData: {
            data: audioBase64,
            mimeType: mimeType || "audio/webm"
          }
        },
        "Please provide an accurate transcription of this audio. Transcribe everything exactly as spoken, with no additional commentary, notes, or introductions."
      ]
    });

    res.json({
      text: response.text || ""
    });
  } catch (error: any) {
    console.error("Error in /api/transcribe:", error);
    res.status(500).json({ error: error.message || "Failed to transcribe audio" });
  }
});

// Vite middleware configuration for serving the frontend React App
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
