export interface SubTask {
  id: string;
  title: string;
  status: "pending" | "completed";
  estimatedMinutes: number;
}

export interface TimeBlock {
  start: string; // ISO string
  end: string;   // ISO string
}

export interface Task {
  id: string;
  title: string;
  description: string;
  deadline: string; // ISO string or Date string
  priority: "high" | "medium" | "low";
  energy: "high" | "medium" | "low"; // Morning = deep (high), Afternoon = meetings (medium), Night = emails (low)
  status: "pending" | "completed" | "overdue" | "missed";
  estimatedHours: number;
  actualHours: number;
  category: "Deep Work" | "Meetings" | "Emails" | "Study" | "Routine" | "Personal";
  subtasks: SubTask[];
  successProbability: number; // AI Deadline Predictor: completion percentage 0-100
  dependencies: string[]; // Task IDs that must be done first
  timeBlock: TimeBlock | null; // Scheduled block of time
  replannedAt: string | null;
  historicalReplansCount: number;
  extensionDraft?: string; // AI Negotiated extension draft
  createdAt: string;
}

export interface CoachLog {
  id: string;
  date: string; // YYYY-MM-DD
  type: "daily" | "weekly";
  achievements: string[];
  missedDeadlines: string[];
  coachingNotes: string;
  scrollTimeWastedMinutes: number;
  meetingTimeReducedMinutes: number;
  habitsScore: number; // 0-100
}

export interface FocusSession {
  id: string;
  taskId: string | null;
  taskTitle?: string;
  durationMinutes: number;
  completed: boolean;
  distractionsCount: number;
  energyLevelBefore: "high" | "medium" | "low";
  energyLevelAfter: "high" | "medium" | "low";
  createdAt: string;
}

export interface AgentStep {
  agentName: "Planner" | "Decomposer" | "Priority" | "Calendar" | "Execution" | "Reflection" | "Notification";
  status: "idle" | "running" | "completed" | "failed";
  thought: string;
  output?: string;
  timestamp: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  start: string;
  end: string;
  category: "work" | "personal" | "flight" | "class" | "blocked";
}

export interface SystemContext {
  battery: number; // percentage
  internet: "online" | "offline";
  location: string;
  weather: string;
  traffic: string;
}
