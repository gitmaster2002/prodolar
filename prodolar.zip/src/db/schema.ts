import { integer, pgTable, serial, text, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  uid: text("uid").notNull().unique(), // Firebase Auth UID
  email: text("email").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: text("id").primaryKey(),
  userId: integer("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  title: text("title").notNull(),
  description: text("description").default(""),
  deadline: text("deadline").notNull(),
  priority: text("priority").notNull(), // high, medium, low
  energy: text("energy").notNull(),     // high, medium, low
  status: text("status").notNull(),     // pending, completed, overdue, missed
  estimatedHours: integer("estimated_hours").default(0),
  actualHours: integer("actual_hours").default(0),
  category: text("category").notNull(),
  subtasks: jsonb("subtasks").default([]), // Array of SubTask
  successProbability: integer("success_probability").default(0),
  dependencies: jsonb("dependencies").default([]), // Array of strings (task ids)
  timeBlock: jsonb("time_block"), // TimeBlock or null
  replannedAt: text("replanned_at"),
  historicalReplansCount: integer("historical_replans_count").default(0),
  extensionDraft: text("extension_draft"),
  createdAt: text("created_at").notNull(),
});

export const calendarEvents = pgTable("calendar_events", {
  id: text("id").primaryKey(),
  userId: integer("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  title: text("title").notNull(),
  start: text("start_time").notNull(),
  end: text("end_time").notNull(),
  category: text("category").notNull(), // work, personal, flight, class, blocked
});

export const coachLogs = pgTable("coach_logs", {
  id: text("id").primaryKey(),
  userId: integer("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  date: text("date").notNull(), // YYYY-MM-DD
  type: text("type").notNull(), // daily, weekly
  achievements: jsonb("achievements").default([]),
  missedDeadlines: jsonb("missed_deadlines").default([]),
  coachingNotes: text("coaching_notes").notNull(),
  scrollTimeWastedMinutes: integer("scroll_time_wasted_minutes").default(0),
  meetingTimeReducedMinutes: integer("meeting_time_reduced_minutes").default(0),
  habitsScore: integer("habits_score").default(0),
});

export const focusSessions = pgTable("focus_sessions", {
  id: text("id").primaryKey(),
  userId: integer("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  taskId: text("task_id"),
  taskTitle: text("task_title"),
  durationMinutes: integer("duration_minutes").notNull(),
  completed: boolean("completed").notNull(),
  distractionsCount: integer("distractions_count").default(0),
  energyLevelBefore: text("energy_level_before").notNull(),
  energyLevelAfter: text("energy_level_after").notNull(),
  createdAt: text("created_at").notNull(),
});

// Relationships
export const usersRelations = relations(users, ({ many }) => ({
  tasks: many(tasks),
  calendarEvents: many(calendarEvents),
  coachLogs: many(coachLogs),
  focusSessions: many(focusSessions),
}));

export const tasksRelations = relations(tasks, ({ one }) => ({
  user: one(users, {
    fields: [tasks.userId],
    references: [users.id],
  }),
}));

export const calendarEventsRelations = relations(calendarEvents, ({ one }) => ({
  user: one(users, {
    fields: [calendarEvents.userId],
    references: [users.id],
  }),
}));

export const coachLogsRelations = relations(coachLogs, ({ one }) => ({
  user: one(users, {
    fields: [coachLogs.userId],
    references: [users.id],
  }),
}));

export const focusSessionsRelations = relations(focusSessions, ({ one }) => ({
  user: one(users, {
    fields: [focusSessions.userId],
    references: [users.id],
  }),
}));
