import { db } from "./index.ts";
import { tasks, calendarEvents, coachLogs, focusSessions } from "./schema.ts";
import { eq, and } from "drizzle-orm";
import { Task, CalendarEvent, CoachLog, FocusSession } from "../types.ts";

// --- TASKS ---
export async function getTasks(userId: number): Promise<Task[]> {
  try {
    const dbTasks = await db.select().from(tasks).where(eq(tasks.userId, userId));
    return dbTasks.map(t => ({
      id: t.id,
      title: t.title,
      description: t.description || "",
      deadline: t.deadline,
      priority: t.priority as any,
      energy: t.energy as any,
      status: t.status as any,
      estimatedHours: t.estimatedHours || 0,
      actualHours: t.actualHours || 0,
      category: t.category as any,
      subtasks: (t.subtasks as any) || [],
      successProbability: t.successProbability || 0,
      dependencies: (t.dependencies as any) || [],
      timeBlock: (t.timeBlock as any) || null,
      replannedAt: t.replannedAt || null,
      historicalReplansCount: t.historicalReplansCount || 0,
      extensionDraft: t.extensionDraft || undefined,
      createdAt: t.createdAt,
    }));
  } catch (error) {
    console.error("Failed to query tasks from Postgres:", error);
    throw new Error("Database query failed", { cause: error });
  }
}

export async function saveTask(userId: number, task: Task): Promise<void> {
  try {
    await db.insert(tasks)
      .values({
        id: task.id,
        userId,
        title: task.title,
        description: task.description,
        deadline: task.deadline,
        priority: task.priority,
        energy: task.energy,
        status: task.status,
        estimatedHours: task.estimatedHours,
        actualHours: task.actualHours,
        category: task.category,
        subtasks: task.subtasks,
        successProbability: task.successProbability,
        dependencies: task.dependencies,
        timeBlock: task.timeBlock,
        replannedAt: task.replannedAt,
        historicalReplansCount: task.historicalReplansCount,
        extensionDraft: task.extensionDraft,
        createdAt: task.createdAt || new Date().toISOString(),
      })
      .onConflictDoUpdate({
        target: tasks.id,
        set: {
          title: task.title,
          description: task.description,
          deadline: task.deadline,
          priority: task.priority,
          energy: task.energy,
          status: task.status,
          estimatedHours: task.estimatedHours,
          actualHours: task.actualHours,
          category: task.category,
          subtasks: task.subtasks,
          successProbability: task.successProbability,
          dependencies: task.dependencies,
          timeBlock: task.timeBlock,
          replannedAt: task.replannedAt,
          historicalReplansCount: task.historicalReplansCount,
          extensionDraft: task.extensionDraft,
        }
      });
  } catch (error) {
    console.error("Failed to save task to Postgres:", error);
    throw new Error("Database insert/update failed", { cause: error });
  }
}

export async function deleteTask(userId: number, taskId: string): Promise<void> {
  try {
    await db.delete(tasks).where(and(eq(tasks.id, taskId), eq(tasks.userId, userId)));
  } catch (error) {
    console.error("Failed to delete task from Postgres:", error);
    throw new Error("Database delete failed", { cause: error });
  }
}

// --- CALENDAR EVENTS ---
export async function getCalendarEvents(userId: number): Promise<CalendarEvent[]> {
  try {
    const dbEvents = await db.select().from(calendarEvents).where(eq(calendarEvents.userId, userId));
    return dbEvents.map(e => ({
      id: e.id,
      title: e.title,
      start: e.start,
      end: e.end,
      category: e.category as any,
    }));
  } catch (error) {
    console.error("Failed to query events from Postgres:", error);
    throw new Error("Database query failed", { cause: error });
  }
}

export async function saveCalendarEvent(userId: number, event: CalendarEvent): Promise<void> {
  try {
    await db.insert(calendarEvents)
      .values({
        id: event.id,
        userId,
        title: event.title,
        start: event.start,
        end: event.end,
        category: event.category,
      })
      .onConflictDoUpdate({
        target: calendarEvents.id,
        set: {
          title: event.title,
          start: event.start,
          end: event.end,
          category: event.category,
        }
      });
  } catch (error) {
    console.error("Failed to save event to Postgres:", error);
    throw new Error("Database insert/update failed", { cause: error });
  }
}

export async function deleteCalendarEvent(userId: number, eventId: string): Promise<void> {
  try {
    await db.delete(calendarEvents).where(and(eq(calendarEvents.id, eventId), eq(calendarEvents.userId, userId)));
  } catch (error) {
    console.error("Failed to delete event from Postgres:", error);
    throw new Error("Database delete failed", { cause: error });
  }
}

// --- COACH LOGS ---
export async function getCoachLogs(userId: number): Promise<CoachLog[]> {
  try {
    const dbLogs = await db.select().from(coachLogs).where(eq(coachLogs.userId, userId));
    return dbLogs.map(l => ({
      id: l.id,
      date: l.date,
      type: l.type as any,
      achievements: (l.achievements as any) || [],
      missedDeadlines: (l.missedDeadlines as any) || [],
      coachingNotes: l.coachingNotes,
      scrollTimeWastedMinutes: l.scrollTimeWastedMinutes || 0,
      meetingTimeReducedMinutes: l.meetingTimeReducedMinutes || 0,
      habitsScore: l.habitsScore || 0,
    }));
  } catch (error) {
    console.error("Failed to query coach logs from Postgres:", error);
    throw new Error("Database query failed", { cause: error });
  }
}

export async function saveCoachLog(userId: number, log: CoachLog): Promise<void> {
  try {
    await db.insert(coachLogs)
      .values({
        id: log.id,
        userId,
        date: log.date,
        type: log.type,
        achievements: log.achievements,
        missedDeadlines: log.missedDeadlines,
        coachingNotes: log.coachingNotes,
        scrollTimeWastedMinutes: log.scrollTimeWastedMinutes,
        meetingTimeReducedMinutes: log.meetingTimeReducedMinutes,
        habitsScore: log.habitsScore,
      })
      .onConflictDoUpdate({
        target: coachLogs.id,
        set: {
          date: log.date,
          type: log.type,
          achievements: log.achievements,
          missedDeadlines: log.missedDeadlines,
          coachingNotes: log.coachingNotes,
          scrollTimeWastedMinutes: log.scrollTimeWastedMinutes,
          meetingTimeReducedMinutes: log.meetingTimeReducedMinutes,
          habitsScore: log.habitsScore,
        }
      });
  } catch (error) {
    console.error("Failed to save coach log to Postgres:", error);
    throw new Error("Database insert/update failed", { cause: error });
  }
}

// --- FOCUS SESSIONS ---
export async function getFocusSessions(userId: number): Promise<FocusSession[]> {
  try {
    const dbSessions = await db.select().from(focusSessions).where(eq(focusSessions.userId, userId));
    return dbSessions.map(s => ({
      id: s.id,
      taskId: s.taskId || null,
      taskTitle: s.taskTitle || undefined,
      durationMinutes: s.durationMinutes,
      completed: s.completed,
      distractionsCount: s.distractionsCount || 0,
      energyLevelBefore: s.energyLevelBefore as any,
      energyLevelAfter: s.energyLevelAfter as any,
      createdAt: s.createdAt,
    }));
  } catch (error) {
    console.error("Failed to query focus sessions from Postgres:", error);
    throw new Error("Database query failed", { cause: error });
  }
}

export async function saveFocusSession(userId: number, session: FocusSession): Promise<void> {
  try {
    await db.insert(focusSessions)
      .values({
        id: session.id,
        userId,
        taskId: session.taskId,
        taskTitle: session.taskTitle,
        durationMinutes: session.durationMinutes,
        completed: session.completed,
        distractionsCount: session.distractionsCount,
        energyLevelBefore: session.energyLevelBefore,
        energyLevelAfter: session.energyLevelAfter,
        createdAt: session.createdAt,
      })
      .onConflictDoUpdate({
        target: focusSessions.id,
        set: {
          taskId: session.taskId,
          taskTitle: session.taskTitle,
          durationMinutes: session.durationMinutes,
          completed: session.completed,
          distractionsCount: session.distractionsCount,
          energyLevelBefore: session.energyLevelBefore,
          energyLevelAfter: session.energyLevelAfter,
          createdAt: session.createdAt,
        }
      });
  } catch (error) {
    console.error("Failed to save focus session to Postgres:", error);
    throw new Error("Database insert/update failed", { cause: error });
  }
}
