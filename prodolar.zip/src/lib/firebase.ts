import { initializeApp } from "firebase/app";
import { initializeFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  projectId: "rare-shade-r5xj8",
  appId: "1:28183705447:web:c063cc354b69f5df0c61c2",
  apiKey: "AIzaSyBfUyZCZUnjDRuylwS_D-thau_QQdbdB_U",
  authDomain: "rare-shade-r5xj8.firebaseapp.com",
  storageBucket: "rare-shade-r5xj8.firebasestorage.app",
  messagingSenderId: "28183705447"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore with custom database ID
export const db = initializeFirestore(app, {}, "ai-studio-deadlineguardian-8f741b13-e9f4-430b-8156-f025c70b8741");

// Initialize Auth
export const auth = getAuth(app);

// Initialize and configure Google Auth Provider for Workspace integration
import { GoogleAuthProvider } from "firebase/auth";
export const googleAuthProvider = new GoogleAuthProvider();
googleAuthProvider.addScope("https://www.googleapis.com/auth/gmail.readonly");
googleAuthProvider.addScope("https://www.googleapis.com/auth/gmail.send");
googleAuthProvider.addScope("https://www.googleapis.com/auth/gmail.modify");
googleAuthProvider.addScope("https://www.googleapis.com/auth/tasks");
googleAuthProvider.addScope("https://www.googleapis.com/auth/calendar");
