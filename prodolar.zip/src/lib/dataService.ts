import { 
  collection, 
  getDocs, 
  setDoc, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  orderBy, 
  onSnapshot,
  Timestamp 
} from "firebase/firestore";
import { db, auth } from "./firebase";
import { Task, CalendarEvent, CoachLog, FocusSession } from "../types";

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  const jsonStr = JSON.stringify(errInfo);
  console.error('Firestore Error: ', jsonStr);
  throw new Error(jsonStr);
}

const isPermissionError = (err: any): boolean => {
  if (!err) return false;
  const msg = err.message || String(err);
  return err.code === 'permission-denied' || msg.includes('permission-denied') || msg.includes('Permission denied') || msg.includes('Missing or insufficient permissions');
};


// Fallback static data representing the overload scenario
const DEFAULT_TASKS: Task[] = [
  {
    id: "task-1",
    title: "Assignment 1: Distributed Consensus Paper",
    description: "Write a 5-page synthesis on Paxos vs Raft consensus algorithms with failure scenarios.",
    deadline: new Date(Date.now() + 86400000 * 2).toISOString(), // 2 days out
    priority: "high",
    energy: "high",
    status: "pending",
    estimatedHours: 5,
    actualHours: 0,
    category: "Deep Work",
    subtasks: [
      { id: "sub-1-1", title: "Read Raft original paper", status: "completed", estimatedMinutes: 60 },
      { id: "sub-1-2", title: "Outline comparative analysis sections", status: "pending", estimatedMinutes: 45 },
      { id: "sub-1-3", title: "Draft Raft leader election details", status: "pending", estimatedMinutes: 120 },
      { id: "sub-1-4", title: "Write conclusion and citation review", status: "pending", estimatedMinutes: 60 }
    ],
    successProbability: 42, // Starts low to show "AI Deadline Predictor" warnings!
    dependencies: [],
    timeBlock: {
      start: new Date(Date.now() + 86400000 * 1).toISOString(), // Tomorrow
      end: new Date(Date.now() + 86400000 * 1 + 3600000 * 4).toISOString()
    },
    replannedAt: null,
    historicalReplansCount: 0,
    createdAt: new Date().toISOString()
  },
  {
    id: "task-2",
    title: "Assignment 2: Neural Net Backprop from Scratch",
    description: "Implement simple multilayer perceptron in raw NumPy with custom loss function.",
    deadline: new Date(Date.now() + 86400000 * 3).toISOString(), // 3 days out
    priority: "high",
    energy: "high",
    status: "pending",
    estimatedHours: 6,
    actualHours: 0,
    category: "Deep Work",
    subtasks: [
      { id: "sub-2-1", title: "Write forward propagation steps", status: "pending", estimatedMinutes: 60 },
      { id: "sub-2-2", title: "Derive gradients for cross entropy", status: "pending", estimatedMinutes: 90 },
      { id: "sub-2-3", title: "Implement backprop loop and verify weights", status: "pending", estimatedMinutes: 120 }
    ],
    successProbability: 38,
    dependencies: [],
    timeBlock: null, // No time block yet, showing scheduling agent's job!
    replannedAt: null,
    historicalReplansCount: 0,
    createdAt: new Date().toISOString()
  },
  {
    id: "task-3",
    title: "Assignment 3: Drizzle ORM Schema Migration",
    description: "Draft database schema and structure migrations for the production Postgres setup.",
    deadline: new Date(Date.now() + 86400000 * 5).toISOString(), // 5 days out
    priority: "medium",
    energy: "medium",
    status: "pending",
    estimatedHours: 3,
    actualHours: 0,
    category: "Study",
    subtasks: [
      { id: "sub-3-1", title: "Define tables in TypeScript schema file", status: "pending", estimatedMinutes: 60 },
      { id: "sub-3-2", title: "Generate and test local migration SQL", status: "pending", estimatedMinutes: 60 }
    ],
    successProbability: 82,
    dependencies: [],
    timeBlock: null,
    replannedAt: null,
    historicalReplansCount: 0,
    createdAt: new Date().toISOString()
  },
  {
    id: "task-4",
    title: "Assignment 4: UI Design Audit",
    description: "Review app designs for accessibility contrast and responsive breaks.",
    deadline: new Date(Date.now() + 86400000 * 6).toISOString(), // 6 days out
    priority: "low",
    energy: "low",
    status: "pending",
    estimatedHours: 2,
    actualHours: 0,
    category: "Routine",
    subtasks: [
      { id: "sub-4-1", title: "Inspect components on ultra-wide screens", status: "pending", estimatedMinutes: 30 },
      { id: "sub-4-2", title: "Fix contrast in utility tail menus", status: "pending", estimatedMinutes: 60 }
    ],
    successProbability: 91,
    dependencies: [],
    timeBlock: null,
    replannedAt: null,
    historicalReplansCount: 0,
    createdAt: new Date().toISOString()
  },
  {
    id: "task-5",
    title: "Interview Prep: Google APAC Round",
    description: "Revise core data structures, graphs, dynamic programming patterns.",
    deadline: new Date(Date.now() + 86400000 * 1).toISOString(), // Tomorrow
    priority: "high",
    energy: "high",
    status: "pending",
    estimatedHours: 4,
    actualHours: 0,
    category: "Study",
    subtasks: [
      { id: "sub-5-1", title: "Practice 3 Hard Graph problems", status: "pending", estimatedMinutes: 120 },
      { id: "sub-5-2", title: "Mock interview with feedback partner", status: "pending", estimatedMinutes: 90 }
    ],
    successProbability: 45,
    dependencies: [],
    timeBlock: {
      start: new Date(Date.now() + 86400000 * 0.5).toISOString(), // Later today
      end: new Date(Date.now() + 86400000 * 0.5 + 3600000 * 3).toISOString()
    },
    replannedAt: null,
    historicalReplansCount: 0,
    createdAt: new Date().toISOString()
  },
  {
    id: "task-6",
    title: "CAT Preparation: Quant practice",
    description: "Complete arithmetic practice booklets and practice speed sets.",
    deadline: new Date(Date.now() + 86400000 * 4).toISOString(), // 4 days out
    priority: "medium",
    energy: "medium",
    status: "pending",
    estimatedHours: 3,
    actualHours: 0,
    category: "Study",
    subtasks: [
      { id: "sub-6-1", title: "Solve speed math module 1", status: "pending", estimatedMinutes: 60 },
      { id: "sub-6-2", title: "Review incorrect geometry answers", status: "pending", estimatedMinutes: 60 }
    ],
    successProbability: 60,
    dependencies: [],
    timeBlock: null,
    replannedAt: null,
    historicalReplansCount: 0,
    createdAt: new Date().toISOString()
  }
];

const DEFAULT_EVENTS: CalendarEvent[] = [
  {
    id: "event-1",
    title: "Flight to Delhi (AI-504)",
    start: new Date(Date.now() + 86400000 * 3).toISOString(), // 3 days out
    end: new Date(Date.now() + 86400000 * 3 + 3.5 * 3600000).toISOString(),
    category: "flight"
  },
  {
    id: "event-2",
    title: "Distributed Systems Lecture",
    start: new Date(Date.now() + 86400000 * 1).toISOString(), // Tomorrow morning
    end: new Date(Date.now() + 86400000 * 1 + 2 * 3600000).toISOString(),
    category: "class"
  },
  {
    id: "event-3",
    title: "Google Recruiter Check-in",
    start: new Date(Date.now() + 86400000 * 2).toISOString(),
    end: new Date(Date.now() + 86400000 * 2 + 0.5 * 3600000).toISOString(),
    category: "work"
  }
];

const DEFAULT_COACH_LOGS: CoachLog[] = [
  {
    id: "coach-1",
    date: new Date(Date.now() - 86400000 * 1).toISOString().split("T")[0],
    type: "daily",
    achievements: [
      "Completed Backprop derivations successfully",
      "Stuck to morning Pomodoro blocks without checking phone"
    ],
    missedDeadlines: [
      "Algorithmic complexities reading was pushed back"
    ],
    coachingNotes: "Your focus efficiency is high during early morning slots (8 AM - 11 AM), but drops nearly 45% after 4 PM. To optimize, reserve your morning slots strictly for deep work (like Assignment 1) and bundle all emails, routine UI audits, and chat check-ins in the afternoon. Great effort on avoiding screen distractions yesterday!",
    scrollTimeWastedMinutes: 45,
    meetingTimeReducedMinutes: 15,
    habitsScore: 82
  }
];

const DEFAULT_FOCUS_SESSIONS: FocusSession[] = [
  {
    id: "focus-1",
    taskId: "task-1",
    taskTitle: "Assignment 1: Distributed Consensus Paper",
    durationMinutes: 50,
    completed: true,
    distractionsCount: 1,
    energyLevelBefore: "high",
    energyLevelAfter: "medium",
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString()
  }
];

// Seed Firestore or fallback local state helper
export class DataService {
  public static workspaceId = "default-user-workspace";

  private static async syncToPostgres(endpoint: string, method: string, body?: any) {
    try {
      const user = auth.currentUser;
      if (!user) return;
      const token = await user.getIdToken();
      const headers: HeadersInit = {
        "Authorization": `Bearer ${token}`,
      };
      if (body) {
        headers["Content-Type"] = "application/json";
      }
      const response = await fetch(`/api/db/${endpoint}`, {
        method,
        headers,
        body: body ? JSON.stringify(body) : undefined,
      });
      if (!response.ok) {
        console.warn(`Postgres sync failed for ${endpoint}:`, await response.text());
      }
    } catch (err) {
      console.warn(`Postgres sync error for ${endpoint}:`, err);
    }
  }

  static setWorkspaceId(uid: string) {
    this.workspaceId = uid || "default-user-workspace";
    console.log("Database workspace updated to:", this.workspaceId);
  }

  // Seeds database if collections are empty
  static async seedIfEmpty() {
    try {
      const taskColRef = collection(db, "workspaces", this.workspaceId, "tasks");
      const snap = await getDocs(taskColRef).catch(err => {
        if (isPermissionError(err)) {
          handleFirestoreError(err, OperationType.GET, `workspaces/${this.workspaceId}/tasks`);
        }
        throw err;
      });
      if (snap.empty) {
        console.log("Seeding empty firestore database with default items...");
        // Seed Tasks
        for (const task of DEFAULT_TASKS) {
          await setDoc(doc(db, "workspaces", this.workspaceId, "tasks", task.id), task).catch(err => {
            if (isPermissionError(err)) {
              handleFirestoreError(err, OperationType.WRITE, `workspaces/${this.workspaceId}/tasks/${task.id}`);
            }
            throw err;
          });
        }
        // Seed Events
        for (const ev of DEFAULT_EVENTS) {
          await setDoc(doc(db, "workspaces", this.workspaceId, "events", ev.id), ev).catch(err => {
            if (isPermissionError(err)) {
              handleFirestoreError(err, OperationType.WRITE, `workspaces/${this.workspaceId}/events/${ev.id}`);
            }
            throw err;
          });
        }
        // Seed Coach Logs
        for (const log of DEFAULT_COACH_LOGS) {
          await setDoc(doc(db, "workspaces", this.workspaceId, "coachLogs", log.id), log).catch(err => {
            if (isPermissionError(err)) {
              handleFirestoreError(err, OperationType.WRITE, `workspaces/${this.workspaceId}/coachLogs/${log.id}`);
            }
            throw err;
          });
        }
        // Seed Focus Sessions
        for (const s of DEFAULT_FOCUS_SESSIONS) {
          await setDoc(doc(db, "workspaces", this.workspaceId, "focusSessions", s.id), s).catch(err => {
            if (isPermissionError(err)) {
              handleFirestoreError(err, OperationType.WRITE, `workspaces/${this.workspaceId}/focusSessions/${s.id}`);
            }
            throw err;
          });
        }
        console.log("Seeding complete!");
      }
    } catch (err) {
      if (isPermissionError(err)) {
        handleFirestoreError(err, OperationType.WRITE, `workspaces/${this.workspaceId}`);
      }
      console.error("Firestore seeding failed, using local storage fallback:", err);
      if (!localStorage.getItem("seeded_deadline_guardian")) {
        localStorage.setItem("tasks", JSON.stringify(DEFAULT_TASKS));
        localStorage.setItem("events", JSON.stringify(DEFAULT_EVENTS));
        localStorage.setItem("coachLogs", JSON.stringify(DEFAULT_COACH_LOGS));
        localStorage.setItem("focusSessions", JSON.stringify(DEFAULT_FOCUS_SESSIONS));
        localStorage.setItem("seeded_deadline_guardian", "true");
      }
    }
  }

  // --- TASKS API ---
  static listenTasks(onUpdate: (tasks: Task[]) => void): () => void {
    try {
      const q = query(collection(db, "workspaces", this.workspaceId, "tasks"), orderBy("createdAt", "desc"));
      return onSnapshot(q, (snapshot) => {
        const tasks: Task[] = [];
        snapshot.forEach((doc) => {
          tasks.push({ ...doc.data(), id: doc.id } as Task);
        });
        if (tasks.length > 0) {
          localStorage.setItem("tasks", JSON.stringify(tasks));
          onUpdate(tasks);
        } else {
          // If Firestore returns empty, fetch local
          const local = localStorage.getItem("tasks");
          if (local) onUpdate(JSON.parse(local));
        }
      }, (err) => {
        if (isPermissionError(err)) {
          handleFirestoreError(err, OperationType.LIST, `workspaces/${this.workspaceId}/tasks`);
        }
        console.warn("Firestore error in tasks subscription:", err);
        const local = localStorage.getItem("tasks");
        if (local) onUpdate(JSON.parse(local));
      });
    } catch (err) {
      if (isPermissionError(err)) {
        handleFirestoreError(err, OperationType.LIST, `workspaces/${this.workspaceId}/tasks`);
      }
      console.error("Failed to establish tasks listener:", err);
      const local = localStorage.getItem("tasks");
      if (local) onUpdate(JSON.parse(local));
      return () => {};
    }
  }

  static async saveTask(task: Task): Promise<void> {
    try {
      await setDoc(doc(db, "workspaces", this.workspaceId, "tasks", task.id), task);
      await this.syncToPostgres("tasks", "POST", task);
    } catch (err) {
      if (isPermissionError(err)) {
        handleFirestoreError(err, OperationType.WRITE, `workspaces/${this.workspaceId}/tasks/${task.id}`);
      }
      console.warn("Firestore task write failed, writing locally:", err);
      const tasks = JSON.parse(localStorage.getItem("tasks") || "[]");
      const idx = tasks.findIndex((t: any) => t.id === task.id);
      if (idx > -1) tasks[idx] = task;
      else tasks.unshift(task);
      localStorage.setItem("tasks", JSON.stringify(tasks));
    }
  }

  static async deleteTask(taskId: string): Promise<void> {
    try {
      await deleteDoc(doc(db, "workspaces", this.workspaceId, "tasks", taskId));
      await this.syncToPostgres(`tasks/${taskId}`, "DELETE");
    } catch (err) {
      if (isPermissionError(err)) {
        handleFirestoreError(err, OperationType.DELETE, `workspaces/${this.workspaceId}/tasks/${taskId}`);
      }
      console.warn("Firestore task delete failed, deleting locally:", err);
      const tasks = JSON.parse(localStorage.getItem("tasks") || "[]");
      const filtered = tasks.filter((t: any) => t.id !== taskId);
      localStorage.setItem("tasks", JSON.stringify(filtered));
    }
  }

  // --- CALENDAR EVENTS ---
  static listenEvents(onUpdate: (events: CalendarEvent[]) => void): () => void {
    try {
      const q = collection(db, "workspaces", this.workspaceId, "events");
      return onSnapshot(q, (snapshot) => {
        const events: CalendarEvent[] = [];
        snapshot.forEach((doc) => {
          events.push({ ...doc.data(), id: doc.id } as CalendarEvent);
        });
        if (events.length > 0) {
          localStorage.setItem("events", JSON.stringify(events));
          onUpdate(events);
        } else {
          const local = localStorage.getItem("events");
          if (local) onUpdate(JSON.parse(local));
        }
      }, (err) => {
        if (isPermissionError(err)) {
          handleFirestoreError(err, OperationType.LIST, `workspaces/${this.workspaceId}/events`);
        }
        console.warn("Events listener failed:", err);
        const local = localStorage.getItem("events");
        if (local) onUpdate(JSON.parse(local));
      });
    } catch (err) {
      if (isPermissionError(err)) {
        handleFirestoreError(err, OperationType.LIST, `workspaces/${this.workspaceId}/events`);
      }
      console.error("Events error:", err);
      const local = localStorage.getItem("events");
      if (local) onUpdate(JSON.parse(local));
      return () => {};
    }
  }

  static async saveEvent(event: CalendarEvent): Promise<void> {
    try {
      await setDoc(doc(db, "workspaces", this.workspaceId, "events", event.id), event);
      await this.syncToPostgres("events", "POST", event);
    } catch (err) {
      if (isPermissionError(err)) {
        handleFirestoreError(err, OperationType.WRITE, `workspaces/${this.workspaceId}/events/${event.id}`);
      }
      const events = JSON.parse(localStorage.getItem("events") || "[]");
      const idx = events.findIndex((e: any) => e.id === event.id);
      if (idx > -1) events[idx] = event;
      else events.unshift(event);
      localStorage.setItem("events", JSON.stringify(events));
    }
  }

  static async deleteEvent(eventId: string): Promise<void> {
    try {
      await deleteDoc(doc(db, "workspaces", this.workspaceId, "events", eventId));
      await this.syncToPostgres(`events/${eventId}`, "DELETE");
    } catch (err) {
      if (isPermissionError(err)) {
        handleFirestoreError(err, OperationType.DELETE, `workspaces/${this.workspaceId}/events/${eventId}`);
      }
      const events = JSON.parse(localStorage.getItem("events") || "[]");
      const filtered = events.filter((e: any) => e.id !== eventId);
      localStorage.setItem("events", JSON.stringify(filtered));
    }
  }

  // --- COACH LOGS ---
  static listenCoachLogs(onUpdate: (logs: CoachLog[]) => void): () => void {
    try {
      const q = query(collection(db, "workspaces", this.workspaceId, "coachLogs"), orderBy("date", "desc"));
      return onSnapshot(q, (snapshot) => {
        const logs: CoachLog[] = [];
        snapshot.forEach((doc) => {
          logs.push({ ...doc.data(), id: doc.id } as CoachLog);
        });
        if (logs.length > 0) {
          localStorage.setItem("coachLogs", JSON.stringify(logs));
          onUpdate(logs);
        } else {
          const local = localStorage.getItem("coachLogs");
          if (local) onUpdate(JSON.parse(local));
        }
      }, (err) => {
        if (isPermissionError(err)) {
          handleFirestoreError(err, OperationType.LIST, `workspaces/${this.workspaceId}/coachLogs`);
        }
        const local = localStorage.getItem("coachLogs");
        if (local) onUpdate(JSON.parse(local));
      });
    } catch (err) {
      if (isPermissionError(err)) {
        handleFirestoreError(err, OperationType.LIST, `workspaces/${this.workspaceId}/coachLogs`);
      }
      const local = localStorage.getItem("coachLogs");
      if (local) onUpdate(JSON.parse(local));
      return () => {};
    }
  }

  static async saveCoachLog(log: CoachLog): Promise<void> {
    try {
      await setDoc(doc(db, "workspaces", this.workspaceId, "coachLogs", log.id), log);
      await this.syncToPostgres("coach-logs", "POST", log);
    } catch (err) {
      if (isPermissionError(err)) {
        handleFirestoreError(err, OperationType.WRITE, `workspaces/${this.workspaceId}/coachLogs/${log.id}`);
      }
      const logs = JSON.parse(localStorage.getItem("coachLogs") || "[]");
      logs.unshift(log);
      localStorage.setItem("coachLogs", JSON.stringify(logs));
    }
  }

  // --- FOCUS SESSIONS ---
  static listenFocusSessions(onUpdate: (sessions: FocusSession[]) => void): () => void {
    try {
      const q = query(collection(db, "workspaces", this.workspaceId, "focusSessions"), orderBy("createdAt", "desc"));
      return onSnapshot(q, (snapshot) => {
        const sessions: FocusSession[] = [];
        snapshot.forEach((doc) => {
          sessions.push({ ...doc.data(), id: doc.id } as FocusSession);
        });
        if (sessions.length > 0) {
          localStorage.setItem("focusSessions", JSON.stringify(sessions));
          onUpdate(sessions);
        } else {
          const local = localStorage.getItem("focusSessions");
          if (local) onUpdate(JSON.parse(local));
        }
      }, (err) => {
        if (isPermissionError(err)) {
          handleFirestoreError(err, OperationType.LIST, `workspaces/${this.workspaceId}/focusSessions`);
        }
        const local = localStorage.getItem("focusSessions");
        if (local) onUpdate(JSON.parse(local));
      });
    } catch (err) {
      if (isPermissionError(err)) {
        handleFirestoreError(err, OperationType.LIST, `workspaces/${this.workspaceId}/focusSessions`);
      }
      const local = localStorage.getItem("focusSessions");
      if (local) onUpdate(JSON.parse(local));
      return () => {};
    }
  }

  static async saveFocusSession(session: FocusSession): Promise<void> {
    try {
      await setDoc(doc(db, "workspaces", this.workspaceId, "focusSessions", session.id), session);
      await this.syncToPostgres("focus-sessions", "POST", session);
    } catch (err) {
      if (isPermissionError(err)) {
        handleFirestoreError(err, OperationType.WRITE, `workspaces/${this.workspaceId}/focusSessions/${session.id}`);
      }
      const sessions = JSON.parse(localStorage.getItem("focusSessions") || "[]");
      sessions.unshift(session);
      localStorage.setItem("focusSessions", JSON.stringify(sessions));
    }
  }
}
