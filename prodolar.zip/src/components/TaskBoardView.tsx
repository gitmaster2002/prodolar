import React, { useState } from "react";
import { 
  CheckSquare, 
  Square, 
  Clock, 
  Trash2, 
  FileText, 
  Flame, 
  Plus, 
  ExternalLink,
  ChevronDown,
  ChevronUp,
  BrainCircuit,
  Sliders,
  CheckCircle,
  Copy
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Task, SubTask } from "../types";

interface TaskBoardViewProps {
  tasks: Task[];
  onToggleTaskStatus: (taskId: string) => void;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  onDeleteTask: (taskId: string) => void;
  onUpdateTaskHours: (taskId: string, newHours: number) => void;
}

export default function TaskBoardView({ 
  tasks, 
  onToggleTaskStatus, 
  onToggleSubtask, 
  onDeleteTask,
  onUpdateTaskHours 
}: TaskBoardViewProps) {
  const [expandedTask, setExpandedTask] = useState<string | null>(null);
  const [activeDraft, setActiveDraft] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [learningFeedback, setLearningFeedback] = useState<string | null>(null);

  // Group tasks
  const pendingTasks = tasks.filter(t => t.status === "pending" && new Date(t.deadline).getTime() >= Date.now());
  const overdueTasks = tasks.filter(t => t.status === "pending" && new Date(t.deadline).getTime() < Date.now());
  const completedTasks = tasks.filter(t => t.status === "completed");

  const toggleExpand = (taskId: string) => {
    setExpandedTask(expandedTask === taskId ? null : taskId);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTuneHours = (taskId: string, currentHours: number, category: string) => {
    const tuneAmount = 1.5;
    const tunedHours = currentHours + tuneAmount;
    onUpdateTaskHours(taskId, tunedHours);
    
    // Simulate Adaptive learning trigger
    setLearningFeedback(
      `Adaptive Engine Tuned: Observed that you complete "${category}" tasks 30% slower than expected. Successfully increased future baseline estimates for "${category}" modules by +${tuneAmount} hours to guarantee safe deadline windows.`
    );
    setTimeout(() => setLearningFeedback(null), 6000);
  };

  return (
    <div className="space-y-6" id="taskboard-container">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-emerald-400" />
            <span>Active Task Matrix</span>
          </h1>
          <p className="text-xs text-gray-400">Manage deliverables, customize effort multipliers, and access AI-generated negotiator letters.</p>
        </div>
      </div>

      {learningFeedback && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400 text-xs flex items-center gap-2.5 shadow-lg"
          id="learning-feedback-toast"
        >
          <BrainCircuit className="w-4.5 h-4.5 shrink-0 animate-pulse text-emerald-400" />
          <span>{learningFeedback}</span>
        </motion.div>
      )}

      {/* Kanban Board Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="kanban-columns-grid">
        {/* Overdue Column */}
        <div className="glass-panel p-5 rounded-2xl flex flex-col space-y-4 border-t-2 border-rose-500" id="column-overdue">
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold text-white flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
              <span>Overdue Risk</span>
            </span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-rose-500/10 text-rose-400 font-bold border border-rose-500/10">
              {overdueTasks.length}
            </span>
          </div>

          <div className="space-y-3 pt-2">
            {overdueTasks.map(task => (
              <TaskCard 
                key={task.id} 
                task={task} 
                isExpanded={expandedTask === task.id}
                onToggleExpand={toggleExpand}
                onToggleStatus={onToggleTaskStatus}
                onToggleSubtask={onToggleSubtask}
                onDelete={onDeleteTask}
                onTuneHours={handleTuneHours}
                onViewDraft={setActiveDraft}
              />
            ))}
            {overdueTasks.length === 0 && (
              <div className="h-32 border border-dashed border-white/5 rounded-xl flex items-center justify-center text-center p-4">
                <span className="text-xs text-gray-500">No overdue tasks. Brilliant scheduling discipline!</span>
              </div>
            )}
          </div>
        </div>

        {/* Pending Column */}
        <div className="glass-panel p-5 rounded-2xl flex flex-col space-y-4 border-t-2 border-amber-500" id="column-pending">
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold text-white flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              <span>In Flight / Pending</span>
            </span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 font-bold border border-amber-500/10">
              {pendingTasks.length}
            </span>
          </div>

          <div className="space-y-3 pt-2">
            {pendingTasks.map(task => (
              <TaskCard 
                key={task.id} 
                task={task} 
                isExpanded={expandedTask === task.id}
                onToggleExpand={toggleExpand}
                onToggleStatus={onToggleTaskStatus}
                onToggleSubtask={onToggleSubtask}
                onDelete={onDeleteTask}
                onTuneHours={handleTuneHours}
                onViewDraft={setActiveDraft}
              />
            ))}
            {pendingTasks.length === 0 && (
              <div className="h-32 border border-dashed border-white/5 rounded-xl flex items-center justify-center text-center p-4">
                <span className="text-xs text-gray-500">All commitments clear. Open AI Planner to add goals.</span>
              </div>
            )}
          </div>
        </div>

        {/* Completed Column */}
        <div className="glass-panel p-5 rounded-2xl flex flex-col space-y-4 border-t-2 border-emerald-500" id="column-completed">
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold text-white flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>Completed</span>
            </span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-bold border border-emerald-500/10">
              {completedTasks.length}
            </span>
          </div>

          <div className="space-y-3 pt-2">
            {completedTasks.map(task => (
              <TaskCard 
                key={task.id} 
                task={task} 
                isExpanded={expandedTask === task.id}
                onToggleExpand={toggleExpand}
                onToggleStatus={onToggleTaskStatus}
                onToggleSubtask={onToggleSubtask}
                onDelete={onDeleteTask}
                onTuneHours={handleTuneHours}
                onViewDraft={setActiveDraft}
              />
            ))}
            {completedTasks.length === 0 && (
              <div className="h-32 border border-dashed border-white/5 rounded-xl flex items-center justify-center text-center p-4">
                <span className="text-xs text-gray-500">No completed tasks yet this cycle. Go start a focus block!</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Copyable Draft letter modal */}
      <AnimatePresence>
        {activeDraft && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" id="draft-modal">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-panel max-w-lg w-full p-6 rounded-2xl space-y-4 shadow-2xl relative"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-base font-semibold text-white flex items-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-400" />
                  <span>AI Negotiator Extension Pitch</span>
                </h3>
                <button
                  onClick={() => copyToClipboard(activeDraft)}
                  className="px-3 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all"
                  id="btn-copy-draft"
                >
                  {copied ? <CheckCircle className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? "Copied!" : "Copy Pitch"}</span>
                </button>
              </div>

              <p className="text-xs text-gray-400">
                This human-sounding rescheduling proposal has been generated based on your heavy schedule overlap and real-time workload calculations.
              </p>

              <pre className="p-4 rounded-xl bg-gray-950 border border-white/5 text-gray-300 font-mono text-xs whitespace-pre-wrap leading-relaxed max-h-[300px] overflow-y-auto">
                {activeDraft}
              </pre>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => setActiveDraft(null)}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 text-white rounded-xl text-xs font-semibold transition-all"
                  id="btn-close-draft"
                >
                  Dismiss
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Inner Task Card component
interface TaskCardProps {
  task: Task;
  isExpanded: boolean;
  onToggleExpand: (id: string) => void;
  onToggleStatus: (id: string) => void;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  onDelete: (id: string) => void;
  onTuneHours: (id: string, hours: number, category: string) => void;
  onViewDraft: (draft: string) => void;
  key?: string;
}

function TaskCard({
  task,
  isExpanded,
  onToggleExpand,
  onToggleStatus,
  onToggleSubtask,
  onDelete,
  onTuneHours,
  onViewDraft
}: TaskCardProps) {
  const isCompleted = task.status === "completed";
  const subtasksDone = task.subtasks.filter(s => s.status === "completed").length;
  const progressPercent = task.subtasks.length > 0 
    ? Math.round((subtasksDone / task.subtasks.length) * 100)
    : 0;

  // Determine priority background
  let pBg = "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
  if (task.priority === "high") {
    pBg = "bg-rose-500/10 text-rose-400 border-rose-500/20";
  } else if (task.priority === "medium") {
    pBg = "bg-amber-500/10 text-amber-400 border-amber-500/20";
  }

  return (
    <div className="p-4 rounded-xl border border-white/10 bg-gray-900/30 hover:bg-gray-900/60 transition-all flex flex-col gap-3" id={`task-card-${task.id}`}>
      <div className="flex items-start gap-3">
        <button 
          onClick={() => onToggleStatus(task.id)}
          className="mt-0.5 shrink-0 text-gray-500 hover:text-emerald-400 transition-colors"
          id={`btn-checkbox-${task.id}`}
        >
          {isCompleted ? (
            <CheckCircle className="w-5 h-5 text-emerald-500 fill-emerald-500/10" />
          ) : (
            <div className="w-5 h-5 rounded-md border border-white/20 flex items-center justify-center hover:border-emerald-500/40"></div>
          )}
        </button>

        <div className="space-y-1.5 flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className={`text-xs font-semibold truncate text-white ${isCompleted ? 'line-through opacity-50' : ''}`}>
              {task.title}
            </span>
            <span className={`text-[8px] px-1.5 py-0.2 rounded font-mono font-bold uppercase border ${pBg}`}>
              {task.priority}
            </span>
          </div>

          <p className={`text-[11px] text-gray-400 line-clamp-1 ${isCompleted ? 'opacity-40' : ''}`}>
            {task.description}
          </p>

          <div className="flex items-center gap-3 text-[10px] text-gray-500 font-mono">
            <span className="flex items-center gap-0.5">
              <Clock className="w-3 h-3 text-emerald-400" />
              <span>EST: {task.estimatedHours}h</span>
            </span>
            <span>•</span>
            <span>Probability: <span className={task.successProbability < 60 ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'}>{task.successProbability}%</span></span>
          </div>
        </div>
      </div>

      {/* Checklist and Controls Expanded */}
      <div className="space-y-3 pt-2.5 border-t border-white/5">
        <div className="flex items-center justify-between text-[10px] text-gray-400">
          <span>Subtask Progress</span>
          <span className="font-mono text-white font-medium">{subtasksDone}/{task.subtasks.length} ({progressPercent}%)</span>
        </div>
        <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden">
          <div 
            className="h-full bg-emerald-500 rounded-full transition-all duration-300" 
            style={{ width: `${progressPercent}%` }}
          ></div>
        </div>

        <div className="flex items-center justify-between gap-2">
          <button
            onClick={() => onToggleExpand(task.id)}
            className="text-[10px] text-gray-400 hover:text-white flex items-center gap-1 transition-colors"
            id={`btn-expand-${task.id}`}
          >
            {isExpanded ? (
              <>
                <ChevronUp className="w-3.5 h-3.5" />
                <span>Hide Subtasks</span>
              </>
            ) : (
              <>
                <ChevronDown className="w-3.5 h-3.5" />
                <span>Show Subtasks ({task.subtasks.length})</span>
              </>
            )}
          </button>

          <div className="flex gap-1">
            {task.extensionDraft && (
              <button
                onClick={() => onViewDraft(task.extensionDraft!)}
                className="p-1.5 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/10 transition-all"
                title="View extension template"
              >
                <FileText className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              onClick={() => onTuneHours(task.id, task.estimatedHours, task.category)}
              className="p-1.5 rounded bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/5 transition-all"
              title="Tune effort estimation"
            >
              <Sliders className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onDelete(task.id)}
              className="p-1.5 rounded bg-white/5 hover:bg-rose-500/10 text-gray-400 hover:text-rose-400 border border-white/5 transition-all"
              title="Delete obligation"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Nested Subtask Checklist */}
      {isExpanded && (
        <motion.div 
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="space-y-1.5 pl-5 pt-1 border-l border-white/5"
          id={`subtasks-expanded-${task.id}`}
        >
          {task.subtasks.map(sub => {
            const isSubDone = sub.status === "completed";
            return (
              <div key={sub.id} className="flex items-center justify-between text-[11px] py-1">
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => onToggleSubtask(task.id, sub.id)}
                    className="text-gray-500 hover:text-emerald-400 transition-colors"
                  >
                    {isSubDone ? (
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400/5" />
                    ) : (
                      <div className="w-3.5 h-3.5 rounded border border-white/20 hover:border-emerald-500/40"></div>
                    )}
                  </button>
                  <span className={`text-gray-300 ${isSubDone ? 'line-through opacity-50' : ''}`}>
                    {sub.title}
                  </span>
                </div>
                <span className="text-[9px] text-gray-500 font-mono font-medium">{sub.estimatedMinutes}m</span>
              </div>
            );
          })}
        </motion.div>
      )}
    </div>
  );
}
