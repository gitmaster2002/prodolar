import React, { useState } from "react";
import { 
  Sparkles, 
  Send, 
  Database, 
  UserCheck, 
  Calendar, 
  Layers, 
  TrendingDown, 
  Eye, 
  FileText,
  Upload,
  Bot,
  ListPlus,
  Play,
  CheckCircle,
  HelpCircle,
  Clock,
  ArrowRight
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Task, CalendarEvent, AgentStep, SystemContext } from "../types";

interface AIPlannerViewProps {
  onPlanGenerated: (newTasks: Task[]) => void;
  currentTasks: Task[];
  currentEvents: CalendarEvent[];
  context: SystemContext;
}

export default function AIPlannerView({ 
  onPlanGenerated, 
  currentTasks, 
  currentEvents, 
  context 
}: AIPlannerViewProps) {
  const [goalText, setGoalText] = useState("");
  const [loading, setLoading] = useState(false);
  const [agentSteps, setAgentSteps] = useState<AgentStep[]>([]);
  const [proposedTasks, setProposedTasks] = useState<Task[]>([]);
  const [coachAdvice, setCoachAdvice] = useState("");
  const [activeTab, setActiveTab] = useState<"natural" | "upload">("natural");

  // Multi-agent execution steps simulator (when API keys might be offline, or to provide visual progression)
  const runAgentPipeline = async (inputText: string) => {
    setLoading(true);
    setProposedTasks([]);
    setCoachAdvice("");

    // Initialize blank steps
    const initialSteps: AgentStep[] = [
      { agentName: "Planner", status: "idle", thought: "Awaiting instructions...", timestamp: new Date().toISOString() },
      { agentName: "Decomposer", status: "idle", thought: "Awaiting components...", timestamp: new Date().toISOString() },
      { agentName: "Priority", status: "idle", thought: "Awaiting priorities...", timestamp: new Date().toISOString() },
      { agentName: "Calendar", status: "idle", thought: "Awaiting free blocks...", timestamp: new Date().toISOString() },
      { agentName: "Execution", status: "idle", thought: "Awaiting negotiator metrics...", timestamp: new Date().toISOString() },
      { agentName: "Reflection", status: "idle", thought: "Awaiting scheduling state...", timestamp: new Date().toISOString() },
    ];
    setAgentSteps(initialSteps);

    try {
      // Calling Express Backend Agent Plan Endpoint
      const response = await fetch("/api/agent/plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          goalText: inputText,
          currentTasks,
          currentEvents,
          context
        })
      });

      if (!response.ok) throw new Error("Backend pipeline error");
      const data = await response.json();

      if (data.success && data.steps) {
        // We will animate the steps for the user to enjoy the multi-agent experience!
        for (let i = 0; i < data.steps.length; i++) {
          const step = data.steps[i];
          setAgentSteps(prev => {
            const copy = [...prev];
            const targetIdx = copy.findIndex(s => s.agentName === step.agentName);
            if (targetIdx > -1) {
              copy[targetIdx] = { ...step, status: "running" };
            }
            return copy;
          });
          
          await new Promise(resolve => setTimeout(resolve, 1000)); // Dramatic pause to look live!
          
          setAgentSteps(prev => {
            const copy = [...prev];
            const targetIdx = copy.findIndex(s => s.agentName === step.agentName);
            if (targetIdx > -1) {
              copy[targetIdx] = { ...step, status: "completed" };
            }
            return copy;
          });
        }

        setProposedTasks(data.tasks);
        setCoachAdvice(data.coachInsight);
      }
    } catch (err) {
      console.error(err);
      // Fallback
      setAgentSteps([]);
    } finally {
      setLoading(false);
    }
  };

  const handlePromptSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalText.trim()) return;
    runAgentPipeline(goalText);
  };

  const handleQuickTrigger = (text: string) => {
    setGoalText(text);
    runAgentPipeline(text);
  };

  // Syllabus Simulation Parsing
  const simulateSyllabusUpload = (type: "syllabus" | "photo") => {
    if (type === "syllabus") {
      setGoalText("Extract assignments and test milestones from uploaded PDF: 'Syllabus_Fall_2026.pdf'");
      runAgentPipeline("Extract key tasks from computer networks course syllabus: Assignment 1 due Thursday, Midterm Exam on Friday");
    } else {
      setGoalText("Extract tasks from photo upload: 'Handwritten_Assignments_Review.png'");
      runAgentPipeline("Analyze task screenshot: Finish Machine Learning backpropagation laboratory model. Estimate 4 hours. Priority High.");
    }
  };

  const applyProposedPlan = () => {
    if (proposedTasks.length === 0) return;
    onPlanGenerated(proposedTasks);
    setProposedTasks([]);
    setGoalText("");
    setAgentSteps([]);
  };

  return (
    <div className="space-y-6" id="planner-container">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-white">AI Executive Planner</h1>
          <p className="text-xs text-gray-400">Collaborating with multiple specialized AI agents to schedule, decompose, and negotiate your deadlines.</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab("natural")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${activeTab === "natural" ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-white/5 border-white/5 text-gray-400 hover:bg-white/10"}`}
          >
            Natural Language
          </button>
          <button
            onClick={() => setActiveTab("upload")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${activeTab === "upload" ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-white/5 border-white/5 text-gray-400 hover:bg-white/10"}`}
          >
            Syllabus / Photo Upload
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Input area */}
        <div className="lg:col-span-2 space-y-6">
          {activeTab === "natural" ? (
            <div className="glass-panel p-5 rounded-2xl space-y-4">
              <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Tell your assistant what you have coming up</span>
              </h2>
              
              <form onSubmit={handlePromptSubmit} className="space-y-3">
                <div className="relative">
                  <textarea
                    value={goalText}
                    onChange={(e) => setGoalText(e.target.value)}
                    placeholder="e.g. 'I have 4 assignments, 2 interviews, one flight to Delhi and a mock CAT exam prep coming up...'"
                    className="w-full bg-gray-900/60 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500/50 min-h-[120px] resize-none"
                    disabled={loading}
                  />
                  <div className="absolute bottom-3 right-3 text-xs text-gray-500">
                    Press send to trigger Multi-Agent loop
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-[10px] text-gray-500">
                    Guardian analyzes context: weather, battery, calendars
                  </span>
                  <button
                    type="submit"
                    disabled={loading || !goalText.trim()}
                    className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-500/20 disabled:text-emerald-500/40 text-white rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all shadow-md shadow-emerald-500/10"
                  >
                    {loading ? "Processing Loop..." : "Command Guardian"}
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </form>

              {/* Quick Prompt Triggers */}
              <div className="space-y-2 pt-2 border-t border-white/5">
                <span className="text-[10px] uppercase font-semibold tracking-wider text-gray-500">Quick Scenarios</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    onClick={() => handleQuickTrigger("I have an assignment due Friday on Distributed Systems")}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-left text-xs text-gray-300 transition-all flex items-center justify-between"
                  >
                    <span>"I have a Distributed Systems assignment..."</span>
                    <ArrowRight className="w-3 h-3 text-emerald-400" />
                  </button>
                  <button
                    onClick={() => handleQuickTrigger("I have 4 assignments, 2 interviews, one flight and CAT preparation.")}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-left text-xs text-gray-300 transition-all flex items-center justify-between"
                  >
                    <span>"4 assignments, 2 interviews, flight..."</span>
                    <ArrowRight className="w-3 h-3 text-emerald-400" />
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="glass-panel p-5 rounded-2xl space-y-4">
              <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                <Upload className="w-4 h-4 text-emerald-400" />
                <span>Upload Syllabus PDF or Assignment Photo</span>
              </h2>
              <p className="text-xs text-gray-400">
                Let Gemini parse the deadlines, assignment pages, and guidelines to build your schedule blocks automatically.
              </p>

              {/* Drag & Drop simulated box */}
              <div className="border-2 border-dashed border-white/10 rounded-2xl p-8 flex flex-col items-center justify-center space-y-3 bg-white/2">
                <FileText className="w-8 h-8 text-emerald-400" />
                <div className="text-center space-y-1">
                  <p className="text-xs text-gray-300 font-medium">Drag syllabus PDF or assignment screenshot here</p>
                  <p className="text-[10px] text-gray-500">Supports PDF, PNG, JPEG up to 10MB</p>
                </div>
                <button className="px-3 py-1.5 bg-white/5 border border-white/10 text-white rounded-lg text-xs font-medium hover:bg-white/10 transition-all">
                  Browse Files
                </button>
              </div>

              {/* Preloaded samples */}
              <div className="space-y-2 pt-2 border-t border-white/5">
                <span className="text-[10px] uppercase font-semibold tracking-wider text-gray-500">Or Simulate with Preloaded Samples</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div 
                    onClick={() => simulateSyllabusUpload("syllabus")}
                    className="p-3 rounded-xl bg-white/5 border border-white/5 hover:border-emerald-500/20 cursor-pointer transition-all flex items-center gap-3"
                  >
                    <FileText className="w-7 h-7 text-emerald-400 bg-emerald-500/10 p-1.5 rounded-lg" />
                    <div>
                      <p className="text-xs text-white font-medium">Syllabus_Fall_2026.pdf</p>
                      <p className="text-[10px] text-gray-500">Computer Networks Course</p>
                    </div>
                  </div>
                  <div 
                    onClick={() => simulateSyllabusUpload("photo")}
                    className="p-3 rounded-xl bg-white/5 border border-white/5 hover:border-emerald-500/20 cursor-pointer transition-all flex items-center gap-3"
                  >
                    <Upload className="w-7 h-7 text-blue-400 bg-blue-500/10 p-1.5 rounded-lg" />
                    <div>
                      <p className="text-xs text-white font-medium">Handwritten_Prompt_Review.png</p>
                      <p className="text-[10px] text-gray-500">Lab Assignment details photo</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Proposed schedule output */}
          {proposedTasks.length > 0 && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-panel p-5 rounded-2xl space-y-4"
              id="proposed-schedule-plan"
            >
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <h2 className="text-sm font-semibold text-white flex items-center gap-1.5">
                    <ListPlus className="w-4 h-4 text-emerald-400" />
                    <span>Proposed Schedule Blocks</span>
                  </h2>
                  <p className="text-xs text-gray-400">Review the tasks & calendar reservations designed by your Agent team.</p>
                </div>
                <button
                  onClick={applyProposedPlan}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md shadow-emerald-500/10 animate-pulse"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>Accept and Plan Calendar</span>
                </button>
              </div>

              {coachAdvice && (
                <div className="p-3 bg-emerald-500/5 border border-emerald-500/10 text-emerald-400 text-xs rounded-xl flex gap-2">
                  <Bot className="w-4 h-4 shrink-0 mt-0.5" />
                  <span><strong>Assistant Advice:</strong> {coachAdvice}</span>
                </div>
              )}

              <div className="space-y-3">
                {proposedTasks.map((task, idx) => (
                  <div key={idx} className="p-3.5 rounded-xl bg-white/5 border border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-white">{task.title}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono font-medium">
                          {task.energy === "high" ? "🔥 High Energy Peak" : task.energy === "medium" ? "⚡ Moderate Energy" : "✉️ Low Energy Routine"}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400">{task.description}</p>
                      
                      <div className="flex flex-wrap items-center gap-3 text-[10px] text-gray-500 font-mono">
                        <span>EST. HOURS: {task.estimatedHours}h</span>
                        <span>•</span>
                        <span>SUBTASKS: {task.subtasks.length}</span>
                        <span>•</span>
                        <span>CATEGORY: {task.category}</span>
                      </div>
                    </div>

                    <div className="shrink-0 flex flex-col items-end gap-1 text-right">
                      <span className="text-xs text-gray-400 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Reserved Block:</span>
                      </span>
                      {task.timeBlock ? (
                        <span className="text-xs font-semibold text-white bg-emerald-500/10 border border-emerald-500/20 px-2 py-1 rounded">
                          {new Date(task.timeBlock.start).toLocaleDateString()} {new Date(task.timeBlock.start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      ) : (
                        <span className="text-xs font-medium text-amber-400 italic">No free blocks found</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Draft letter */}
              {proposedTasks[0]?.extensionDraft && (
                <div className="space-y-2 pt-2 border-t border-white/5">
                  <h3 className="text-xs font-semibold text-white flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-rose-400" />
                    <span>AI Negotiator: Extension Request Drafted</span>
                  </h3>
                  <p className="text-xs text-gray-400">
                    Because success probability was estimated under 70%, the Negotiator Agent drafted this extension template for you:
                  </p>
                  <pre className="p-3 rounded-xl bg-gray-950 border border-white/5 text-gray-300 font-mono text-[11px] whitespace-pre-wrap leading-relaxed">
                    {proposedTasks[0].extensionDraft}
                  </pre>
                </div>
              )}
            </motion.div>
          )}
        </div>

        {/* Live Multi-Agent Thinking Pipeline Panel */}
        <div className="space-y-4">
          <div className="glass-panel p-5 rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-white flex items-center gap-1.5">
                <Bot className="w-4 h-4 text-emerald-400" />
                <span>Multi-Agent Operations</span>
              </h2>
              {loading && (
                <span className="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping"></span>
              )}
            </div>
            
            <p className="text-xs text-gray-400">
              Coordinated by Gemini to run task extraction, prioritizing, calendar conflict resolution, and reflective coaching loops.
            </p>

            <div className="relative border-l border-white/10 pl-4 ml-1.5 space-y-6 pt-2">
              {agentSteps.map((step, idx) => {
                const isRunning = step.status === "running";
                const isCompleted = step.status === "completed";
                const isIdle = step.status === "idle";

                let ringBg = "bg-gray-800 border-gray-700";
                let dotColor = "bg-gray-500";
                let titleColor = "text-gray-400";

                if (isRunning) {
                  ringBg = "bg-emerald-500/20 border-emerald-500";
                  dotColor = "bg-emerald-400 animate-pulse";
                  titleColor = "text-emerald-400 font-medium";
                } else if (isCompleted) {
                  ringBg = "bg-emerald-500/10 border-emerald-500/40";
                  dotColor = "bg-emerald-400";
                  titleColor = "text-white font-medium";
                }

                return (
                  <div key={idx} className="relative" id={`agent-step-${step.agentName}`}>
                    {/* Ring dot indicator */}
                    <div className={`absolute -left-[25px] top-1 w-4.5 h-4.5 rounded-full border flex items-center justify-center ${ringBg}`}>
                      <div className={`w-1.5 h-1.5 rounded-full ${dotColor}`}></div>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className={`text-xs ${titleColor}`}>{step.agentName} Agent</span>
                        {isCompleted && (
                          <span className="text-[9px] text-gray-500 font-mono">COMPLETE</span>
                        )}
                        {isRunning && (
                          <span className="text-[9px] text-emerald-400 font-mono animate-pulse">THINKING...</span>
                        )}
                      </div>
                      
                      {/* Thought process */}
                      <p className="text-[11px] text-gray-400 italic">
                        {step.thought}
                      </p>

                      {/* Output line if complete */}
                      {isCompleted && step.output && (
                        <p className="text-[11px] text-emerald-400 font-mono bg-emerald-500/5 p-1.5 rounded border border-emerald-500/10 mt-1">
                          ↳ {step.output}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}

              {agentSteps.length === 0 && (
                <div className="text-center py-10 text-gray-500 text-xs flex flex-col items-center gap-2">
                  <Bot className="w-8 h-8 opacity-40" />
                  <span>Awaiting instructions.<br/>Submit a goal to watch the agents execute.</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
