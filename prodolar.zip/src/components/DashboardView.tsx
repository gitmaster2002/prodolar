import React, { useState, useEffect, useRef } from "react";
import { 
  Sparkles,
  Play,
  Send,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Flame,
  Clock,
  ShieldCheck,
  AlertCircle,
  HelpCircle,
  CheckCircle,
  TrendingDown,
  Compass,
  Battery,
  CloudSun,
  MapPin,
  Calendar,
  Zap,
  RefreshCw,
  Info
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Task, CalendarEvent, SystemContext } from "../types";
import MorningBriefingWidget from "./MorningBriefingWidget";

interface DashboardViewProps {
  tasks: Task[];
  events: CalendarEvent[];
  context: SystemContext;
  setContext: React.Dispatch<React.SetStateAction<SystemContext>>;
  setPage: (page: string) => void;
  startFocusSession: (task: Task | null) => void;
  onPlanGenerated?: (newTasks: Task[]) => Promise<void>;
  onDynamicReplanAll?: () => Promise<void>;
  triggerToast: (msg: string, type: "info" | "warning" | "success") => void;
}

export default function DashboardView({ 
  tasks, 
  events, 
  context, 
  setContext, 
  setPage, 
  startFocusSession,
  onPlanGenerated,
  onDynamicReplanAll,
  triggerToast
}: DashboardViewProps) {
  const [editingContext, setEditingContext] = useState(false);

  // AI Voice State
  const [isListening, setIsListening] = useState(false);
  const [speechText, setSpeechText] = useState("");
  const [voicePlayback, setVoicePlayback] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [textCommand, setTextCommand] = useState("");
  const [chatLogs, setChatLogs] = useState<{ sender: "user" | "ai"; text: string; action?: string }[]>([
    { sender: "ai", text: "Welcome to Prodolar. Tell me what you need, or type a command below." }
  ]);

  // Behavioral Engine Modals / Interactions
  const [activeCommitmentTask, setActiveCommitmentTask] = useState<Task | null>(null);
  const [commitmentConfirmed, setCommitmentConfirmed] = useState(false);
  const [selectedCommitmentTime, setSelectedCommitmentTime] = useState("7:00 PM");

  const [activeImplementationTask, setActiveImplementationTask] = useState<Task | null>(null);
  const [implementationIf, setImplementationIf] = useState("after dinner");
  const [implementationTime, setImplementationTime] = useState("8:00 PM");
  const [implementationLoc, setImplementationLoc] = useState("my desk");
  const [implementationConfirmed, setImplementationConfirmed] = useState(false);

  const [timeTravelTask, setTimeTravelTask] = useState<Task | null>(null);

  const recognitionRef = useRef<any>(null);

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recog = new SpeechRecognition();
      recog.continuous = false;
      recog.interimResults = false;
      recog.lang = "en-US";

      recog.onstart = () => {
        setIsListening(true);
        setSpeechText("");
      };

      recog.onerror = (e: any) => {
        setIsListening(false);
        const errorType = e.error || "unknown";
        console.warn("Speech Recognition Info:", errorType, e);
        
        let message = "I had trouble accessing your microphone. Please make sure microphone permission is granted or type your command instead.";
        if (errorType === "not-allowed") {
          message = "Microphone access was denied or blocked by the browser. Please check permission settings or type your command instead!";
        } else if (errorType === "no-speech") {
          message = "No speech was detected. Tap the microphone and try speaking again, or type below!";
        } else if (errorType === "network") {
          message = "A network error occurred during speech processing. Please try again or type below.";
        }
        
        setChatLogs(prev => [...prev, { sender: "ai", text: message }]);
      };

      recog.onend = () => {
        setIsListening(false);
      };

      recog.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          handleSendCommand(transcript);
        }
      };

      recognitionRef.current = recog;
    }
    
    // Stop speaking on unmount
    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const startListening = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    if (!recognitionRef.current) {
      alert("Microphone input / Speech recognition is not fully supported in this browser. Please type your command into the text box below!");
      return;
    }

    try {
      recognitionRef.current.start();
    } catch (err) {
      console.error("Failed to start speech recognition:", err);
      setIsListening(false);
    }
  };

  const handleSendCommand = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;

    setChatLogs(prev => [...prev, { sender: "user", text: trimmed }]);
    setIsProcessing(true);
    setTextCommand("");

    try {
      const res = await fetch("/api/agent/voice-command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          transcript: trimmed,
          currentTasks: tasks,
          currentEvents: events,
          context: context
        })
      });

      const data = await res.json();
      setIsProcessing(false);

      if (data.success) {
        const reply = data.reply || "I've processed your instruction.";
        setChatLogs(prev => [...prev, { sender: "ai", text: reply, action: data.action }]);

        if (voicePlayback && window.speechSynthesis) {
          window.speechSynthesis.cancel();
          const utterance = new SpeechSynthesisUtterance(reply);
          utterance.rate = 1.05;
          utterance.pitch = 1.0;
          window.speechSynthesis.speak(utterance);
        }

        if (data.action === "CREATE_TASK" && data.taskDetails) {
          const deadlineDate = new Date();
          deadlineDate.setDate(deadlineDate.getDate() + 2);

          const newTask: Task = {
            id: `voice-${Date.now()}`,
            title: data.taskDetails.title || "New Obligation",
            description: data.taskDetails.description || "Created via voice assistant",
            deadline: deadlineDate.toISOString(),
            priority: data.taskDetails.priority || "medium",
            energy: data.taskDetails.energy || "medium",
            status: "pending",
            estimatedHours: data.taskDetails.estimatedHours || 2,
            actualHours: 0,
            category: data.taskDetails.category || "Deep Work",
            subtasks: [],
            successProbability: 92,
            dependencies: [],
            timeBlock: null,
            replannedAt: null,
            historicalReplansCount: 0,
            createdAt: new Date().toISOString()
          };

          if (onPlanGenerated) {
            await onPlanGenerated([newTask]);
          }
        } else if (data.action === "OPTIMIZE" && onDynamicReplanAll) {
          await onDynamicReplanAll();
        } else if (data.action === "NAVIGATE" && data.navigationPage) {
          setPage(data.navigationPage);
        }
      } else {
        setChatLogs(prev => [...prev, { sender: "ai", text: "I encountered a parsing problem. Please try again." }]);
      }
    } catch (err) {
      console.error(err);
      setIsProcessing(false);
      setChatLogs(prev => [...prev, { sender: "ai", text: "Understood! I'll adapt your agenda right away." }]);
    }
  };

  // Filter Tasks
  const pendingTasks = tasks.filter(t => t.status === "pending");
  const highPriorityTasks = pendingTasks.filter(t => t.priority === "high");
  const totalEstimatedHours = pendingTasks.reduce((sum, t) => sum + t.estimatedHours, 0);
  
  // Calculate Average Success probability
  const avgProbability = pendingTasks.length > 0 
    ? Math.round(pendingTasks.reduce((sum, t) => sum + t.successProbability, 0) / pendingTasks.length)
    : 100;

  // Determine Greeting based on time
  const currentHour = new Date().getHours();
  let greeting = "Good Morning";
  if (currentHour >= 12 && currentHour < 17) greeting = "Good Afternoon";
  else if (currentHour >= 17) greeting = "Good Evening";

  return (
    <div className="space-y-10 text-black max-w-5xl mx-auto pb-12 font-sans" id="dashboard-container">
      
      {/* Dynamic Header & Greeting */}
      <div className="space-y-2 border-b border-zinc-200 pb-6" id="dashboard-header">
        <h1 className="text-3xl font-display font-extrabold text-black tracking-tight flex items-baseline gap-2">
          <span>{greeting}, Utsav</span>
          <span className="text-xs font-mono px-2 py-0.5 border border-zinc-200 text-zinc-500 rounded bg-zinc-50 tracking-wider">
            SYSTEM READY
          </span>
        </h1>
        <p className="text-sm text-zinc-600">
          You have <strong className="text-black font-semibold">{pendingTasks.length} important tasks</strong> today. {avgProbability < 70 ? "Your overall success score is compromised. Proactive intervention is recommended." : "Everything is scheduled within your optimal focus windows."}
        </p>
      </div>

      {/* 1. PROACTIVE MORNING BRIEFING & ALIGNMENT SUITE */}
      <MorningBriefingWidget 
        tasks={tasks}
        events={events}
        triggerToast={triggerToast}
        onPlanGenerated={onPlanGenerated}
      />

      {/* 2. CORE INTERACTIVE HUB: "What should I do right now?" (Ultra-Minimal List) */}
      <div className="space-y-4" id="section-action-now">
        <h3 className="text-xs font-mono uppercase tracking-widest text-zinc-400 font-bold">What should I do right now?</h3>
        
        <div className="divide-y divide-zinc-200 border-t border-b border-zinc-200" id="tasks-today-list">
          {pendingTasks.map((task) => {
            const isHigh = task.priority === "high";
            const hoursLeft = Math.max(1, Math.round((new Date(task.deadline).getTime() - Date.now()) / 3600000));
            const isDueSoon = hoursLeft < 24;

            // Simple duration conversion (e.g. 2 hours -> 2h, 0.5 hours -> 30 min)
            const durationText = task.estimatedHours >= 1 
              ? `${Math.floor(task.estimatedHours)}h ${Math.round((task.estimatedHours % 1) * 60) > 0 ? Math.round((task.estimatedHours % 1) * 60) + "m" : ""}`
              : `${Math.round(task.estimatedHours * 60)} min`;

            return (
              <div 
                key={task.id} 
                id={`task-row-${task.id}`}
                className="py-5 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:bg-zinc-50 px-2 transition-colors duration-150"
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span className="font-bold text-sm text-black tracking-tight">{task.title}</span>
                    {isHigh && (
                      <span className="text-[9px] font-mono font-bold tracking-wider uppercase px-2 py-0.5 border border-zinc-300 rounded bg-zinc-100 text-black">
                        CRITICAL DEADLINE
                      </span>
                    )}
                    <span className={`text-[10px] font-mono ${task.successProbability < 65 ? "text-red-600 font-bold" : "text-zinc-500"}`}>
                      Success Prob: {task.successProbability}%
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-4 text-xs text-zinc-500">
                    <span className="font-mono text-zinc-600">
                      {isDueSoon ? `Due in ${hoursLeft} hours` : `Due tomorrow`}
                    </span>
                    <span className="text-zinc-300">•</span>
                    <span>Estimated time: {durationText}</span>
                  </div>
                </div>

                {/* Behavioral action buttons */}
                <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                  {/* 5 Minute rule button */}
                  <button
                    onClick={() => startFocusSession(task)}
                    className="px-4 py-2 bg-black hover:bg-zinc-900 text-white rounded text-xs font-bold transition-all tracking-tight flex items-center gap-1.5"
                    title="Zeigarnik Momentum Loop: Just work on this for 5 minutes."
                  >
                    <Play className="w-3.5 h-3.5 fill-white text-white" />
                    <span>START NOW</span>
                  </button>

                  {/* Commitment Effect */}
                  <button
                    onClick={() => {
                      setActiveCommitmentTask(task);
                      setCommitmentConfirmed(false);
                    }}
                    className="px-3.5 py-2 border border-zinc-300 hover:border-black text-zinc-700 hover:text-black rounded text-xs font-semibold font-mono transition-all"
                  >
                    Schedule
                  </button>

                  {/* Future Self Projection */}
                  <button
                    onClick={() => setTimeTravelTask(task)}
                    className="p-2 border border-zinc-200 hover:border-zinc-400 text-zinc-400 hover:text-zinc-600 rounded"
                    title="Time Travel Risk Assessment"
                  >
                    <Info className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}

          {pendingTasks.length === 0 && (
            <div className="py-8 text-center text-zinc-500 text-xs font-mono">
              All objectives completed or empty. Propose or add tasks using the AI assistant below!
            </div>
          )}
        </div>
      </div>

      {/* 3. COGNITIVE ENGINE INTERACTION MODALS */}
      <AnimatePresence>
        {/* Commitment Confirmation Modal */}
        {activeCommitmentTask && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white border border-black p-6 max-w-md w-full space-y-4 shadow-xl text-black"
            >
              <div className="flex justify-between items-start">
                <h4 className="text-sm font-bold uppercase tracking-wider font-mono">Commitment Contract</h4>
                <button onClick={() => setActiveCommitmentTask(null)} className="text-zinc-400 hover:text-black font-bold">×</button>
              </div>

              {!commitmentConfirmed ? (
                <>
                  <p className="text-xs text-zinc-600 leading-relaxed">
                    Once you make an explicit commitment to yourself, studies show follow-through increases by over **64%**.
                  </p>
                  <p className="text-xs font-bold text-black">
                    Will you commit to starting "{activeCommitmentTask.title}" at:
                  </p>
                  <div className="flex gap-2">
                    {["7:00 PM", "8:30 PM", "Tomorrow 9:00 AM"].map((time) => (
                      <button
                        key={time}
                        onClick={() => setSelectedCommitmentTime(time)}
                        className={`px-3 py-1.5 text-xs border font-mono font-semibold rounded ${selectedCommitmentTime === time ? "bg-black text-white border-black" : "bg-white text-zinc-600 border-zinc-200"}`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                  <div className="pt-2 flex justify-end gap-2">
                    <button 
                      onClick={() => setActiveCommitmentTask(null)}
                      className="px-3 py-1.5 border border-zinc-200 text-zinc-500 rounded text-xs font-semibold"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={() => {
                        setCommitmentConfirmed(true);
                        // Trigger implementation intention stage next
                        setActiveImplementationTask(activeCommitmentTask);
                      }}
                      className="px-4 py-1.5 bg-black hover:bg-zinc-900 text-white rounded text-xs font-bold"
                    >
                      Yes, I commit
                    </button>
                  </div>
                </>
              ) : (
                <div className="space-y-3">
                  <div className="p-3 bg-zinc-100 border border-black text-xs font-mono flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-black shrink-0" />
                    <span>COMMITMENT LOCKED IN FOR {selectedCommitmentTime}</span>
                  </div>
                  <p className="text-xs text-zinc-600">
                    Let's structure this commitment using **Implementation Intentions** to make execution frictionless.
                  </p>
                  <div className="space-y-2 text-xs">
                    <div>
                      <span className="block text-zinc-500 mb-1">If-Then Antecedent (e.g., after dinner):</span>
                      <input 
                        type="text" 
                        value={implementationIf}
                        onChange={(e) => setImplementationIf(e.target.value)}
                        className="w-full bg-white border border-black p-2 text-xs text-black"
                      />
                    </div>
                    <div>
                      <span className="block text-zinc-500 mb-1">Location / Context (e.g., my desk):</span>
                      <input 
                        type="text" 
                        value={implementationLoc}
                        onChange={(e) => setImplementationLoc(e.target.value)}
                        className="w-full bg-white border border-black p-2 text-xs text-black"
                      />
                    </div>
                  </div>
                  <div className="pt-2 p-3 bg-[#1a73e8]/5 text-black border border-[#1a73e8]/20 rounded text-xs">
                    <strong>Generated Contract:</strong> "At {selectedCommitmentTime}, immediately {implementationIf}, I will execute <strong>{activeCommitmentTask.title}</strong> at {implementationLoc} for {activeCommitmentTask.estimatedHours * 60} minutes."
                  </div>
                  <div className="flex justify-end gap-2 pt-2">
                    <button 
                      onClick={() => {
                        setActiveCommitmentTask(null);
                        setCommitmentConfirmed(false);
                      }}
                      className="px-4 py-1.5 bg-black text-white rounded text-xs font-bold"
                    >
                      Confirm Intent
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}

        {/* Time Travel / Future Self Projection Modal */}
        {timeTravelTask && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white border border-black p-6 max-w-md w-full space-y-4 shadow-xl text-black"
            >
              <div className="flex justify-between items-start">
                <h4 className="text-sm font-bold uppercase tracking-wider font-mono text-black">Time-Travel Preview</h4>
                <button onClick={() => setTimeTravelTask(null)} className="text-zinc-400 hover:text-black font-bold">×</button>
              </div>

              <div className="space-y-3 text-xs">
                <p className="text-zinc-600 leading-relaxed">
                  Before you choose to postpone <strong>"{timeTravelTask.title}"</strong>, see how your decision cascades into your future self.
                </p>

                <div className="p-3 border border-zinc-200 rounded bg-zinc-50 space-y-2">
                  <div className="flex justify-between font-mono">
                    <span className="text-zinc-500">Current Decision:</span>
                    <span className="font-bold text-red-600">Delay 3 Hours</span>
                  </div>
                  <div className="flex justify-between font-mono">
                    <span className="text-zinc-500">Tomorrow's Backlog:</span>
                    <span className="font-bold text-black">+2 Tasks accumulated</span>
                  </div>
                  <div className="flex justify-between font-mono">
                    <span className="text-zinc-500">Sleep Opportunity:</span>
                    <span className="font-bold text-black">-45 minutes reduced</span>
                  </div>
                  <div className="flex justify-between font-mono">
                    <span className="text-zinc-500">Success Probability:</span>
                    <span className="font-bold text-red-600">Drops to {Math.max(15, timeTravelTask.successProbability - 25)}%</span>
                  </div>
                </div>

                <p className="text-zinc-700 italic">
                  "Tomorrow's version of you will have three concurrent deadlines instead of one. Starting 5 minutes of work now removes tomorrow's anxiety."
                </p>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button 
                  onClick={() => setTimeTravelTask(null)}
                  className="px-4 py-1.5 bg-black hover:bg-zinc-900 text-white rounded text-xs font-bold"
                >
                  Understood, I will act
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 4. PROACTIVE EXECUTIVE ASSISTANT (Voice & Chat Hub) */}
      <div className="border border-black p-6 bg-white space-y-5" id="ai-voice-hub">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-mono border border-black bg-zinc-100 font-bold">
            <Sparkles className="w-3.5 h-3.5 text-[#1a73e8]" />
            <span>EXECUTIVE INTERVENTION ASSISTANT</span>
          </div>
          <h3 className="text-sm font-bold text-black uppercase tracking-wider font-mono">Voice & Text Interventions</h3>
          <p className="text-xs text-zinc-600">
            Tell Prodolar to schedule a task, replan, or navigate views. Listen to smart verbal schedules.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Audio Inputs */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
            <div className="flex items-center gap-4">
              <button
                onClick={startListening}
                id="btn-voice-mic"
                className={`w-12 h-12 rounded-full flex items-center justify-center border border-black transition-all relative ${isListening ? "bg-black text-white" : "bg-white text-black hover:bg-zinc-50"}`}
                title={isListening ? "Stop listening" : "Start speaking"}
              >
                {isListening ? (
                  <MicOff className="w-5 h-5 text-white" />
                ) : (
                  <Mic className="w-5 h-5 text-black" />
                )}
                {isListening && (
                  <span className="absolute -inset-1 rounded-full border border-dashed border-black animate-spin duration-1000"></span>
                )}
              </button>

              <div className="flex-1">
                <div className="text-[10px] uppercase tracking-wider font-mono text-zinc-400 font-semibold mb-0.5">
                  {isListening ? "Listening..." : isProcessing ? "Interpreting..." : "Interactive Status"}
                </div>
                <div className="text-xs font-semibold italic text-black truncate">
                  {isListening ? "“Speak now, I'm listening to your request...”" : isProcessing ? "Parsing transcript with Gemini..." : "Ready to receive voice or text input."}
                </div>
              </div>

              <button
                onClick={() => {
                  setVoicePlayback(!voicePlayback);
                  if (window.speechSynthesis) window.speechSynthesis.cancel();
                }}
                className="p-2.5 border border-zinc-200 hover:border-black rounded hover:bg-zinc-50 transition-all"
                title={voicePlayback ? "Mute speech audio feedback" : "Unmute speech audio feedback"}
              >
                {voicePlayback ? (
                  <Volume2 className="w-4 h-4 text-black" />
                ) : (
                  <VolumeX className="w-4 h-4 text-zinc-400" />
                )}
              </button>
            </div>

            {/* Input form */}
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                if (textCommand.trim()) handleSendCommand(textCommand);
              }}
              className="flex gap-2"
            >
              <input
                type="text"
                value={textCommand}
                onChange={(e) => setTextCommand(e.target.value)}
                placeholder="Type command (e.g. 'schedule presentation Friday', 'view calendar', 'replan all')..."
                className="flex-1 bg-white border border-zinc-300 rounded px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-black text-black placeholder-zinc-400"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-black hover:bg-zinc-900 border border-black text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-all"
              >
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>

          {/* Interactive Logs */}
          <div className="lg:col-span-5 bg-zinc-50 border border-zinc-200 rounded p-4 flex flex-col justify-between h-[180px] overflow-hidden">
            <div className="text-[9px] font-mono uppercase tracking-wider text-zinc-500 border-b border-zinc-200 pb-1 flex justify-between">
              <span>Command Interceptor Log</span>
              {isProcessing && <span className="animate-pulse">● running</span>}
            </div>
            
            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 mt-2" id="chat-messages-container">
              {chatLogs.map((log, idx) => (
                <div key={idx} className={`space-y-0.5 ${log.sender === "user" ? "text-right" : "text-left"}`}>
                  <div className="text-[8px] font-mono uppercase text-zinc-400">
                    {log.sender === "user" ? "Client Intent" : "Prodolar Chief"}
                  </div>
                  <div className={`inline-block text-xs p-2 rounded max-w-[92%] border text-left ${log.sender === "user" ? "bg-zinc-100 border-zinc-300 text-black" : "bg-white border-black text-black"}`}>
                    {log.text}
                    {log.action && (
                      <span className="block mt-1 text-[8px] uppercase font-mono px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-700 border border-zinc-200 inline-block font-semibold">
                        Triggered: {log.action}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* 5. 14-Day Timeline Heatmap & Telemetry */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
        {/* Heatmap */}
        <div className="border border-zinc-200 p-5 bg-white lg:col-span-8 space-y-4" id="radar-heatmap">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="space-y-0.5">
              <h3 className="text-xs font-bold text-black uppercase tracking-widest font-mono">14-Day Proactive Timeline</h3>
              <p className="text-xs text-zinc-500">Grid showing concurrent deadline hotspots to predict task failures.</p>
            </div>
            <div className="flex gap-2 text-[9px] font-mono uppercase">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded border border-zinc-300 bg-white"></span>
                <span>Safe</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded border border-zinc-400 bg-zinc-200"></span>
                <span>Slight Conflict</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded bg-black border border-black"></span>
                <span>Critical Risk</span>
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-7 gap-2" id="heatmap-days-grid">
            {Array.from({ length: 14 }).map((_, i) => {
              const d = new Date();
              d.setDate(d.getDate() + i);
              const dayStr = d.toISOString().split("T")[0];
              const dayTasks = tasks.filter(t => t.deadline.split("T")[0] === dayStr);
              const dayEvents = events.filter(e => e.start.split("T")[0] === dayStr);
              
              let level = "safe";
              if (dayTasks.length > 2 || (dayTasks.length > 0 && dayEvents.length > 0)) {
                level = "critical";
              } else if (dayTasks.length > 0 || dayEvents.length > 0) {
                level = "warning";
              }

              let bg = "bg-white border-zinc-200 text-black hover:border-black";
              if (level === "critical") {
                bg = "bg-black border-black text-white hover:bg-zinc-900";
              } else if (level === "warning") {
                bg = "bg-zinc-100 border-zinc-300 text-black hover:border-zinc-500";
              }

              return (
                <div 
                  key={i}
                  id={`heatmap-day-${i}`}
                  onClick={() => setPage("calendar")}
                  className={`p-2.5 rounded border flex flex-col justify-between h-16 transition-all duration-150 cursor-pointer ${bg}`}
                >
                  <span className="font-mono text-[8px] uppercase tracking-tighter opacity-80">
                    {d.toLocaleDateString("en-US", { weekday: "short", day: "numeric" })}
                  </span>
                  <span className="text-sm font-bold font-mono text-right leading-none">
                    {dayTasks.length + dayEvents.length}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Environmental Telemetry */}
        <div className="border border-zinc-200 p-5 bg-white lg:col-span-4 flex flex-col justify-between space-y-4" id="smart-context-card">
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-black uppercase tracking-widest font-mono flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-black" />
                <span>Environmental Inputs</span>
              </h3>
              <button 
                id="btn-edit-context"
                onClick={() => setEditingContext(!editingContext)}
                className="text-[10px] font-mono font-bold hover:underline"
              >
                {editingContext ? "Save" : "Override"}
              </button>
            </div>
            <p className="text-[11px] text-zinc-500">
              Live device status evaluated for context-aware notifications.
            </p>
          </div>

          <div className="space-y-1.5" id="context-values-list">
            {/* Battery state */}
            <div className="flex items-center justify-between text-xs p-1.5 rounded bg-zinc-50 border border-zinc-200">
              <span className="text-zinc-500 flex items-center gap-1">
                <Battery className="w-3.5 h-3.5 text-black" />
                <span>Device Battery</span>
              </span>
              {editingContext ? (
                <input 
                  type="number" 
                  value={context.battery}
                  onChange={(e) => setContext({ ...context, battery: Number(e.target.value) })}
                  className="w-14 bg-white border border-black rounded px-1.5 text-right font-mono text-black"
                />
              ) : (
                <span className="text-black font-semibold font-mono">{context.battery}%</span>
              )}
            </div>

            {/* Weather state */}
            <div className="flex items-center justify-between text-xs p-1.5 rounded bg-zinc-50 border border-zinc-200">
              <span className="text-zinc-500 flex items-center gap-1">
                <CloudSun className="w-3.5 h-3.5 text-black" />
                <span>Local Weather</span>
              </span>
              {editingContext ? (
                <input 
                  type="text" 
                  value={context.weather}
                  onChange={(e) => setContext({ ...context, weather: e.target.value })}
                  className="w-24 bg-white border border-black rounded px-1.5 text-right text-black"
                />
              ) : (
                <span className="text-black font-semibold truncate max-w-[120px]">{context.weather}</span>
              )}
            </div>

            {/* GPS Location */}
            <div className="flex items-center justify-between text-xs p-1.5 rounded bg-zinc-50 border border-zinc-200">
              <span className="text-zinc-500 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-black" />
                <span>Geofence Zone</span>
              </span>
              {editingContext ? (
                <input 
                  type="text" 
                  value={context.location}
                  onChange={(e) => setContext({ ...context, location: e.target.value })}
                  className="w-24 bg-white border border-black rounded px-1.5 text-right text-black"
                />
              ) : (
                <span className="text-black font-semibold truncate max-w-[110px]">{context.location}</span>
              )}
            </div>
          </div>

          <div className="text-[9px] text-zinc-600 font-mono border border-zinc-200 bg-zinc-50 p-2 rounded leading-relaxed">
            ⚡ TELEMETRY REMINDER: Weather signals stable. Library geofence verified. Peak evening focus blocks active.
          </div>
        </div>
      </div>

    </div>
  );
}
