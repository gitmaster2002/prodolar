import React, { useState, useEffect, useRef } from "react";
import { 
  Bot, 
  Send, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  RefreshCw, 
  LogIn, 
  LogOut, 
  Smartphone, 
  ShieldCheck, 
  ShieldAlert,
  PhoneCall, 
  PhoneOff, 
  MessageSquare, 
  AlertTriangle, 
  Search,
  Eye, 
  Play, 
  Square, 
  CheckCircle, 
  User,
  ExternalLink,
  Flame,
  Info
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { auth } from "../lib/firebase";
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut, 
  onAuthStateChanged,
  User as FirebaseUser
} from "firebase/auth";
import { Task, CalendarEvent } from "../types";

interface AILoungeViewProps {
  tasks: Task[];
  events: CalendarEvent[];
  triggerToast: (msg: string, type: "info" | "warning" | "success") => void;
  onPlanGenerated?: (newTasks: Task[]) => Promise<void>;
}

interface Message {
  sender: "user" | "ai";
  text: string;
  searchResults?: { title: string; uri: string }[];
  isThinking?: boolean;
}

export default function AILoungeView({ 
  tasks, 
  events, 
  triggerToast,
  onPlanGenerated 
}: AILoungeViewProps) {
  // Authentication State
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);

  // Chat Configuration
  const [chatRole, setChatRole] = useState<"Chief" | "Guilt" | "Stoic" | "FOMO">("Chief");
  const [lowLatency, setLowLatency] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [searchGrounding, setSearchGrounding] = useState(false);

  // Chat Interface State
  const [messages, setMessages] = useState<Message[]>([
    { 
      sender: "ai", 
      text: "Prodolar Executive AI Online. I've mapped your academic deadlines and calendar. What needs executing?" 
    }
  ]);
  const [inputText, setInputText] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Voice / Phone Call Simulation State
  const [isCallActive, setIsCallActive] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [isSpeechListening, setIsSpeechListening] = useState(false);
  const [currentSpeechTranscript, setCurrentSpeechTranscript] = useState("");
  const [speechOutputMuted, setSpeechOutputMuted] = useState(false);
  const recognitionRef = useRef<any>(null);
  const callTimerRef = useRef<any>(null);

  // Custom Audio Recorder / Transcriber State
  const [isRecordingAudio, setIsRecordingAudio] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [transcribedText, setTranscribedText] = useState("");
  const [isTranscribing, setIsTranscribing] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Android Simulated Background Tracker State
  const [trackerActive, setTrackerActive] = useState(true);
  const [psychoSetting, setPsychoSetting] = useState<"PassiveAggressive" | "Severe" | "Gentle">("PassiveAggressive");
  const [phoneAppLogs, setPhoneAppLogs] = useState<Array<{ id: string; time: string; app: string; intervention: string; action: "Blocked" | "Warned" | "Allowed" }>>([
    {
      id: "log-1",
      time: "2:40 PM",
      app: "Instagram Reels",
      intervention: "Reels opened. Warning: 'Utsav, Distributed Consensus Paper success rate is at 42%. You have not read Paxos yet. Put down the device.'",
      action: "Warned"
    },
    {
      id: "log-2",
      time: "2:15 PM",
      app: "YouTube",
      intervention: "Dev videos opened. Blocked. Redirected to backprop derivation sheet.",
      action: "Blocked"
    },
    {
      id: "log-3",
      time: "1:30 PM",
      app: "LinkedIn",
      intervention: "Urgent check-in. Allowed. 'Keep graph practice focused on tomorrow's Google check-in.'",
      action: "Allowed"
    }
  ]);

  // Handle Firebase Auth listening
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  // Web Speech recognition setup for Live Calling
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recog = new SpeechRecognition();
      recog.continuous = true;
      recog.interimResults = true;
      recog.lang = "en-US";

      recog.onstart = () => {
        setIsSpeechListening(true);
      };

      recog.onerror = (e: any) => {
        console.warn("Speech Error:", e);
      };

      recog.onend = () => {
        setIsSpeechListening(false);
      };

      recog.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0])
          .map((result: any) => result.transcript)
          .join("");
        
        setCurrentSpeechTranscript(transcript);

        // Process speech after brief silence or single phrase
        const lastResult = event.results[event.results.length - 1];
        if (lastResult.isFinal) {
          handleVoiceCommandInput(lastResult[0].transcript);
        }
      };

      recognitionRef.current = recog;
    }

    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, [tasks, events]);

  // Scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isGenerating]);

  // Call timer simulation
  useEffect(() => {
    if (isCallActive) {
      callTimerRef.current = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    } else {
      clearInterval(callTimerRef.current);
      setCallDuration(0);
    }
    return () => clearInterval(callTimerRef.current);
  }, [isCallActive]);

  // Google Sign-In with popup
  const handleSignIn = async () => {
    setIsSigningIn(true);
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
      triggerToast("Logged in successfully with Google!", "success");
    } catch (error: any) {
      console.error("Sign-In failed:", error);
      triggerToast("Google Sign-In failed or was cancelled.", "warning");
    } finally {
      setIsSigningIn(false);
    }
  };

  // Google Sign Out
  const handleSignOut = async () => {
    try {
      await signOut(auth);
      triggerToast("Logged out of Google account.", "info");
    } catch (error: any) {
      console.error("Sign-Out failed:", error);
    }
  };

  // System Instruction according to selected psychiatric role
  const getSystemInstruction = () => {
    const base = "You are Prodolar, an extreme AI Chief of Staff. You do not cheer users up, you push them to avoid catastrophic failure. You analyze the user's tasks and provide psychological, urgent interventions.";
    switch (chatRole) {
      case "Chief":
        return `${base} Focus on structural scheduling, direct task execution, and Zeigarnik effect (reducing friction to start immediately). Use a professional, highly firm, crisp, and no-excuses tone.`;
      case "Guilt":
        return `${base} Focus heavily on guilt-tripping the user. Remind them how their procrastination affects their parents, friends, peer competition, and their own future self. Frame every delay as let-down.`;
      case "Stoic":
        return `${base} Adopt the persona of a hardened Stoic Military Commander. Apply rigid logic, cold truths, and zero-compromise discipline. Action is the only reality.`;
      case "FOMO":
        return `${base} Focus on Loss-Framed calculations. Tell the user exactly what they will miss (failing the course, getting locked out of the recruitment pipeline, working at 4 AM under extreme fatigue). Build immediate urgency.`;
    }
  };

  // Standard multi-turn chat generation
  const handleSendMessage = async () => {
    const trimmed = inputText.trim();
    if (!trimmed || isGenerating) return;

    const userMessage: Message = { sender: "user", text: trimmed };
    setMessages(prev => [...prev, userMessage]);
    setInputText("");
    setIsGenerating(true);

    // Prepare history payload mapping
    // Exclude initial prompt and current user message from previous history
    const historyPayload = messages.slice(1).map(m => ({
      role: m.sender === "user" ? "user" : "model",
      text: m.text
    }));

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: trimmed,
          history: historyPayload,
          lowLatency,
          thinking,
          searchGrounding,
          systemInstruction: getSystemInstruction()
        })
      });

      const data = await response.json();
      if (data.text) {
        setMessages(prev => [...prev, { 
          sender: "ai", 
          text: data.text, 
          searchResults: data.searchResults 
        }]);
      } else {
        setMessages(prev => [...prev, { 
          sender: "ai", 
          text: "My neural relays stalled. Try prompting me again." 
        }]);
      }
    } catch (error) {
      console.error("Chat error:", error);
      triggerToast("Failed to secure AI chat response", "warning");
    } finally {
      setIsGenerating(false);
    }
  };

  // Transcription Microphone Recorder Start/Stop
  const toggleAudioRecording = async () => {
    if (isRecordingAudio) {
      // Stop recording
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
        mediaRecorderRef.current.stop();
      }
      setIsRecordingAudio(false);
    } else {
      // Start recording
      audioChunksRef.current = [];
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mediaRecorder = new MediaRecorder(stream);
        mediaRecorderRef.current = mediaRecorder;

        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            audioChunksRef.current.push(event.data);
          }
        };

        mediaRecorder.onstop = async () => {
          const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
          setAudioBlob(blob);
          stream.getTracks().forEach(track => track.stop());
          
          // Auto transcribe upon stop
          handleTranscribeBlob(blob);
        };

        mediaRecorder.start();
        setIsRecordingAudio(true);
        setTranscribedText("Listening to audio stream...");
      } catch (err) {
        console.error("Mic access denied:", err);
        triggerToast("Microphone access denied or unsupported.", "warning");
      }
    }
  };

  // Convert blob to base64 and send to `/api/transcribe`
  const handleTranscribeBlob = async (blob: Blob) => {
    setIsTranscribing(true);
    setTranscribedText("AI Transcribing with gemini-3.5-flash...");

    const reader = new FileReader();
    reader.readAsDataURL(blob);
    reader.onloadend = async () => {
      const base64data = reader.result?.toString().split(",")[1];
      if (!base64data) {
        setTranscribedText("Could not encode audio file.");
        setIsTranscribing(false);
        return;
      }

      try {
        const res = await fetch("/api/transcribe", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            audioBase64: base64data,
            mimeType: "audio/webm"
          })
        });
        const data = await res.json();
        if (data.text) {
          setTranscribedText(data.text);
          // Insert into chat
          setInputText(data.text);
          triggerToast("Speech transcribed! Ready to submit.", "success");
        } else {
          setTranscribedText("Transcribing produced empty output.");
        }
      } catch (err) {
        console.error("Transcription error:", err);
        setTranscribedText("Failed to process transcription.");
      } finally {
        setIsTranscribing(false);
      }
    };
  };

  // Live calling voice logic
  const startLivePhoneCall = () => {
    if (isSpeechListening) {
      recognitionRef.current?.stop();
    }
    
    setIsCallActive(true);
    setCallDuration(0);
    setCurrentSpeechTranscript("");

    // Read initial greetings using text-to-speech
    setTimeout(() => {
      speakVocalResponse("Prodolar here. Focus line established. Speak clearly. What deadline is threatening you?");
    }, 500);

    // Start listening
    try {
      recognitionRef.current?.start();
    } catch (e) {
      console.warn("Could not start recognition:", e);
    }
  };

  const stopLivePhoneCall = () => {
    setIsCallActive(false);
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
  };

  // Handle live spoken commands from call
  const handleVoiceCommandInput = async (spokenPhrase: string) => {
    if (!spokenPhrase.trim()) return;
    
    // Simulating Live model gemini-3.1-flash-live-preview responses
    try {
      const response = await fetch("/api/agent/voice-command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          transcript: spokenPhrase,
          currentTasks: tasks,
          currentEvents: events,
          context: {
            battery: 92,
            internet: "online",
            location: "Active Calling Lounge",
            weather: "Sunny, 72°F",
            traffic: "Clear"
          }
        })
      });

      const data = await response.json();
      if (data.reply) {
        speakVocalResponse(data.reply);
        setCurrentSpeechTranscript("");
      }
    } catch (e) {
      console.error("Live calling command error:", e);
    }
  };

  // Read spoken replies out loud
  const speakVocalResponse = (text: string) => {
    if (speechOutputMuted || !window.speechSynthesis) return;

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 0.95; // Slightly lower pitch for authority!
    window.speechSynthesis.speak(utterance);
  };

  // Format seconds to call clock MM:SS
  const formatTime = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = sec % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // Insert mock android background tracker log
  const simulateNewPhoneActivity = () => {
    const apps = ["Instagram", "WhatsApp", "YouTube", "Twitter / X", "Netflix", "Duolingo"];
    const chosenApp = apps[Math.floor(Math.random() * apps.length)];
    
    let intervention = "";
    let act: "Blocked" | "Warned" | "Allowed" = "Warned";

    if (chosenApp === "Instagram" || chosenApp === "Twitter / X") {
      intervention = `Proactively Warned: '${chosenApp} session logged. Procrastination risk critical. Re-routing focus.'`;
      act = "Warned";
    } else if (chosenApp === "YouTube" || chosenApp === "Netflix") {
      intervention = `Hard Block: 'Blocked media streaming. Redirecting to urgent distributedconsensus review.'`;
      act = "Blocked";
    } else {
      intervention = `Allowed check: '${chosenApp} allowed. 5-minute activation cycle still running.'`;
      act = "Allowed";
    }

    const newLog = {
      id: `log-${Date.now()}`,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      app: chosenApp,
      intervention,
      action: act
    };

    setPhoneAppLogs(prev => [newLog, ...prev.slice(0, 5)]);
    triggerToast(`Phone App tracker caught ${chosenApp}!`, act === "Blocked" ? "warning" : "info");
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto text-black pb-12" id="ai-lounge-container">
      {/* Tab Header */}
      <div className="border-b border-zinc-200 pb-5">
        <h1 className="text-2xl font-display font-bold text-black tracking-tight flex items-center gap-2">
          <Bot className="w-6 h-6 text-[#1a73e8]" />
          <span>AI Chief Executive Suite</span>
        </h1>
        <p className="text-xs text-zinc-500 mt-1 font-mono">
          GOOGLE SIGN-IN, GEMINI MULTI-TURN CHAT, GROUNDING, LIVE CALL ENGINE & ANDROID TRACKER
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="ai-lounge-grid">
        
        {/* Left Column: Firebase Authentication & Chatbot Panel (8 cols) */}
        <div className="lg:col-span-8 space-y-6 flex flex-col h-[750px]" id="lounge-left-col">
          
          {/* User Sign In and Account Metadata Panel */}
          <div className="border border-zinc-200 p-5 bg-white rounded-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4" id="google-auth-panel">
            <div className="flex items-center gap-3">
              {user ? (
                <>
                  {user.photoURL ? (
                    <img 
                      src={user.photoURL} 
                      alt={user.displayName || "User"} 
                      className="w-10 h-10 rounded-full border border-zinc-200"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-zinc-900 text-white flex items-center justify-center font-bold">
                      {user.displayName?.charAt(0) || "U"}
                    </div>
                  )}
                  <div>
                    <h3 className="text-sm font-bold text-black flex items-center gap-1.5">
                      <span>{user.displayName || "Utsav Jha"}</span>
                      <span className="px-1.5 py-0.5 text-[8px] bg-emerald-50 text-emerald-700 border border-emerald-300 rounded uppercase font-mono font-bold">Cloud Synced</span>
                    </h3>
                    <p className="text-[11px] font-mono text-zinc-500">{user.email}</p>
                  </div>
                </>
              ) : (
                <>
                  <div className="w-10 h-10 rounded-full bg-zinc-100 border border-zinc-200 flex items-center justify-center">
                    <User className="w-5 h-5 text-zinc-400" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-black">Local Offline Mode</h3>
                    <p className="text-[11px] text-zinc-500 font-sans">Sign in to sync obligations across devices.</p>
                  </div>
                </>
              )}
            </div>

            <div>
              {user ? (
                <button
                  id="btn-google-signout"
                  onClick={handleSignOut}
                  className="px-4 py-2 border border-zinc-200 hover:border-black text-xs font-semibold rounded flex items-center gap-2 transition-all hover:bg-zinc-50"
                >
                  <LogOut className="w-4 h-4 text-zinc-500" />
                  <span>Sign Out</span>
                </button>
              ) : (
                <button
                  id="btn-google-signin"
                  onClick={handleSignIn}
                  disabled={isSigningIn}
                  className="px-4 py-2 border border-black text-white bg-zinc-900 hover:bg-zinc-800 text-xs font-semibold rounded flex items-center gap-2 transition-all shadow-sm"
                >
                  <LogIn className="w-4 h-4 text-white animate-pulse" />
                  <span>{isSigningIn ? "Authorizing..." : "Google Sign-In"}</span>
                </button>
              )}
            </div>
          </div>

          {/* Gemini Multimodal Chat Suite */}
          <div className="border border-zinc-200 bg-white rounded-lg flex flex-col flex-1 overflow-hidden" id="chatbot-frame">
            
            {/* Chat Header Settings */}
            <div className="p-4 border-b border-zinc-200 bg-zinc-50 flex flex-wrap items-center justify-between gap-3" id="chat-sub-settings">
              {/* Persona Selector */}
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold text-zinc-500 uppercase">Aesthetic Vibe:</span>
                <select
                  id="select-chat-persona"
                  value={chatRole}
                  onChange={(e) => setChatRole(e.target.value as any)}
                  className="px-2.5 py-1 text-[11px] font-semibold border border-zinc-300 rounded bg-white text-zinc-800"
                >
                  <option value="Chief">Prodolar Executive Mode</option>
                  <option value="Guilt">The Guilt Tripper (High guilt)</option>
                  <option value="Stoic">Stoic Commander (Zero Excuses)</option>
                  <option value="FOMO">Deadline Anxiety Creator</option>
                </select>
              </div>

              {/* Advanced Flags */}
              <div className="flex items-center gap-3">
                {/* Low Latency */}
                <label className="flex items-center gap-1.5 cursor-pointer" title="Ultra fast responses using gemini-3.1-flash-lite">
                  <input 
                    type="checkbox" 
                    id="chk-low-latency"
                    checked={lowLatency}
                    onChange={(e) => {
                      setLowLatency(e.target.checked);
                      if (e.target.checked) setThinking(false);
                    }}
                    className="w-3.5 h-3.5 accent-black rounded border-zinc-300"
                  />
                  <span className="text-[11px] font-semibold text-zinc-700 font-mono">Lite</span>
                </label>

                {/* Search Grounding */}
                <label className="flex items-center gap-1.5 cursor-pointer" title="Connect to real-time search data with gemini-3.5-flash">
                  <input 
                    type="checkbox" 
                    id="chk-search-grounding"
                    checked={searchGrounding}
                    onChange={(e) => setSearchGrounding(e.target.checked)}
                    className="w-3.5 h-3.5 accent-black rounded border-zinc-300"
                  />
                  <span className="text-[11px] font-semibold text-zinc-700 font-mono">Grounding</span>
                </label>

                {/* Deep Thinking Mode */}
                <label className="flex items-center gap-1.5 cursor-pointer" title="High level reasoning using gemini-3.1-pro-preview">
                  <input 
                    type="checkbox" 
                    id="chk-deep-thinking"
                    checked={thinking}
                    onChange={(e) => {
                      setThinking(e.target.checked);
                      if (e.target.checked) setLowLatency(false);
                    }}
                    className="w-3.5 h-3.5 accent-[#1a73e8] rounded border-zinc-300"
                  />
                  <span className={`text-[11px] font-semibold font-mono ${thinking ? "text-[#1a73e8]" : "text-zinc-700"}`}>Thinking Mode</span>
                </label>
              </div>
            </div>

            {/* Chat Thread Container */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-[350px]" id="chat-thread">
              {messages.map((m, idx) => (
                <div 
                  key={idx} 
                  className={`flex ${m.sender === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div 
                    className={`max-w-[85%] rounded-lg p-3 text-xs leading-relaxed space-y-2 border ${
                      m.sender === "user" 
                        ? "bg-zinc-100 border-zinc-300 text-zinc-900" 
                        : "bg-white border-zinc-200 text-black shadow-sm"
                    }`}
                  >
                    {m.sender === "ai" && (
                      <div className="flex items-center gap-1.5 border-b border-zinc-100 pb-1.5 mb-1 text-[10px] font-mono text-zinc-500 font-semibold uppercase">
                        <Bot className="w-3.5 h-3.5 text-[#1a73e8]" />
                        <span>{chatRole} Coach</span>
                      </div>
                    )}
                    <p className="whitespace-pre-wrap">{m.text}</p>

                    {/* Search results grounding citations rendering */}
                    {m.searchResults && m.searchResults.length > 0 && (
                      <div className="mt-2.5 pt-2 border-t border-zinc-100 space-y-1">
                        <div className="flex items-center gap-1 text-[10px] font-mono font-semibold text-[#1a73e8] uppercase">
                          <Search className="w-3 h-3" />
                          <span>Grounding citations:</span>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {m.searchResults.map((ref, rIdx) => (
                            <a 
                              key={rIdx} 
                              href={ref.uri} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-[10px] bg-zinc-100 hover:bg-zinc-200 text-zinc-700 border border-zinc-200 px-2 py-0.5 rounded font-mono transition-colors"
                            >
                              <span>{ref.title || "Ref"}</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              
              {isGenerating && (
                <div className="flex justify-start">
                  <div className="max-w-[70%] rounded-lg p-3 bg-zinc-50 border border-zinc-200 text-xs">
                    <div className="flex items-center gap-2">
                      <div className="flex space-x-1">
                        <div className="w-2.5 h-2.5 bg-zinc-600 rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></div>
                        <div className="w-2.5 h-2.5 bg-zinc-600 rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></div>
                        <div className="w-2.5 h-2.5 bg-zinc-600 rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></div>
                      </div>
                      <span className="text-[10px] font-mono text-zinc-500 font-semibold animate-pulse uppercase">
                        {thinking ? "Deep thinking cycle active..." : "Prodolar drafting strategy..."}
                      </span>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Chat Inputs & Mic transcription widget */}
            <div className="p-4 border-t border-zinc-200 space-y-3" id="chat-input-bar">
              {/* Audio transcription output display if active */}
              {(isRecordingAudio || isTranscribing || transcribedText) && (
                <div className="p-2.5 bg-zinc-50 border border-zinc-200 rounded text-[11px] font-mono text-zinc-700 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className={`w-2 h-2 rounded-full ${isRecordingAudio ? "bg-red-500 animate-ping" : "bg-zinc-400"}`}></div>
                    <span className="truncate">{transcribedText}</span>
                  </div>
                  {transcribedText && !isTranscribing && (
                    <button 
                      id="btn-clear-transcribe"
                      onClick={() => setTranscribedText("")}
                      className="text-zinc-500 hover:text-black font-semibold text-[10px] uppercase border-b border-zinc-300"
                    >
                      Clear
                    </button>
                  )}
                </div>
              )}

              <div className="flex items-center gap-2">
                {/* Audio transcription trigger button */}
                <button
                  id="btn-voice-mic"
                  onClick={toggleAudioRecording}
                  title="Click to talk, we will transcribe your voice into text using gemini-3.5-flash"
                  className={`w-10 h-10 rounded border flex items-center justify-center transition-all ${
                    isRecordingAudio 
                      ? "bg-red-100 border-red-400 text-red-600 animate-pulse" 
                      : "bg-white border-zinc-200 hover:border-black text-zinc-600 hover:text-black"
                  }`}
                >
                  {isRecordingAudio ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </button>

                <input
                  type="text"
                  id="input-chat-message"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                  placeholder={isRecordingAudio ? "Speaking into microphone..." : "Force a deadline rescheduling or consult with Chief..."}
                  className="flex-1 border border-zinc-200 rounded px-4 py-2 text-xs focus:outline-none focus:border-black placeholder-zinc-400"
                />

                <button
                  id="btn-submit-chat"
                  onClick={handleSendMessage}
                  disabled={isGenerating || !inputText.trim()}
                  className="w-10 h-10 rounded border border-black bg-zinc-900 hover:bg-zinc-800 disabled:opacity-40 text-white flex items-center justify-center transition-all shrink-0"
                >
                  <Send className="w-4.5 h-4.5 text-white" />
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* Right Column: Voice Room / Phone Call & Android Simulator (4 cols) */}
        <div className="lg:col-span-4 space-y-6" id="lounge-right-col">
          
          {/* Real-time Voice Call Lounge (gemini-3.1-flash-live-preview Simulator) */}
          <div className="border border-zinc-200 bg-white rounded-lg p-5 text-center flex flex-col justify-between h-[360px]" id="voice-call-lounge">
            <div>
              <div className="flex items-center justify-between text-zinc-500 mb-3">
                <span className="text-[9px] font-mono uppercase tracking-wider font-semibold">Live Lounge</span>
                <span className="px-1.5 py-0.5 text-[8px] bg-[#1a73e8]/10 text-[#1a73e8] rounded font-mono font-semibold uppercase">gemini-3.1-flash-live-preview</span>
              </div>
              
              <h2 className="text-sm font-bold text-black font-display">Oral Executive Intervention</h2>
              <p className="text-[11px] text-zinc-500 mt-0.5">A real verbal conversation with the Chief of Staff</p>
            </div>

            {/* Calling state screen */}
            <div className="my-4 py-3 flex flex-col items-center justify-center relative">
              <AnimatePresence mode="wait">
                {isCallActive ? (
                  <motion.div 
                    key="active-call"
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                    className="flex flex-col items-center space-y-3"
                  >
                    {/* Pulsing visual audio wave */}
                    <div className="flex items-center gap-1.5 h-12">
                      <motion.div animate={{ height: [12, 40, 12] }} transition={{ repeat: Infinity, duration: 1.1, ease: "easeInOut" }} className="w-1 bg-[#1a73e8] rounded"></motion.div>
                      <motion.div animate={{ height: [16, 48, 16] }} transition={{ repeat: Infinity, duration: 0.9, ease: "easeInOut" }} className="w-1 bg-[#1a73e8] rounded"></motion.div>
                      <motion.div animate={{ height: [20, 56, 20] }} transition={{ repeat: Infinity, duration: 1.3, ease: "easeInOut" }} className="w-1 bg-black rounded"></motion.div>
                      <motion.div animate={{ height: [16, 42, 16] }} transition={{ repeat: Infinity, duration: 1.0, ease: "easeInOut" }} className="w-1 bg-[#1a73e8] rounded"></motion.div>
                      <motion.div animate={{ height: [12, 32, 12] }} transition={{ repeat: Infinity, duration: 1.2, ease: "easeInOut" }} className="w-1 bg-[#1a73e8] rounded"></motion.div>
                    </div>

                    <div className="text-zinc-800 font-mono text-xs font-bold tracking-widest animate-pulse">
                      LINE SECURED • {formatTime(callDuration)}
                    </div>
                    {currentSpeechTranscript ? (
                      <p className="text-[11px] text-zinc-700 max-w-[200px] italic line-clamp-2">"{currentSpeechTranscript}"</p>
                    ) : (
                      <p className="text-[10px] text-zinc-400">Speak into your mic...</p>
                    )}
                  </motion.div>
                ) : (
                  <motion.div 
                    key="idle-call"
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                    className="flex flex-col items-center space-y-2"
                  >
                    <div className="w-16 h-16 rounded-full bg-zinc-50 border border-zinc-200 flex items-center justify-center text-zinc-400">
                      <PhoneCall className="w-7 h-7" />
                    </div>
                    <span className="text-[11px] text-zinc-500 font-sans">Ready to initiate oral intervention</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Trigger buttons */}
            <div className="flex items-center justify-center gap-3">
              {isCallActive ? (
                <>
                  {/* Mute Voice Readout */}
                  <button
                    id="btn-toggle-speak-mute"
                    onClick={() => {
                      setSpeechOutputMuted(!speechOutputMuted);
                      if (!speechOutputMuted && window.speechSynthesis) window.speechSynthesis.cancel();
                    }}
                    className={`w-9 h-9 rounded-full border flex items-center justify-center transition-all ${
                      speechOutputMuted ? "bg-amber-50 border-amber-300 text-amber-600" : "bg-zinc-50 border-zinc-200 text-zinc-600 hover:border-zinc-400"
                    }`}
                    title={speechOutputMuted ? "Unmute vocal feedback" : "Mute vocal feedback"}
                  >
                    {speechOutputMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>

                  <button
                    id="btn-disconnect-call"
                    onClick={stopLivePhoneCall}
                    className="px-6 py-2.5 rounded bg-red-600 hover:bg-red-500 border border-red-700 text-white text-xs font-bold font-mono tracking-wider flex items-center gap-2 transition-all shadow-sm uppercase"
                  >
                    <PhoneOff className="w-4 h-4 text-white" />
                    <span>Hang Up</span>
                  </button>
                </>
              ) : (
                <button
                  id="btn-connect-call"
                  onClick={startLivePhoneCall}
                  className="px-6 py-2.5 rounded bg-[#1a73e8] hover:bg-[#1557b0] border border-black text-white text-xs font-bold font-mono tracking-wider flex items-center gap-2 transition-all shadow-sm uppercase"
                >
                  <PhoneCall className="w-4 h-4 text-white animate-bounce" />
                  <span>Call Prodolar</span>
                </button>
              )}
            </div>
          </div>

          {/* Android Simulated Background Tracker Hub */}
          <div className="border border-zinc-200 bg-white rounded-lg p-5 flex flex-col h-[366px]" id="android-tracker-sim">
            <div className="flex items-center justify-between text-zinc-500 mb-2">
              <span className="text-[9px] font-mono uppercase tracking-wider font-semibold">Mock Android System service</span>
              <Smartphone className="w-4.5 h-4.5 text-zinc-700" />
            </div>

            <div className="flex items-center justify-between border-b border-zinc-100 pb-3 mb-3">
              <div>
                <h3 className="text-xs font-bold text-black uppercase tracking-wider font-mono">Device Interception</h3>
                <p className="text-[10px] text-zinc-500 mt-0.5">Prodolar scans app openings to guilt-trip slacking</p>
              </div>

              <button
                id="btn-toggle-tracker"
                onClick={() => setTrackerActive(!trackerActive)}
                className={`w-10 h-5.5 rounded-full transition-all relative border border-black focus:outline-none ${
                  trackerActive ? "bg-[#1a73e8]" : "bg-zinc-200"
                }`}
              >
                <span className={`w-3.5 h-3.5 rounded-full bg-white absolute top-1/2 -translate-y-1/2 transition-transform ${
                  trackerActive ? "translate-x-5" : "translate-x-1"
                }`}></span>
              </button>
            </div>

            {/* Tracking Activity list */}
            <div className="flex-1 overflow-y-auto space-y-2 mb-3 pr-1" id="android-log-list">
              {phoneAppLogs.map((log) => (
                <div 
                  key={log.id} 
                  className={`p-2 border rounded text-[10px] leading-tight flex items-start gap-2 ${
                    log.action === "Blocked" 
                      ? "bg-red-50/50 border-red-200 text-red-900" 
                      : log.action === "Warned" 
                        ? "bg-amber-50/50 border-amber-200 text-amber-900" 
                        : "bg-zinc-50 border-zinc-200 text-zinc-600"
                  }`}
                >
                  <div className="shrink-0 mt-0.5">
                    {log.action === "Blocked" ? (
                      <ShieldAlert className="w-3.5 h-3.5 text-red-600" />
                    ) : (
                      <ShieldCheck className="w-3.5 h-3.5 text-zinc-600" />
                    )}
                  </div>
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5 font-mono">
                      <span className="font-bold text-black">{log.app}</span>
                      <span className="text-zinc-400 text-[9px]">{log.time}</span>
                      <span className={`text-[8px] uppercase font-bold px-1 rounded ${
                        log.action === "Blocked" ? "bg-red-100 text-red-800" : log.action === "Warned" ? "bg-amber-100 text-amber-800" : "bg-zinc-100 text-zinc-800"
                      }`}>{log.action}</span>
                    </div>
                    <p className="text-[9.5px] italic text-zinc-700">"{log.intervention}"</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Action buttons */}
            <div className="space-y-2">
              <button
                id="btn-simulate-android-activity"
                onClick={simulateNewPhoneActivity}
                disabled={!trackerActive}
                className="w-full py-1.5 border border-black hover:bg-zinc-50 text-[10px] font-mono uppercase tracking-wider font-bold rounded transition-all disabled:opacity-40"
              >
                Simulate Phone App Launch
              </button>
              
              <div className="p-2.5 bg-zinc-50 border border-zinc-200 rounded text-[10px] leading-relaxed text-zinc-600">
                🚀 **Did you know?** When downloaded, Prodolar runs as a background worker on your phone, mapping calendar logs and sending push prompts whenever social networks are accessed.
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
