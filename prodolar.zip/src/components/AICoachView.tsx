import React, { useState } from "react";
import { 
  Bot, 
  Sparkles, 
  Flame, 
  TrendingUp, 
  BookOpen, 
  Clock, 
  Sliders, 
  MessageSquare,
  AlertTriangle,
  Award,
  RefreshCw,
  Zap
} from "lucide-react";
import { motion } from "motion/react";
import { Task, FocusSession, CoachLog } from "../types";

interface AICoachViewProps {
  tasks: Task[];
  focusSessions: FocusSession[];
  coachLogs: CoachLog[];
  onAddCoachLog: (newLog: CoachLog) => void;
}

export default function AICoachView({ 
  tasks, 
  focusSessions, 
  coachLogs,
  onAddCoachLog 
}: AICoachViewProps) {
  const [loading, setLoading] = useState(false);
  const [scrollTime, setScrollTime] = useState(60); // custom scrolling slider

  const triggerReviewGeneration = async (type: "daily" | "weekly") => {
    setLoading(true);
    try {
      const response = await fetch("/api/agent/coach", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          focusSessions,
          tasks,
          currentStats: {
            scrollTimeWasted: scrollTime,
            completedCount: tasks.filter(t => t.status === "completed").length
          }
        })
      });

      if (!response.ok) throw new Error("Coach API failure");
      const data = await response.json();

      if (data.success && data.log) {
        const newLog: CoachLog = {
          id: `coach-${Date.now()}`,
          date: new Date().toISOString().split("T")[0],
          type,
          achievements: data.log.achievements || ["Maintained strict calendar adherence"],
          missedDeadlines: data.log.missedDeadlines || [],
          coachingNotes: data.log.coachingNotes || "You are making steady progress towards your Friday assignments. Protect your morning peak slots.",
          scrollTimeWastedMinutes: data.log.scrollTimeWastedMinutes || scrollTime,
          meetingTimeReducedMinutes: data.log.meetingTimeReducedMinutes || 15,
          habitsScore: data.log.habitsScore || 85
        };
        onAddCoachLog(newLog);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const activeLog = coachLogs[0]; // Highlight the latest log

  return (
    <div className="space-y-6" id="coach-container">
      {/* Header */}
      <div>
        <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
          <Bot className="w-5 h-5 text-emerald-400" />
          <span>Guardian AI Coach</span>
        </h1>
        <p className="text-xs text-gray-400">Reflective daily metrics and behavioral analytics parsed by your personal productivity mentor.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive Reflection Launcher */}
        <div className="glass-panel p-5 rounded-2xl space-y-4" id="coach-generation-panel">
          <h2 className="text-sm font-semibold text-white flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>Reflect on Your Day</span>
          </h2>
          <p className="text-xs text-gray-400 leading-relaxed">
            Specify daily metrics below. The AI Coach Agent will analyze your task pacing, focus blocks, and scrolling habits to generate a custom reflection log.
          </p>

          <div className="space-y-4 pt-2">
            {/* Scroll time slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-medium text-gray-300">
                <span>Estimated screen scroll / phone use</span>
                <span className="text-amber-400 font-semibold font-mono">{scrollTime} mins</span>
              </div>
              <input
                type="range"
                min="0"
                max="240"
                step="15"
                value={scrollTime}
                onChange={(e) => setScrollTime(Number(e.target.value))}
                className="w-full accent-emerald-500 bg-gray-800 rounded-lg appearance-none h-1.5 cursor-pointer"
                id="input-scroll-slider"
              />
              <div className="flex justify-between text-[9px] text-gray-500 font-mono">
                <span>0 MIN (SUPERHUMAN)</span>
                <span>4 HRS (SEVERE DISTRACTION)</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => triggerReviewGeneration("daily")}
                disabled={loading}
                className="px-3.5 py-2.5 bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-500/20 disabled:text-emerald-500/40 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-md shadow-emerald-500/15"
                id="btn-generate-daily"
              >
                {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Bot className="w-3.5 h-3.5" />}
                <span>Daily Reflection</span>
              </button>
              <button
                onClick={() => triggerReviewGeneration("weekly")}
                disabled={loading}
                className="px-3.5 py-2.5 bg-white/5 hover:bg-white/10 disabled:opacity-40 text-white border border-white/10 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
                id="btn-generate-weekly"
              >
                <span>Weekly Review</span>
              </button>
            </div>
          </div>
        </div>

        {/* Dynamic Coach Review Output */}
        <div className="lg:col-span-2 space-y-6">
          {activeLog ? (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-panel p-6 rounded-2xl space-y-5"
              id="coach-active-log"
            >
              {/* Score card */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/5">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold bg-emerald-500/10 text-emerald-400 px-2.5 py-0.5 rounded-full uppercase font-mono tracking-wider">
                      {activeLog.type} Review
                    </span>
                    <span className="text-xs text-gray-500 font-mono">Logged: {activeLog.date}</span>
                  </div>
                  <h3 className="text-sm font-semibold text-white">Your Habits Counseling Assessment</h3>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] text-gray-400 block uppercase font-mono font-medium">Habits score</span>
                    <span className="text-2xl font-display font-bold text-emerald-400 tracking-tight">{activeLog.habitsScore}/100</span>
                  </div>
                  <Award className="w-8 h-8 text-emerald-400 bg-emerald-500/10 p-1.5 rounded-xl border border-emerald-500/20" />
                </div>
              </div>

              {/* Coaching notes text */}
              <div className="space-y-2">
                <span className="text-[11px] uppercase tracking-wider font-semibold text-gray-400 flex items-center gap-1.5">
                  <MessageSquare className="w-4 h-4 text-emerald-400" />
                  <span>Coach Notes & Analysis</span>
                </span>
                <p className="text-sm text-gray-300 leading-relaxed font-sans">
                  "{activeLog.coachingNotes}"
                </p>
              </div>

              {/* Grid of details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                {/* Achievements block */}
                <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl space-y-2">
                  <span className="text-[10px] uppercase font-semibold text-emerald-400 flex items-center gap-1 font-mono">
                    <Award className="w-3.5 h-3.5" />
                    <span>Achievements Detected</span>
                  </span>
                  <ul className="space-y-1">
                    {activeLog.achievements.map((item, idx) => (
                      <li key={idx} className="text-xs text-gray-300 flex items-start gap-1.5">
                        <span className="text-emerald-400 select-none">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Overdue/Missed items */}
                <div className="p-4 bg-rose-500/5 border border-rose-500/10 rounded-2xl space-y-2">
                  <span className="text-[10px] uppercase font-semibold text-rose-400 flex items-center gap-1 font-mono">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Missed Milestones / Overload</span>
                  </span>
                  <ul className="space-y-1">
                    {activeLog.missedDeadlines.length > 0 ? (
                      activeLog.missedDeadlines.map((item, idx) => (
                        <li key={idx} className="text-xs text-gray-300 flex items-start gap-1.5">
                          <span className="text-rose-400 select-none">•</span>
                          <span>{item}</span>
                        </li>
                      ))
                    ) : (
                      <li className="text-xs text-emerald-400/80 italic flex items-start gap-1.5">
                        <span>✓ Perfect compliance. No missed deadlines recorded.</span>
                      </li>
                    )}
                  </ul>
                </div>
              </div>

              {/* Time stats */}
              <div className="grid grid-cols-2 gap-4 pt-2 border-t border-white/5 font-mono text-xs">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span className="text-gray-400">Screen scroll wasted:</span>
                  <span className="text-white font-bold">{activeLog.scrollTimeWastedMinutes}m</span>
                </div>
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-emerald-400" />
                  <span className="text-gray-400">Meeting overhead saved:</span>
                  <span className="text-white font-bold">{activeLog.meetingTimeReducedMinutes}m</span>
                </div>
              </div>

            </motion.div>
          ) : (
            <div className="h-64 glass-panel rounded-2xl flex flex-col items-center justify-center p-8 text-center space-y-3">
              <Bot className="w-10 h-10 text-emerald-400/40 bg-emerald-500/5 p-2 rounded-2xl" />
              <div className="space-y-1">
                <p className="text-sm font-semibold text-white">Awaiting Reflections</p>
                <p className="text-xs text-gray-500 max-w-sm leading-relaxed">
                  You haven't generated a reflection log for this cycle yet. Fill in your screen-time parameter and click "Daily Reflection" to invoke the AI Coach.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
