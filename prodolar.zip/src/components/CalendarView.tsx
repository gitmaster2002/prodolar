import React, { useState } from "react";
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Zap, 
  ChevronLeft, 
  ChevronRight, 
  RefreshCw, 
  Plane, 
  BookOpen, 
  Briefcase, 
  Lock,
  Sparkles,
  Bot
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Task, CalendarEvent } from "../types";

interface CalendarViewProps {
  tasks: Task[];
  events: CalendarEvent[];
  onRescheduleTask: (taskId: string, newStart: string, newEnd: string) => void;
  onDynamicReplanAll: () => void;
}

export default function CalendarView({ 
  tasks, 
  events, 
  onRescheduleTask,
  onDynamicReplanAll 
}: CalendarViewProps) {
  const [selectedDayOffset, setSelectedDayOffset] = useState(0);
  const [replanDialog, setReplanDialog] = useState<{ isOpen: boolean; taskId: string | null; currentHour: number } | null>(null);
  const [replanningRunning, setReplanningRunning] = useState(false);

  // Calculate day details
  const getTargetDate = () => {
    const d = new Date();
    d.setDate(d.getDate() + selectedDayOffset);
    return d;
  };

  const targetDate = getTargetDate();
  const dayStr = targetDate.toISOString().split("T")[0];

  // Filter tasks and events scheduled for this day
  const dailyEvents = events.filter(e => e.start.split("T")[0] === dayStr);
  const dailyTasks = tasks.filter(t => t.timeBlock && t.timeBlock.start.split("T")[0] === dayStr);

  // Group into cognitive energy intervals:
  // - Morning (8:00 AM - 12:00 PM): Deep Work
  // - Afternoon (12:00 PM - 5:00 PM): Meetings, Collaborations
  // - Evening/Night (5:00 PM - 10:00 PM): Emails, Routine, Personal
  const getSlotDetails = (timeStr: string) => {
    const date = new Date(timeStr);
    const hours = date.getHours();
    if (hours < 12) return { name: "Morning Peak (08:00 - 12:00)", energy: "high", icon: "🔥", desc: "Best for complex cognitive assignments" };
    if (hours < 17) return { name: "Afternoon Slump (12:00 - 17:00)", energy: "medium", icon: "⚡", desc: "Ideal for meetings, networking, and review" };
    return { name: "Evening Recovery (17:00 - 22:00)", energy: "low", icon: "✉️", desc: "Suited for email responses, log review, and personal" };
  };

  const morningItems = [
    ...dailyEvents.filter(e => new Date(e.start).getHours() < 12).map(e => ({ type: "event", item: e })),
    ...dailyTasks.filter(t => t.timeBlock && new Date(t.timeBlock.start).getHours() < 12).map(t => ({ type: "task", item: t }))
  ];

  const afternoonItems = [
    ...dailyEvents.filter(e => new Date(e.start).getHours() >= 12 && new Date(e.start).getHours() < 17).map(e => ({ type: "event", item: e })),
    ...dailyTasks.filter(t => t.timeBlock && new Date(t.timeBlock.start).getHours() >= 12 && new Date(t.timeBlock.start).getHours() < 17).map(t => ({ type: "task", item: t }))
  ];

  const eveningItems = [
    ...dailyEvents.filter(e => new Date(e.start).getHours() >= 17).map(e => ({ type: "event", item: e })),
    ...dailyTasks.filter(t => t.timeBlock && new Date(t.timeBlock.start).getHours() >= 17).map(t => ({ type: "task", item: t }))
  ];

  const handleRescheduleClick = (taskId: string) => {
    setReplanDialog({ isOpen: true, taskId, currentHour: 9 });
  };

  const executeReschedule = async () => {
    if (!replanDialog || !replanDialog.taskId) return;
    setReplanningRunning(true);

    // Simulate Dynamic Rebuilding
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Construct new start/end
    const newStart = new Date(targetDate);
    newStart.setHours(replanDialog.currentHour, 0, 0);
    const newEnd = new Date(newStart);
    newEnd.setHours(newStart.getHours() + 3);

    onRescheduleTask(replanDialog.taskId, newStart.toISOString(), newEnd.toISOString());
    setReplanningRunning(false);
    setReplanDialog(null);
  };

  return (
    <div className="space-y-6" id="calendar-view-container">
      {/* Calendar Header with Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-emerald-400" />
            <span>Energy-Optimized Schedule</span>
          </h1>
          <p className="text-xs text-gray-400">Time blocks allocated based on task difficulty and your daily cognitive peaks.</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center bg-white/5 border border-white/5 rounded-xl px-1 py-1">
            <button 
              id="btn-prev-day"
              onClick={() => setSelectedDayOffset(prev => prev - 1)}
              className="p-1.5 hover:bg-white/5 rounded-lg text-gray-400 hover:text-white transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-semibold px-4 text-white font-mono min-w-[120px] text-center">
              {targetDate.toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric' })}
            </span>
            <button 
              id="btn-next-day"
              onClick={() => setSelectedDayOffset(prev => prev + 1)}
              className="p-1.5 hover:bg-white/5 rounded-lg text-gray-400 hover:text-white transition-all"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <button
            id="btn-trigger-replan"
            onClick={onDynamicReplanAll}
            className="px-3.5 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Dynamic Rebuild</span>
          </button>
        </div>
      </div>

      {/* Main Energy Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="energy-columns-grid">
        {/* Morning Column */}
        <div className="glass-panel p-5 rounded-2xl space-y-4 border-t-2 border-emerald-500" id="column-morning">
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-white flex items-center gap-1.5">
                <span className="text-lg">🔥</span>
                <span>Morning Focus Peak</span>
              </span>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full font-semibold border border-emerald-500/10">
                8 AM - 12 PM
              </span>
            </div>
            <p className="text-[11px] text-gray-400">High cognitive power. Ideal for complex papers, coding, and backpropagation calculations.</p>
          </div>

          <div className="space-y-3 pt-2">
            {morningItems.map((item, index) => (
              <CalendarItemCard 
                key={index} 
                item={item} 
                onReschedule={handleRescheduleClick} 
              />
            ))}
            {morningItems.length === 0 && (
              <div className="h-32 border border-dashed border-white/5 rounded-xl flex flex-col items-center justify-center text-center p-4">
                <span className="text-xs text-gray-500">No scheduled activities</span>
                <span className="text-[10px] text-emerald-400/60 mt-1 cursor-pointer hover:underline" onClick={onDynamicReplanAll}>Click Rebuild to fill slot</span>
              </div>
            )}
          </div>
        </div>

        {/* Afternoon Column */}
        <div className="glass-panel p-5 rounded-2xl space-y-4 border-t-2 border-amber-500" id="column-afternoon">
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-white flex items-center gap-1.5">
                <span className="text-lg">⚡</span>
                <span>Afternoon Collaborative</span>
              </span>
              <span className="text-[10px] bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded-full font-semibold border border-amber-500/10">
                12 PM - 5 PM
              </span>
            </div>
            <p className="text-[11px] text-gray-400">Intermediate focus. Perfect for technical round interviews, lectures, and peer review.</p>
          </div>

          <div className="space-y-3 pt-2">
            {afternoonItems.map((item, index) => (
              <CalendarItemCard 
                key={index} 
                item={item} 
                onReschedule={handleRescheduleClick} 
              />
            ))}
            {afternoonItems.length === 0 && (
              <div className="h-32 border border-dashed border-white/5 rounded-xl flex flex-col items-center justify-center text-center p-4">
                <span className="text-xs text-gray-500">Free interval</span>
                <span className="text-[10px] text-amber-400/60 mt-1">Recommended for interview prep</span>
              </div>
            )}
          </div>
        </div>

        {/* Evening Column */}
        <div className="glass-panel p-5 rounded-2xl space-y-4 border-t-2 border-blue-500" id="column-evening">
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-white flex items-center gap-1.5">
                <span className="text-lg">✉️</span>
                <span>Evening Recovery</span>
              </span>
              <span className="text-[10px] bg-blue-500/10 text-blue-400 px-2 py-0.5 rounded-full font-semibold border border-blue-500/10">
                5 PM - 10 PM
              </span>
            </div>
            <p className="text-[11px] text-gray-400">Low cognitive density. Best for flight packing, email sorting, routine UI audits, and reflection.</p>
          </div>

          <div className="space-y-3 pt-2">
            {eveningItems.map((item, index) => (
              <CalendarItemCard 
                key={index} 
                item={item} 
                onReschedule={handleRescheduleClick} 
              />
            ))}
            {eveningItems.length === 0 && (
              <div className="h-32 border border-dashed border-white/5 rounded-xl flex flex-col items-center justify-center text-center p-4">
                <span className="text-xs text-gray-500">No evening commitments</span>
                <span className="text-[10px] text-blue-400/60 mt-1">Good time for Pomodoro reflection</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Reschedule Dialog Modal */}
      <AnimatePresence>
        {replanDialog && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" id="reschedule-modal">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-panel max-w-md w-full p-6 rounded-2xl space-y-4 shadow-2xl"
            >
              <h3 className="text-base font-semibold text-white flex items-center gap-2">
                <Bot className="w-5 h-5 text-emerald-400" />
                <span>AI Replan: Shift Schedule Slot</span>
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                You are adjusting a task time block. Moving this block triggers the Calendar Agent to analyze other conflicts and calculate the updated success margins.
              </p>

              <div className="space-y-3 pt-2">
                <div>
                  <label className="text-xs font-medium text-gray-400 block mb-1">Target Start Hour</label>
                  <select 
                    value={replanDialog.currentHour}
                    onChange={(e) => setReplanDialog({ ...replanDialog, currentHour: Number(e.target.value) })}
                    className="w-full bg-gray-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                    id="select-reschedule-hour"
                  >
                    <option value={9}>09:00 AM (Morning focus peak)</option>
                    <option value={11}>11:00 AM (Morning focus peak)</option>
                    <option value={14}>02:00 PM (Afternoon collaborative)</option>
                    <option value={16}>04:00 PM (Afternoon collaborative)</option>
                    <option value={19}>07:00 PM (Evening recovery)</option>
                    <option value={20}>08:00 PM (Evening recovery)</option>
                  </select>
                </div>

                {replanDialog.currentHour >= 16 && (
                  <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs rounded-xl">
                    ⚠️ Moving deep work into late evening slots reduces focus efficiency and drops completion success probability by 12%.
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setReplanDialog(null)}
                  className="px-3 py-2 rounded-xl text-xs font-semibold text-gray-400 hover:text-white transition-all"
                  id="btn-cancel-reschedule"
                >
                  Cancel
                </button>
                <button
                  onClick={executeReschedule}
                  disabled={replanningRunning}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-500/20 disabled:text-emerald-500/40 text-white rounded-xl text-xs font-semibold flex items-center gap-1 transition-all"
                  id="btn-confirm-reschedule"
                >
                  {replanningRunning ? "Adapting..." : "Confirm & Adapt"}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Inner calendar card helper
function CalendarItemCard({ item, onReschedule }: { item: any, onReschedule: (id: string) => void, key?: any }) {
  const isTask = item.type === "task";
  
  if (!isTask) {
    const ev = item.item as CalendarEvent;
    
    let icon = <Briefcase className="w-3.5 h-3.5 text-blue-400" />;
    let border = "border-blue-500/20 bg-blue-500/5";
    let titleColor = "text-blue-300";
    if (ev.category === "flight") {
      icon = <Plane className="w-3.5 h-3.5 text-amber-400 animate-pulse" />;
      border = "border-amber-500/20 bg-amber-500/5";
      titleColor = "text-amber-300";
    } else if (ev.category === "class") {
      icon = <BookOpen className="w-3.5 h-3.5 text-emerald-400" />;
      border = "border-emerald-500/20 bg-emerald-500/5";
      titleColor = "text-emerald-300";
    }

    return (
      <div className={`p-3 rounded-xl border flex items-start gap-2.5 relative overflow-hidden ${border}`}>
        <div className="absolute right-2 top-2">
          <Lock className="w-3 h-3 text-gray-600" />
        </div>
        <div className="mt-0.5 shrink-0">{icon}</div>
        <div className="space-y-1">
          <span className={`text-xs font-semibold block leading-none ${titleColor}`}>
            {ev.title}
          </span>
          <div className="flex items-center gap-1.5 text-[10px] text-gray-500 font-mono">
            <Clock className="w-3 h-3" />
            <span>
              {new Date(ev.start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - {new Date(ev.end).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        </div>
      </div>
    );
  } else {
    const task = item.item as Task;
    const block = task.timeBlock!;

    return (
      <div className="p-3.5 rounded-xl border border-white/10 bg-gray-900/40 hover:bg-gray-900/80 hover:border-emerald-500/20 transition-all flex flex-col gap-2 relative group">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-white group-hover:text-emerald-400 transition-colors">
                {task.title}
              </span>
              <span className={`text-[8px] px-1.5 py-0.2 rounded font-mono font-bold border ${task.priority === "high" ? "bg-rose-500/10 text-rose-400 border-rose-500/20" : "bg-gray-500/10 text-gray-400 border-gray-500/20"}`}>
                {task.priority.toUpperCase()}
              </span>
            </div>
            <p className="text-[10px] text-gray-400 line-clamp-2 leading-relaxed">
              {task.description}
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between pt-1 border-t border-white/5">
          <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-mono font-medium">
            <Clock className="w-3.5 h-3.5" />
            <span>
              {new Date(block.start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} ({task.estimatedHours}h)
            </span>
          </div>

          <button
            onClick={() => onReschedule(task.id)}
            className="text-[9px] text-emerald-400 hover:text-emerald-300 font-semibold px-2 py-1 rounded bg-emerald-500/5 hover:bg-emerald-500/10 border border-emerald-500/10 transition-all"
          >
            Reschedule
          </button>
        </div>
      </div>
    );
  }
}
