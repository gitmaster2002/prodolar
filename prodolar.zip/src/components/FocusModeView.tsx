import React, { useState, useEffect, useRef } from "react";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Flame, 
  AlertTriangle, 
  Music, 
  Volume2, 
  VolumeX, 
  EyeOff, 
  Sparkles, 
  CheckCircle,
  Clock,
  ChevronDown
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Task, FocusSession } from "../types";

interface FocusModeViewProps {
  tasks: Task[];
  activeTaskFromDash: Task | null;
  onAddFocusSession: (newSession: FocusSession) => void;
  onCloseFocus: () => void;
}

export default function FocusModeView({ 
  tasks, 
  activeTaskFromDash, 
  onAddFocusSession,
  onCloseFocus 
}: FocusModeViewProps) {
  const [selectedTask, setSelectedTask] = useState<Task | null>(activeTaskFromDash || tasks.find(t => t.status === "pending") || null);
  const [duration, setDuration] = useState(50); // 50 mins deep work standard
  const [timeLeft, setTimeLeft] = useState(50 * 60);
  const [timerRunning, setTimerRunning] = useState(false);
  const [distractions, setDistractions] = useState(0);
  const [musicTrack, setMusicTrack] = useState("Lofi Study Beats");
  const [isMuted, setIsMuted] = useState(false);
  const [fullCocoon, setFullCocoon] = useState(false); // full screen overlay mode

  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Sync timeLeft when duration changes (only if timer not running)
  useEffect(() => {
    if (!timerRunning) {
      setTimeLeft(duration * 60);
    }
  }, [duration]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const toggleTimer = () => {
    if (timerRunning) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setTimerRunning(false);
    } else {
      setTimerRunning(true);
      intervalRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            handleTimerComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
  };

  const handleTimerComplete = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setTimerRunning(false);

    // Save session
    const newSession: FocusSession = {
      id: `focus-${Date.now()}`,
      taskId: selectedTask?.id || null,
      taskTitle: selectedTask?.title || "General Sprint",
      durationMinutes: duration,
      completed: true,
      distractionsCount: distractions,
      energyLevelBefore: "high",
      energyLevelAfter: "medium",
      createdAt: new Date().toISOString()
    };
    onAddFocusSession(newSession);
    alert(`🎉 Great Focus! You completed a ${duration}-minute session for "${selectedTask?.title || "General Sprint"}".`);
    resetTimer();
  };

  const resetTimer = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setTimerRunning(false);
    setTimeLeft(duration * 60);
    setDistractions(0);
  };

  const logDistraction = () => {
    setDistractions(prev => prev + 1);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="space-y-6 relative" id="focus-view-container">
      {/* Cocoon Overlay */}
      <AnimatePresence>
        {fullCocoon && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-[#060913] flex flex-col items-center justify-center space-y-8 p-6"
            id="cocoon-overlay"
          >
            {/* Ambient Background Glows */}
            <div className="absolute top-1/4 left-1/4 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl animate-pulse"></div>

            <button 
              id="btn-leave-cocoon"
              onClick={() => setFullCocoon(false)}
              className="absolute top-6 right-6 px-4 py-2 bg-white/5 border border-white/10 hover:bg-white/10 text-white rounded-xl text-xs font-semibold transition-all"
            >
              Exit Cocoon Mode
            </button>

            <div className="text-center space-y-2 relative z-10">
              <span className="text-[10px] uppercase font-mono tracking-widest text-emerald-400 font-bold flex items-center justify-center gap-1.5">
                <Flame className="w-4 h-4 animate-bounce" />
                <span>ACTIVE FOCUS BOUNDARY</span>
              </span>
              <h2 className="text-sm text-gray-400 font-medium">Currently Focusing On:</h2>
              <h1 className="text-xl font-display font-bold text-white max-w-md mx-auto">
                {selectedTask?.title || "General Deep Work Block"}
              </h1>
            </div>

            {/* Huge Timer */}
            <div className="text-7xl sm:text-8xl font-display font-bold text-white font-mono tracking-tight select-none relative z-10" id="cocoon-large-timer">
              {formatTime(timeLeft)}
            </div>

            {/* Simple Controls */}
            <div className="flex items-center gap-4 relative z-10">
              <button
                onClick={toggleTimer}
                className={`p-4 rounded-full text-white transition-all shadow-xl ${timerRunning ? 'bg-amber-500 hover:bg-amber-600 shadow-amber-500/15' : 'bg-emerald-500 hover:bg-emerald-600 shadow-emerald-500/15'}`}
                id="btn-cocoon-toggle"
              >
                {timerRunning ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 fill-white" />}
              </button>
              <button
                onClick={logDistraction}
                className="px-4 py-2.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5"
                id="btn-cocoon-log-distraction"
              >
                <AlertTriangle className="w-4 h-4" />
                <span>Log Interruption ({distractions})</span>
              </button>
            </div>

            {/* Sound loop controls inside cocoon */}
            <div className="flex items-center gap-3 text-xs bg-white/3 border border-white/5 px-4 py-2.5 rounded-xl text-gray-400 relative z-10">
              <Music className="w-4 h-4 text-emerald-400" />
              <span>Playing: {musicTrack}</span>
              <span>•</span>
              <button 
                onClick={() => setIsMuted(!isMuted)}
                className="hover:text-white transition-colors"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Focus view (Standard mode) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="focus-mode-grid">
        {/* Timer Panel */}
        <div className="glass-panel p-6 rounded-2xl flex flex-col items-center justify-between space-y-6 lg:col-span-2 relative overflow-hidden" id="focus-timer-card">
          <div className="absolute top-0 left-0 w-full h-1 bg-gray-800">
            <div 
              className="h-full bg-emerald-500 transition-all duration-1000" 
              style={{ width: `${(timeLeft / (duration * 60)) * 100}%` }}
            ></div>
          </div>

          <div className="w-full flex justify-between items-center">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-xs font-semibold text-white">Eye-Safe Focus Room</span>
            </div>
            
            <button
              onClick={() => setFullCocoon(true)}
              className="px-3 py-1.5 bg-white/5 border border-white/10 hover:bg-white/10 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all"
              id="btn-trigger-cocoon"
            >
              <EyeOff className="w-3.5 h-3.5 text-emerald-400" />
              <span>Enter Cocoon Mode</span>
            </button>
          </div>

          {/* Time Dial */}
          <div className="my-6 text-center space-y-1">
            <div className="text-6xl sm:text-7xl font-display font-bold text-white font-mono tracking-tight select-none">
              {formatTime(timeLeft)}
            </div>
            <p className="text-xs text-gray-500 font-mono">FLOW INTERVAL</p>
          </div>

          {/* Sizing Toggles */}
          <div className="flex items-center gap-2 bg-white/5 rounded-xl p-1 border border-white/5">
            <button
              onClick={() => { setDuration(25); resetTimer(); }}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${duration === 25 ? "bg-emerald-500 text-white shadow" : "text-gray-400 hover:text-white"}`}
            >
              25 min (Pomodoro)
            </button>
            <button
              onClick={() => { setDuration(50); resetTimer(); }}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${duration === 50 ? "bg-emerald-500 text-white shadow" : "text-gray-400 hover:text-white"}`}
            >
              50 min (Consensus Sprint)
            </button>
          </div>

          {/* Sprints controls */}
          <div className="w-full grid grid-cols-3 gap-3 pt-4 border-t border-white/5">
            <button
              onClick={toggleTimer}
              className={`py-2.5 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-1.5 transition-all ${timerRunning ? 'bg-amber-500 hover:bg-amber-600' : 'bg-emerald-500 hover:bg-emerald-600'}`}
              id="btn-timer-toggle-standard"
            >
              {timerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white text-white" />}
              <span>{timerRunning ? "Pause" : "Start"}</span>
            </button>
            <button
              onClick={logDistraction}
              className="py-2.5 bg-white/5 hover:bg-rose-500/10 hover:text-rose-400 text-gray-400 border border-white/10 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
              id="btn-log-distraction-standard"
            >
              <AlertTriangle className="w-4 h-4" />
              <span>Interruption ({distractions})</span>
            </button>
            <button
              onClick={resetTimer}
              className="py-2.5 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/10 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
              id="btn-timer-reset"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reset</span>
            </button>
          </div>
        </div>

        {/* Configurations Side Panel */}
        <div className="space-y-6">
          {/* Linked Task Selector */}
          <div className="glass-panel p-5 rounded-2xl space-y-3" id="linked-task-card">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400">Anchor Your Focus</h3>
            <p className="text-xs text-gray-400 leading-relaxed">
              Anchor this Pomodoro session to an active obligation. Completion logs directly to the Database.
            </p>

            <div className="space-y-2 pt-1">
              <select
                value={selectedTask?.id || ""}
                onChange={(e) => setSelectedTask(tasks.find(t => t.id === e.target.value) || null)}
                className="w-full bg-gray-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                id="select-focus-task"
              >
                <option value="">General Sprint (Unanchored)</option>
                {tasks.filter(t => t.status === "pending").map(t => (
                  <option key={t.id} value={t.id}>{t.title}</option>
                ))}
              </select>

              {selectedTask && (
                <div className="p-3 bg-emerald-500/5 border border-emerald-500/10 rounded-xl space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-emerald-400 font-mono font-bold">
                    <span>OBLIGATION ATTACHED</span>
                    <span>EST: {selectedTask.estimatedHours}h</span>
                  </div>
                  <p className="text-xs text-white font-medium">{selectedTask.title}</p>
                </div>
              )}
            </div>
          </div>

          {/* Soundtrack selector */}
          <div className="glass-panel p-5 rounded-2xl space-y-3" id="focus-sounds-card">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400">Ambient Sound Machine</h3>
            <p className="text-xs text-gray-400">
              Select an auditory anchor to mask physical world distractions and boost memory consolidation.
            </p>

            <div className="space-y-2 pt-1 font-sans text-xs">
              {[
                { name: "Lofi Study Beats", desc: "Cozy vinyl beats for steady coding flow" },
                { name: "Alpine Forest Stream", desc: "Gentle water ripples to calm cognitive tension" },
                { name: "White Static Noise", desc: "Smooth baseline frequency to silence physical echoes" },
                { name: "Alpha Neural Waves", desc: "8Hz-12Hz binaural tracks targeting focus areas" }
              ].map((track, idx) => (
                <div 
                  key={idx}
                  onClick={() => setMusicTrack(track.name)}
                  className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${musicTrack === track.name ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-white/3 border-white/5 text-gray-400 hover:bg-white/5'}`}
                >
                  <div>
                    <span className="font-semibold block text-white text-[11px]">{track.name}</span>
                    <span className="text-[10px] opacity-75">{track.desc}</span>
                  </div>
                  <Music className="w-3.5 h-3.5 opacity-50 shrink-0" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
