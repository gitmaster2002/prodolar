import React, { useState } from "react";
import { 
  User, 
  Calendar, 
  Zap, 
  ShieldCheck, 
  Flame, 
  Clock, 
  Sparkles, 
  CheckCircle, 
  Moon, 
  Bell, 
  Shield, 
  RefreshCw, 
  Info
} from "lucide-react";

interface ProfileViewProps {
  tasksCount: number;
}

export default function ProfileView({ tasksCount }: ProfileViewProps) {
  // Gamification state
  const streak = 12;
  const tasksCompleted = 18;
  const hoursSaved = 23;
  const deadlinesPrevented = 6;

  // Settings states
  const [gcalSync, setGcalSync] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [notificationStyle, setNotificationStyle] = useState<"Aggressive" | "Normal" | "Minimal">("Aggressive");
  const [aiAggressiveness, setAiAggressiveness] = useState<"High" | "Medium" | "Low">("Medium");
  const [privacyMode, setPrivacyMode] = useState<"Strict" | "Balanced" | "Relaxed">("Balanced");

  return (
    <div className="space-y-8 max-w-4xl mx-auto text-black pb-12" id="profile-container">
      {/* Page Header */}
      <div className="border-b border-zinc-200 pb-5">
        <h1 className="text-2xl font-display font-bold text-black tracking-tight">Profile & Performance</h1>
        <p className="text-xs text-zinc-500 mt-1 font-mono">PRODOLAR CHIEF OF STAFF ACCOUNT</p>
      </div>

      {/* Gamification Grid (Streaks & Achievements - Minimal, No Coins/XP) */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4" id="stats-dashboard">
        {/* Streak card */}
        <div className="p-5 border border-zinc-200 bg-white hover:border-black transition-all flex flex-col justify-between h-28" id="profile-card-streak">
          <div className="flex items-center justify-between text-zinc-500">
            <span className="text-[10px] font-mono uppercase tracking-wider font-semibold">Consistency Streak</span>
            <Flame className="w-4 h-4 text-[#1a73e8]" />
          </div>
          <div>
            <span className="text-3xl font-bold font-mono tracking-tight text-black">{streak}</span>
            <span className="text-xs text-zinc-500 font-sans block">days in a row</span>
          </div>
        </div>

        {/* Tasks completed */}
        <div className="p-5 border border-zinc-200 bg-white hover:border-black transition-all flex flex-col justify-between h-28" id="profile-card-completed">
          <div className="flex items-center justify-between text-zinc-500">
            <span className="text-[10px] font-mono uppercase tracking-wider font-semibold">Tasks Completed</span>
            <CheckCircle className="w-4 h-4 text-[#1a73e8]" />
          </div>
          <div>
            <span className="text-3xl font-bold font-mono tracking-tight text-black">{tasksCompleted}</span>
            <span className="text-xs text-zinc-500 font-sans block">objectives secured</span>
          </div>
        </div>

        {/* Hours Saved */}
        <div className="p-5 border border-zinc-200 bg-white hover:border-black transition-all flex flex-col justify-between h-28" id="profile-card-saved">
          <div className="flex items-center justify-between text-zinc-500">
            <span className="text-[10px] font-mono uppercase tracking-wider font-semibold">Hours Recovered</span>
            <Clock className="w-4 h-4 text-[#1a73e8]" />
          </div>
          <div>
            <span className="text-3xl font-bold font-mono tracking-tight text-black">{hoursSaved}h</span>
            <span className="text-xs text-zinc-500 font-sans block">of proactive planning</span>
          </div>
        </div>

        {/* Deadlines Prevented */}
        <div className="p-5 border border-zinc-200 bg-white hover:border-black transition-all flex flex-col justify-between h-28" id="profile-card-prevented">
          <div className="flex items-center justify-between text-zinc-500">
            <span className="text-[10px] font-mono uppercase tracking-wider font-semibold">Failures Prevented</span>
            <ShieldCheck className="w-4 h-4 text-[#1a73e8]" />
          </div>
          <div>
            <span className="text-3xl font-bold font-mono tracking-tight text-black">{deadlinesPrevented}</span>
            <span className="text-xs text-zinc-500 font-sans block">high-risk rescues</span>
          </div>
        </div>
      </div>

      {/* User Information Block */}
      <div className="border border-zinc-200 p-6 bg-white space-y-4" id="user-details-section">
        <h2 className="text-xs font-mono uppercase tracking-widest text-zinc-400 font-semibold">Owner Metadata</h2>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-zinc-100 flex items-center justify-center border border-zinc-200 text-black text-lg font-bold font-mono">
              UJ
            </div>
            <div>
              <h3 className="text-sm font-bold text-black">Utsav Jha</h3>
              <p className="text-[11px] font-mono text-zinc-500">jha.utsav2002@gmail.com</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 text-[10px] font-mono border border-zinc-200 rounded uppercase font-semibold bg-zinc-50">
              Free Tier
            </span>
            <span className="px-2.5 py-1 text-[10px] font-mono border border-black rounded uppercase font-semibold bg-black text-white">
              Prodolar Chief Active
            </span>
          </div>
        </div>
      </div>

      {/* Core Settings Panel */}
      <div className="border border-zinc-200 p-6 bg-white space-y-6" id="settings-controls-section">
        <h2 className="text-xs font-mono uppercase tracking-widest text-zinc-400 font-semibold border-b border-zinc-100 pb-3">
          Prodolar Intervention Settings
        </h2>

        <div className="space-y-5">
          {/* Google Calendar Sync */}
          <div className="flex items-center justify-between py-2 border-b border-zinc-100">
            <div className="space-y-0.5">
              <span className="text-xs font-bold block text-black">Google Calendar Synchronizer</span>
              <span className="text-[11px] text-zinc-500 block">Proactively fetch external events, classes, and study blocks to avoid timeline congestion.</span>
            </div>
            <button
              id="btn-toggle-gcal"
              onClick={() => setGcalSync(!gcalSync)}
              className={`w-11 h-6 rounded-full transition-colors relative focus:outline-none border border-black ${gcalSync ? "bg-[#1a73e8]" : "bg-zinc-200"}`}
            >
              <span className={`w-4 h-4 rounded-full bg-white absolute top-1/2 -translate-y-1/2 transition-transform ${gcalSync ? "translate-x-6" : "translate-x-1"}`}></span>
            </button>
          </div>

          {/* Dark Mode toggle */}
          <div className="flex items-center justify-between py-2 border-b border-zinc-100">
            <div className="space-y-0.5">
              <span className="text-xs font-bold block text-black">Dark Mode Atmosphere</span>
              <span className="text-[11px] text-zinc-500 block">Toggle dark background palette for late evening high-energy focus slots.</span>
            </div>
            <button
              id="btn-toggle-dark"
              onClick={() => setDarkMode(!darkMode)}
              className={`w-11 h-6 rounded-full transition-colors relative focus:outline-none border border-black ${darkMode ? "bg-black" : "bg-zinc-200"}`}
            >
              <span className={`w-4 h-4 rounded-full bg-white absolute top-1/2 -translate-y-1/2 transition-transform ${darkMode ? "translate-x-6" : "translate-x-1"}`}></span>
            </button>
          </div>

          {/* Notification Style */}
          <div className="flex items-center justify-between py-2 border-b border-zinc-100">
            <div className="space-y-0.5">
              <span className="text-xs font-bold block text-black">Intervention Notification Style</span>
              <span className="text-[11px] text-zinc-500 block">How aggressively the AI Chief of Staff notifies you about high-risk deadlines.</span>
            </div>
            <div className="flex border border-zinc-300 rounded overflow-hidden">
              {(["Minimal", "Normal", "Aggressive"] as const).map((style) => (
                <button
                  key={style}
                  id={`btn-notify-${style}`}
                  onClick={() => setNotificationStyle(style)}
                  className={`px-3 py-1.5 text-[10px] font-mono transition-all font-semibold ${notificationStyle === style ? "bg-black text-white border-black" : "bg-white text-zinc-600 hover:bg-zinc-50"}`}
                >
                  {style}
                </button>
              ))}
            </div>
          </div>

          {/* AI Aggressiveness */}
          <div className="flex items-center justify-between py-2 border-b border-zinc-100">
            <div className="space-y-0.5">
              <span className="text-xs font-bold block text-black">AI Schedule Aggressiveness</span>
              <span className="text-[11px] text-zinc-500 block">Determines if the AI forces you to take focus sprints and automatically books slots.</span>
            </div>
            <div className="flex border border-zinc-300 rounded overflow-hidden">
              {(["Low", "Medium", "High"] as const).map((level) => (
                <button
                  key={level}
                  id={`btn-agg-${level}`}
                  onClick={() => setAiAggressiveness(level)}
                  className={`px-3 py-1.5 text-[10px] font-mono transition-all font-semibold ${aiAggressiveness === level ? "bg-black text-white border-black" : "bg-white text-zinc-600 hover:bg-zinc-50"}`}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>

          {/* Privacy Level */}
          <div className="flex items-center justify-between py-2">
            <div className="space-y-0.5">
              <span className="text-xs font-bold block text-black">Privacy Protection Zone</span>
              <span className="text-[11px] text-zinc-500 block">Choose how securely your environmental telemetry is held or analyzed on the server.</span>
            </div>
            <div className="flex border border-zinc-300 rounded overflow-hidden">
              {(["Strict", "Balanced", "Relaxed"] as const).map((mode) => (
                <button
                  key={mode}
                  id={`btn-privacy-${mode}`}
                  onClick={() => setPrivacyMode(mode)}
                  className={`px-3 py-1.5 text-[10px] font-mono transition-all font-semibold ${privacyMode === mode ? "bg-black text-white border-black" : "bg-white text-zinc-600 hover:bg-zinc-50"}`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Behavioral Psychology Integration Info */}
      <div className="p-5 border border-[#1a73e8]/20 bg-[#1a73e8]/5 rounded-lg flex gap-3 text-black" id="behavioral-coach-card">
        <Info className="w-5 h-5 text-[#1a73e8] shrink-0 mt-0.5" />
        <div className="space-y-1">
          <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-black">The Behavioral Engine (Psychological Interventions)</h3>
          <p className="text-xs text-zinc-700 leading-relaxed">
            Prodolar implements **evidence-based cognitive interventions** (including the **5-Minute Activation Rule**, the **Zeigarnik Momentum Loop**, **Future-Self projection metrics**, and **Loss-Framed time travel** calculations) directly inside your daily Dashboard and Focus Rooms. Rather than passive notification, Prodolar works on reducing barrier friction and helping your brain start!
          </p>
        </div>
      </div>
    </div>
  );
}
