import React from "react";
import { 
  Sliders, 
  User, 
  Database, 
  Bot, 
  ShieldCheck, 
  Save, 
  Sparkles,
  Info
} from "lucide-react";
import { SystemContext } from "../types";

interface SettingsViewProps {
  context: SystemContext;
  setContext: React.Dispatch<React.SetStateAction<SystemContext>>;
}

export default function SettingsView({ context, setContext }: SettingsViewProps) {
  const userEmail = "jha.utsav2002@gmail.com";

  return (
    <div className="space-y-6" id="settings-container">
      {/* Header */}
      <div>
        <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
          <Sliders className="w-5 h-5 text-emerald-400" />
          <span>System Settings</span>
        </h1>
        <p className="text-xs text-gray-400">Manage your active workspace profile, Firebase Firestore credentials, and Gemini API selections.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profile Card */}
        <div className="glass-panel p-5 rounded-2xl space-y-4" id="profile-settings-card">
          <h2 className="text-sm font-semibold text-white flex items-center gap-1.5">
            <User className="w-4 h-4 text-emerald-400" />
            <span>Firebase Auth Profile</span>
          </h2>
          <p className="text-xs text-gray-400">Authenticated workspace environment.</p>

          <div className="p-4 rounded-xl bg-white/5 border border-white/5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold text-sm">
              U
            </div>
            <div>
              <p className="text-xs font-semibold text-white">Utsav Jha</p>
              <p className="text-[10px] text-gray-500 font-mono">{userEmail}</p>
            </div>
          </div>

          <div className="text-[10px] text-emerald-400 font-mono bg-emerald-500/5 p-2 rounded-xl flex items-center gap-1.5 border border-emerald-500/10">
            <ShieldCheck className="w-4 h-4" />
            <span>Security Status: Secure Firebase Auth Token Active</span>
          </div>
        </div>

        {/* AI & Database Config */}
        <div className="glass-panel p-5 rounded-2xl space-y-4" id="infrastructure-settings-card">
          <h2 className="text-sm font-semibold text-white flex items-center gap-1.5">
            <Database className="w-4 h-4 text-emerald-400" />
            <span>Google Cloud Architecture</span>
          </h2>
          <p className="text-xs text-gray-400">Live GCP service mapping used by Deadline Guardian:</p>

          <div className="space-y-3 pt-1 text-xs">
            {/* Database */}
            <div className="p-3 bg-white/5 border border-white/5 rounded-xl flex justify-between items-center">
              <span className="text-gray-400">Cloud Database:</span>
              <span className="text-white font-mono font-semibold">Firebase Firestore</span>
            </div>

            {/* Model */}
            <div className="p-3 bg-white/5 border border-white/5 rounded-xl flex justify-between items-center">
              <span className="text-gray-400">Reasoning Core:</span>
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <Bot className="w-3.5 h-3.5" />
                <span>Gemini 2.5 Flash</span>
              </span>
            </div>

            {/* Region */}
            <div className="p-3 bg-white/5 border border-white/5 rounded-xl flex justify-between items-center">
              <span className="text-gray-400">Deployment Engine:</span>
              <span className="text-white font-mono">Cloud Run (Server + Client)</span>
            </div>
          </div>
        </div>

        {/* Documentation details */}
        <div className="glass-panel p-5 rounded-2xl lg:col-span-2 flex gap-3 bg-blue-500/5 border border-blue-500/10" id="docs-card">
          <Info className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h3 className="text-xs font-semibold text-white">Why This Is Stand-out Hackathon Tech</h3>
            <p className="text-[11px] text-gray-300 leading-relaxed">
              Unlike generic reminder checklists, this application runs a **6-agent cascade** coordinated by Gemini. The **Planner Agent** parses intent, the **Decomposer** establishes milestones, the **Priority Agent** runs Monte-Carlo-like success probabilities based on calendar congestion, the **Calendar Agent** locks in optimal energy slots, and the **Negotiator** provides tailored professional letters for high-risk allocations. All task and configuration logs persist securely inside **Firebase Firestore**.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
