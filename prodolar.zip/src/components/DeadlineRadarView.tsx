import React from "react";
import { 
  ShieldAlert, 
  Compass, 
  Calendar, 
  Clock, 
  CheckCircle, 
  AlertTriangle, 
  Sparkles,
  Bot,
  ArrowRight,
  FileText
} from "lucide-react";
import { motion } from "motion/react";
import { Task } from "../types";

interface DeadlineRadarViewProps {
  tasks: Task[];
  setPage: (page: string) => void;
}

export default function DeadlineRadarView({ tasks, setPage }: DeadlineRadarViewProps) {
  const pendingTasks = tasks.filter(t => t.status === "pending");

  // Determine risk categories
  const safeTasks = pendingTasks.filter(t => t.successProbability >= 80);
  const riskTasks = pendingTasks.filter(t => t.successProbability >= 60 && t.successProbability < 80);
  const criticalTasks = pendingTasks.filter(t => t.successProbability < 60);

  // Group tasks by deadline days remaining
  const getDaysRemaining = (deadlineStr: string) => {
    const diff = new Date(deadlineStr).getTime() - Date.now();
    return Math.ceil(diff / (86400000));
  };

  return (
    <div className="space-y-6" id="radar-container">
      {/* Header */}
      <div>
        <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
          <Compass className="w-5 h-5 text-emerald-400" />
          <span>Deadline Collision Radar</span>
        </h1>
        <p className="text-xs text-gray-400">AI-driven predictive analysis mapping proximity against completion probabilities.</p>
      </div>

      {/* Grid mapping */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="radar-columns">
        {/* Critical Overload */}
        <div className="glass-panel p-5 rounded-2xl space-y-4 border-l-4 border-rose-500" id="radar-critical">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-rose-500 animate-pulse" />
              <span>Collision Risk (Red)</span>
            </span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/10">
              {criticalTasks.length} Overloads
            </span>
          </div>
          <p className="text-xs text-gray-400">Completion probability is under 60%. Highly recommended to activate AI Negotiator immediately.</p>

          <div className="space-y-3 pt-2">
            {criticalTasks.map(task => {
              const days = getDaysRemaining(task.deadline);
              return (
                <div key={task.id} className="p-3.5 bg-rose-500/5 border border-rose-500/10 rounded-xl space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-xs font-semibold text-white">{task.title}</span>
                    <span className="text-[10px] font-bold text-rose-400 font-mono shrink-0 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/10">
                      {task.successProbability}% Prob
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-[10px] text-gray-500 font-mono pt-1 border-t border-white/5">
                    <span className="flex items-center gap-0.5">
                      <Clock className="w-3 h-3 text-rose-400" />
                      <span>{days <= 0 ? "OVERDUE" : `Due in ${days} days`}</span>
                    </span>
                    <button
                      onClick={() => setPage("tasks")}
                      className="text-rose-400 font-semibold flex items-center gap-0.5 hover:underline"
                    >
                      <span>Negotiate</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
            {criticalTasks.length === 0 && (
              <p className="text-xs text-gray-500 text-center py-8">No high-risk deadline collisions detected.</p>
            )}
          </div>
        </div>

        {/* Moderate Risk */}
        <div className="glass-panel p-5 rounded-2xl space-y-4 border-l-4 border-amber-500" id="radar-warning">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <span>Watch Interval (Yellow)</span>
            </span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/10">
              {riskTasks.length} Warnings
            </span>
          </div>
          <p className="text-xs text-gray-400">Completion probability is between 60% and 80%. Calendar margins are tightening.</p>

          <div className="space-y-3 pt-2">
            {riskTasks.map(task => {
              const days = getDaysRemaining(task.deadline);
              return (
                <div key={task.id} className="p-3.5 bg-amber-500/5 border border-amber-500/10 rounded-xl space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-xs font-semibold text-white">{task.title}</span>
                    <span className="text-[10px] font-bold text-amber-400 font-mono shrink-0 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/10">
                      {task.successProbability}% Prob
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-[10px] text-gray-500 font-mono pt-1 border-t border-white/5">
                    <span className="flex items-center gap-0.5">
                      <Clock className="w-3 h-3 text-amber-400" />
                      <span>Due in {days} days</span>
                    </span>
                    <button
                      onClick={() => setPage("calendar")}
                      className="text-amber-400 font-semibold flex items-center gap-0.5 hover:underline"
                    >
                      <span>Adjust Blocks</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
            {riskTasks.length === 0 && (
              <p className="text-xs text-gray-500 text-center py-8">No moderate risks scheduled. Your schedule blocks are perfectly balanced.</p>
            )}
          </div>
        </div>

        {/* Safe Zone */}
        <div className="glass-panel p-5 rounded-2xl space-y-4 border-l-4 border-emerald-500" id="radar-safe">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-emerald-500" />
              <span>Safe Zone (Green)</span>
            </span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/10">
              {safeTasks.length} Secured
            </span>
          </div>
          <p className="text-xs text-gray-400">Completion probability is above 80%. Wide margins and zero active conflicts.</p>

          <div className="space-y-3 pt-2">
            {safeTasks.map(task => {
              const days = getDaysRemaining(task.deadline);
              return (
                <div key={task.id} className="p-3.5 bg-emerald-500/5 border border-emerald-500/10 rounded-xl space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-xs font-semibold text-white">{task.title}</span>
                    <span className="text-[10px] font-bold text-emerald-400 font-mono shrink-0 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/10">
                      {task.successProbability}% Prob
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-[10px] text-gray-500 font-mono pt-1 border-t border-white/5">
                    <span className="flex items-center gap-0.5">
                      <Clock className="w-3 h-3 text-emerald-400" />
                      <span>Due in {days} days</span>
                    </span>
                    <button
                      onClick={() => setPage("focus")}
                      className="text-emerald-400 font-semibold flex items-center gap-0.5 hover:underline"
                    >
                      <span>Focus Run</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
            {safeTasks.length === 0 && (
              <p className="text-xs text-gray-500 text-center py-8">All tasks require effort multipliers. Use AI Planner to re-optimize.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
