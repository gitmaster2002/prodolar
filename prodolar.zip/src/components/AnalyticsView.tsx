import React from "react";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell,
  Legend 
} from "recharts";
import { 
  TrendingUp, 
  Zap, 
  BarChart3, 
  PieChart as PieIcon, 
  Clock, 
  Activity,
  Bot
} from "lucide-react";
import { Task, FocusSession } from "../types";

interface AnalyticsViewProps {
  tasks: Task[];
  focusSessions: FocusSession[];
}

export default function AnalyticsView({ tasks, focusSessions }: AnalyticsViewProps) {
  // 1. Success Probability Trend data
  const trendData = [
    { name: "Mon", probability: 52 },
    { name: "Tue", probability: 48 },
    { name: "Wed", probability: 42 }, // Overload peak!
    { name: "Thu", probability: 68 }, // Rebuilt day
    { name: "Fri", probability: 78 }, // Success rising
    { name: "Sat", probability: 91 },
    { name: "Sun", probability: 94 }
  ];

  // 2. Category / Energy level allocation
  const pendingTasks = tasks.filter(t => t.status === "pending");
  const categoriesCount: Record<string, number> = {};
  pendingTasks.forEach(t => {
    categoriesCount[t.category] = (categoriesCount[t.category] || 0) + t.estimatedHours;
  });

  const categoryData = Object.entries(categoriesCount).map(([name, value]) => ({
    name,
    value
  }));

  const COLORS = ["#10b981", "#3b82f6", "#f59e0b", "#ec4899", "#8b5cf6", "#6b7280"];

  // 3. Planned vs. Actual Work hours (Adaptive learning simulation)
  const learningData = [
    { name: "Algorithms", planned: 4.0, actual: 5.5, error: "+1.5h" },
    { name: "Backpropagation", planned: 5.0, actual: 6.5, error: "+1.5h" },
    { name: "Database Schema", planned: 3.0, actual: 3.2, error: "+0.2h" },
    { name: "UI contrast", planned: 2.0, actual: 1.8, error: "-0.2h" },
    { name: "Quant practice", planned: 3.0, actual: 3.5, error: "+0.5h" }
  ];

  // 4. Distractions Analytics (Distractions count during Focus Pomodoro)
  const totalDistractions = focusSessions.reduce((sum, s) => sum + s.distractionsCount, 0);
  const avgDistractions = focusSessions.length > 0 
    ? (totalDistractions / focusSessions.length).toFixed(1)
    : "0";

  return (
    <div className="space-y-6" id="analytics-container">
      {/* Header */}
      <div>
        <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
          <Activity className="w-5 h-5 text-emerald-400" />
          <span>Cognitive Performance Analytics</span>
        </h1>
        <p className="text-xs text-gray-400">Review success prediction metrics, effort calibration histories, and focus efficiency indices.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Success Probability Trend Area Chart */}
        <div className="glass-panel p-5 rounded-2xl space-y-4" id="chart-probability-trend">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-white flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>AI Success Prediction Trend</span>
            </span>
            <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2.5 py-0.5 rounded-full font-bold">
              +42% Growth This Week
            </span>
          </div>
          
          <div className="h-64 pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="probGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff0a" vertical={false} />
                <XAxis dataKey="name" stroke="#ffffff40" fontSize={10} tickLine={false} />
                <YAxis stroke="#ffffff40" fontSize={10} tickLine={false} domain={[0, 100]} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#111827", borderColor: "#ffffff14", borderRadius: "12px", fontSize: "11px" }}
                  labelStyle={{ color: "#9ca3af" }}
                />
                <Area type="monotone" dataKey="probability" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#probGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[11px] text-gray-400 leading-relaxed italic">
            <strong>Adaptive Note:</strong> On Wednesday, your scheduling density peaked causing a severe drop in predicted completion success (42%). Following the auto-negotiated extension, your margins normalized to 94%.
          </p>
        </div>

        {/* Planned vs Actual hours calibration Bar Chart */}
        <div className="glass-panel p-5 rounded-2xl space-y-4" id="chart-planned-actual">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-white flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-amber-400" />
              <span>Adaptive Calibration (Planned vs. Actual)</span>
            </span>
            <span className="text-[10px] text-gray-400 font-mono">Calibrated daily</span>
          </div>

          <div className="h-64 pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={learningData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff0a" vertical={false} />
                <XAxis dataKey="name" stroke="#ffffff40" fontSize={10} tickLine={false} />
                <YAxis stroke="#ffffff40" fontSize={10} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#111827", borderColor: "#ffffff14", borderRadius: "12px", fontSize: "11px" }}
                  labelStyle={{ color: "#9ca3af" }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: "10px" }} />
                <Bar dataKey="planned" fill="#ffffff20" radius={[4, 4, 0, 0]} name="Original Plan (Hours)" />
                <Bar dataKey="actual" fill="#f59e0b" radius={[4, 4, 0, 0]} name="Actual Elapsed (Hours)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="p-3 bg-amber-500/5 border border-amber-500/10 rounded-xl flex gap-2">
            <Bot className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
            <span className="text-[11px] text-amber-300">
              <strong>Estimator Calibration:</strong> Algorithms & Backprop categories exhibit a systematic overshoot (+1.5 hours slower). The AI Coach has configured a 1.3x multiplier for future study estimation tasks automatically.
            </span>
          </div>
        </div>

        {/* Category Share Pie Chart */}
        <div className="glass-panel p-5 rounded-2xl space-y-4" id="chart-category-distribution">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-white flex items-center gap-1.5">
              <PieIcon className="w-4 h-4 text-blue-400" />
              <span>Cognitive Energy Allocation (Hrs)</span>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 items-center gap-4">
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData.length > 0 ? categoryData : [{ name: "No active tasks", value: 1 }]}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                    {categoryData.length === 0 && <Cell fill="#ffffff10" />}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#111827", borderColor: "#ffffff14", borderRadius: "12px", fontSize: "11px" }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-2">
              {categoryData.map((entry, idx) => (
                <div key={idx} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[idx % COLORS.length] }}></span>
                    <span className="text-gray-300">{entry.name}</span>
                  </div>
                  <span className="font-mono text-white font-semibold">{entry.value}h</span>
                </div>
              ))}
              {categoryData.length === 0 && (
                <p className="text-xs text-gray-500 italic">No pending tasks to track energy distribution.</p>
              )}
            </div>
          </div>
        </div>

        {/* Focus Efficiency Stats */}
        <div className="glass-panel p-5 rounded-2xl flex flex-col justify-between space-y-4" id="chart-focus-stats">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-white flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-orange-400" />
              <span>Pomodoro focus efficiency logs</span>
            </span>
            <p className="text-xs text-gray-400">Observing distraction intervals logged during active timer sessions.</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-white/5 border border-white/5 rounded-2xl text-center space-y-1">
              <span className="text-3xl font-display font-bold text-white tracking-tight">{focusSessions.length}</span>
              <p className="text-[10px] uppercase text-gray-500 font-mono font-medium">Completed sprints</p>
            </div>
            <div className="p-4 bg-white/5 border border-white/5 rounded-2xl text-center space-y-1">
              <span className="text-3xl font-display font-bold text-rose-400 tracking-tight">{avgDistractions}</span>
              <p className="text-[10px] uppercase text-gray-500 font-mono font-medium">Distractions / hour</p>
            </div>
          </div>

          <div className="p-3 bg-emerald-500/5 border border-emerald-500/10 rounded-xl text-[11px] text-gray-300 leading-relaxed">
            🌿 <strong>Guardian Coaching Feedback:</strong> Keeping your study sessions at exactly 50 minutes (instead of 25) reduces task switching cost. Your focus duration yesterday maximized active memory retention.
          </div>
        </div>
      </div>
    </div>
  );
}
