import React, { useState, useEffect, useRef } from "react";
import { 
  Sparkles, 
  Mic, 
  MicOff, 
  Clock, 
  CheckCircle, 
  Volume2, 
  VolumeX, 
  Calendar, 
  Plus, 
  Trash2, 
  ArrowRight, 
  Smartphone, 
  Battery, 
  Wifi, 
  ShieldAlert, 
  RefreshCw, 
  ShieldCheck, 
  Play, 
  Lock,
  Compass
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Task, CalendarEvent } from "../types";
import { DataService } from "../lib/dataService";

interface MorningBriefingWidgetProps {
  tasks: Task[];
  events: CalendarEvent[];
  triggerToast: (msg: string, type: "info" | "warning" | "success") => void;
  onPlanGenerated?: (newTasks: Task[]) => Promise<void>;
  onClose?: () => void;
}

interface ExtraGoal {
  id: string;
  title: string;
  estimatedHours: number;
}

interface ScheduledItem {
  id: string;
  type: "task" | "event" | "extra" | "buffer";
  title: string;
  startStr: string; // HH:MM AM/PM
  endStr: string;
  durationMinutes: number;
  bufferDescription?: string;
}

export default function MorningBriefingWidget({
  tasks,
  events,
  triggerToast,
  onPlanGenerated,
  onClose
}: MorningBriefingWidgetProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [extraGoals, setExtraGoals] = useState<ExtraGoal[]>([]);
  const [manualGoalText, setManualGoalText] = useState("");
  const [manualGoalHours, setManualGoalHours] = useState(1);
  
  // Mobile / Voice State
  const [isRecording, setIsRecording] = useState(false);
  const [speechTranscript, setSpeechTranscript] = useState("");
  const [voicePlaybackMuted, setVoicePlaybackMuted] = useState(false);
  const recognitionRef = useRef<any>(null);

  // Buffer Size State
  const [bufferMinutes, setBufferMinutes] = useState(15);
  const [alignedSchedule, setAlignedSchedule] = useState<ScheduledItem[]>([]);

  // Distraction simulation state
  const [simulatedDistractionActive, setSimulatedDistractionActive] = useState(false);
  const [distractionCountdown, setDistractionCountdown] = useState(0);
  const countdownTimerRef = useRef<any>(null);

  // Generate Today's Briefing text content
  const todayTasks = tasks.filter(t => t.status === "pending");
  const todayEvents = events.filter(e => {
    // Check if event is scheduled for today (or default to today for simplicity)
    return true; 
  }).slice(0, 3);

  const getBriefText = () => {
    const taskCount = todayTasks.length;
    const highTasks = todayTasks.filter(t => t.priority === "high").length;
    const totalEst = todayTasks.reduce((acc, t) => acc + t.estimatedHours, 0);

    let summary = `Good morning, Utsav! Today is ${new Date().toLocaleDateString("en-US", { weekday: 'long', month: 'long', day: 'numeric' })}. Your academic defense pipeline is active. `;
    summary += `You have ${taskCount} pending tasks representing ${totalEst} hours of estimated deep focus. `;
    if (highTasks > 0) {
      summary += `Of these, ${highTasks} are critical high-priority deadlines that cannot slip. `;
    }
    summary += "I have initialized your core timeline with twenty minute distraction recovery buffers to secure your attention. What else must we execute today?";
    return summary;
  };

  // Speak Morning Brief out loud
  const speakBrief = () => {
    if (!window.speechSynthesis || voicePlaybackMuted) return;
    
    window.speechSynthesis.cancel();
    const briefText = getBriefText();
    const utterance = new SpeechSynthesisUtterance(briefText);
    utterance.rate = 1.05;
    utterance.pitch = 0.95; // authoritative low tone

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    triggerToast("Reading morning briefing vocal feed...", "info");
  };

  // Web Speech recognition setup
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recog = new SpeechRecognition();
      recog.continuous = false;
      recog.interimResults = true;
      recog.lang = "en-US";

      recog.onstart = () => {
        setIsRecording(true);
        setSpeechTranscript("");
      };

      recog.onerror = (e: any) => {
        setIsRecording(false);
        console.warn("Speech recognition error:", e);
        triggerToast("Vocal recognition failed or timed out. Feel free to type manually!", "warning");
      };

      recog.onend = () => {
        setIsRecording(false);
      };

      recog.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setSpeechTranscript(transcript);

        if (event.results[0].isFinal && transcript.trim()) {
          addVoiceGoal(transcript);
        }
      };

      recognitionRef.current = recog;
    }

    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      clearInterval(countdownTimerRef.current);
    };
  }, [extraGoals]);

  // Voice recording toggle
  const toggleRecording = () => {
    if (isRecording) {
      recognitionRef.current?.stop();
    } else {
      if (!recognitionRef.current) {
        triggerToast("Web Speech API not supported in this browser. Please use keyboard input!", "warning");
        return;
      }
      try {
        recognitionRef.current.start();
      } catch (err) {
        console.error(err);
      }
    }
  };

  const addVoiceGoal = (text: string) => {
    if (!text.trim()) return;
    const cleanText = text.replace(/^(add|create|schedule|i want to|we need to)\s+/i, "");
    const hoursMatch = text.match(/(\d+)\s*hours?/i);
    const estimatedHours = hoursMatch ? parseInt(hoursMatch[1]) : 1;

    const newGoal: ExtraGoal = {
      id: `extra-${Date.now()}`,
      title: cleanText.charAt(0).toUpperCase() + cleanText.slice(1),
      estimatedHours: estimatedHours || 1
    };

    setExtraGoals(prev => [...prev, newGoal]);
    setSpeechTranscript("");
    triggerToast(`Added goal: "${newGoal.title}" via voice!`, "success");

    // Readout confirmation
    speakResponse(`Added ${newGoal.title} to today's objectives.`);
  };

  const handleAddManualGoal = () => {
    if (!manualGoalText.trim()) return;
    const newGoal: ExtraGoal = {
      id: `extra-${Date.now()}`,
      title: manualGoalText.trim(),
      estimatedHours: Number(manualGoalHours) || 1
    };
    setExtraGoals(prev => [...prev, newGoal]);
    setManualGoalText("");
    setManualGoalHours(1);
    triggerToast("New objective added!", "success");
    speakResponse(`Added ${newGoal.title}.`);
  };

  const handleDeleteGoal = (id: string) => {
    setExtraGoals(prev => prev.filter(g => g.id !== id));
    triggerToast("Objective removed.", "info");
  };

  const speakResponse = (text: string) => {
    if (voicePlaybackMuted || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 0.95;
    window.speechSynthesis.speak(utterance);
  };

  // Beautiful sequential day alignment algorithm with custom distraction recovery buffers
  const runAlignmentScheduler = () => {
    const scheduled: ScheduledItem[] = [];
    
    // Start alignment at 9:00 AM of today (or round up if current hour is past 9)
    const now = new Date();
    let startHour = 9;
    let startMinutes = 0;

    if (now.getHours() >= 9) {
      startHour = now.getHours();
      startMinutes = now.getMinutes() >= 30 ? 30 : 0;
      if (now.getMinutes() > 30) {
        startHour += 1;
        startMinutes = 0;
      }
    }

    let currentTotalMinutes = startHour * 60 + startMinutes;

    const formatMinutesToTime = (totalMin: number): string => {
      let hour = Math.floor(totalMin / 60) % 24;
      const minutes = totalMin % 60;
      const ampm = hour >= 12 ? "PM" : "AM";
      hour = hour % 12;
      hour = hour ? hour : 12; // 12 instead of 0
      const minStr = minutes.toString().padStart(2, "0");
      return `${hour}:${minStr} ${ampm}`;
    };

    // 1. Fixed Calendar Events scheduled for today
    // Let's assume today's events run at their specified times. For visualization, we can show them or slide other tasks around them.
    // To make it incredibly elegant, we sequence the tasks and extra goals first, placing buffers in between.
    
    // Compile active elements
    const elementsToSchedule: Array<{ id: string; type: "task" | "extra"; title: string; hours: number }> = [];
    
    // Add pending tasks (sorted by high priority first)
    todayTasks.forEach(t => {
      elementsToSchedule.push({
        id: t.id,
        type: "task",
        title: t.title,
        hours: t.estimatedHours || 2
      });
    });

    // Add new extra achievements
    extraGoals.forEach(g => {
      elementsToSchedule.push({
        id: g.id,
        type: "extra",
        title: g.title,
        hours: g.estimatedHours || 1
      });
    });

    // Schedule sequentially
    elementsToSchedule.forEach((item, index) => {
      const durationMin = Math.round(item.hours * 60);
      const startStr = formatMinutesToTime(currentTotalMinutes);
      currentTotalMinutes += durationMin;
      const endStr = formatMinutesToTime(currentTotalMinutes);

      scheduled.push({
        id: item.id,
        type: item.type,
        title: item.title,
        startStr,
        endStr,
        durationMinutes: durationMin
      });

      // Inject Distraction Recovery Buffer slot after every item (unless it's the last item)
      if (index < elementsToSchedule.length - 1) {
        const bufferStart = formatMinutesToTime(currentTotalMinutes);
        currentTotalMinutes += bufferMinutes;
        const bufferEnd = formatMinutesToTime(currentTotalMinutes);

        scheduled.push({
          id: `buffer-${index}-${Date.now()}`,
          type: "buffer",
          title: `🟢 Distraction Recovery Buffer`,
          startStr: bufferStart,
          endStr: bufferEnd,
          durationMinutes: bufferMinutes,
          bufferDescription: "If you lose focus, stray onto social media, or drift, use these fifteen minutes to self-correct and re-center."
        });
      }
    });

    setAlignedSchedule(scheduled);
  };

  // Re-run scheduler whenever goals or buffers change
  useEffect(() => {
    runAlignmentScheduler();
  }, [extraGoals, bufferMinutes, tasks]);

  // Handle locking the guarded day plan
  const handleDeployGuardedPlan = async () => {
    try {
      // 1. Create Firestore tasks for the newly specified extra goals
      const tasksToDeploy: Task[] = [];

      for (const goal of extraGoals) {
        const deadlineDate = new Date();
        deadlineDate.setDate(deadlineDate.getDate() + 1); // due tomorrow

        const newTask: Task = {
          id: `extra-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          title: goal.title,
          description: "Created via morning briefing alignment",
          deadline: deadlineDate.toISOString(),
          priority: "medium",
          energy: "medium",
          status: "pending",
          estimatedHours: goal.estimatedHours,
          actualHours: 0,
          category: "Personal",
          subtasks: [],
          successProbability: 88,
          dependencies: [],
          timeBlock: null,
          replannedAt: null,
          historicalReplansCount: 0,
          createdAt: new Date().toISOString()
        };

        // Save to Firestore / local storage
        await DataService.saveTask(newTask);
        tasksToDeploy.push(newTask);
      }

      // Also let's update current scheduled time blocks in the database
      // Map scheduled items back to tasks and update their timeBlock
      for (const item of alignedSchedule) {
        if (item.type === "task") {
          const originalTask = tasks.find(t => t.id === item.id);
          if (originalTask) {
            // Convert startStr and endStr back into absolute Date timestamps
            const today = new Date();
            const parseTime = (timeStr: string) => {
              const [time, ampm] = timeStr.split(" ");
              let [hours, minutes] = time.split(":").map(Number);
              if (ampm === "PM" && hours < 12) hours += 12;
              if (ampm === "AM" && hours === 12) hours = 0;
              const date = new Date(today);
              date.setHours(hours, minutes, 0, 0);
              return date.toISOString();
            };

            const updatedTask: Task = {
              ...originalTask,
              timeBlock: {
                start: parseTime(item.startStr),
                end: parseTime(item.endStr)
              },
              replannedAt: new Date().toISOString()
            };
            await DataService.saveTask(updatedTask);
          }
        }
      }

      triggerToast(`Safeguarded day agenda secured with ${alignedSchedule.filter(i => i.type === 'buffer').length} distraction recovery slots!`, "success");
      speakResponse("Your guarded daily plan is locked. Standby for focus activation.");
      
      if (onClose) {
        onClose();
      }
    } catch (e) {
      console.error(e);
      triggerToast("Error deploying scheduled plan.", "warning");
    }
  };

  // Simulate a real-time distraction warning
  const triggerDistractionSimulation = () => {
    setSimulatedDistractionActive(true);
    setDistractionCountdown(15); // minutes left in buffer
    
    // Play alert sound synthesis
    speakResponse("Alert! Distraction drifting detected on mobile device. Social feeds are locked. You have fifteen minutes remaining in your distraction recovery buffer. Close the tab immediately and return to task.");

    // Countdown interval
    clearInterval(countdownTimerRef.current);
    countdownTimerRef.current = setInterval(() => {
      setDistractionCountdown(prev => {
        if (prev <= 1) {
          clearInterval(countdownTimerRef.current);
          setSimulatedDistractionActive(false);
          return 0;
        }
        return prev - 1;
      });
    }, 5000); // speed up simulation (every 5s is 1 min)
  };

  return (
    <div className="border border-zinc-300 bg-zinc-50/40 p-6 rounded-xl space-y-6 text-black" id="morning-alignment-suite">
      
      {/* Header Banner */}
      <div className="flex items-start justify-between flex-wrap gap-4 border-b border-zinc-200 pb-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono border border-[#1a73e8]/30 bg-[#1a73e8]/5 text-[#1a73e8] font-bold">
            <Compass className="w-3.5 h-3.5" />
            <span>DAILY ALIGNMENT SYSTEM</span>
          </div>
          <h2 className="text-xl font-display font-extrabold tracking-tight">Morning Executive Interceptor</h2>
          <p className="text-xs text-zinc-500 font-mono">ALIGNING NEW OBLIGATIONS & SECURING DISTRACTION RECOVERY BUFFERS</p>
        </div>
        
        {/* Step Indicator */}
        <div className="flex items-center gap-1.5 bg-white border border-zinc-200 px-3 py-1 rounded font-mono text-[11px] font-semibold">
          <span className={step === 1 ? "text-black font-bold" : "text-zinc-400"}>1. Brief</span>
          <span className="text-zinc-300">→</span>
          <span className={step === 2 ? "text-black font-bold" : "text-zinc-400"}>2. Achieve</span>
          <span className="text-zinc-300">→</span>
          <span className={step === 3 ? "text-black font-bold" : "text-zinc-400"}>3. Align</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        
        {/* Left Column: Interactive Wizard Steps (7 cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-6" id="wizard-steps-container">
          
          <AnimatePresence mode="wait">
            {/* STEP 1: Morning Briefing Readout */}
            {step === 1 && (
              <motion.div
                key="step-1"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="space-y-4"
              >
                <div className="bg-white border border-zinc-200 p-5 rounded-lg space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-wider font-bold text-[#1a73e8]">Consensus Daily Feed</span>
                    
                    {/* Speak Button */}
                    <button
                      onClick={speakBrief}
                      id="btn-voice-readout"
                      className={`px-3 py-1 rounded border text-xs font-mono font-semibold flex items-center gap-1.5 transition-colors ${
                        isSpeaking 
                          ? "bg-black text-white border-black animate-pulse" 
                          : "bg-white hover:bg-zinc-100 text-zinc-700 border-zinc-200"
                      }`}
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>{isSpeaking ? "Vocalizing..." : "Vocal Brief"}</span>
                    </button>
                  </div>

                  <p className="text-sm text-zinc-800 leading-relaxed font-sans">
                    {getBriefText()}
                  </p>

                  {/* Summary grid */}
                  <div className="grid grid-cols-3 gap-3 pt-2">
                    <div className="bg-zinc-50 border border-zinc-200 p-3 rounded text-center">
                      <div className="text-[10px] font-mono text-zinc-400 uppercase">Total Tasks</div>
                      <div className="text-lg font-bold text-black font-mono mt-0.5">{todayTasks.length}</div>
                    </div>
                    <div className="bg-zinc-50 border border-zinc-200 p-3 rounded text-center">
                      <div className="text-[10px] font-mono text-zinc-400 uppercase">Critical Due</div>
                      <div className="text-lg font-bold text-red-600 font-mono mt-0.5">
                        {todayTasks.filter(t => t.priority === "high").length}
                      </div>
                    </div>
                    <div className="bg-zinc-50 border border-zinc-200 p-3 rounded text-center">
                      <div className="text-[10px] font-mono text-zinc-400 uppercase">Total Volume</div>
                      <div className="text-lg font-bold text-black font-mono mt-0.5">
                        {todayTasks.reduce((acc, t) => acc + t.estimatedHours, 0)} Hrs
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    onClick={() => {
                      if (window.speechSynthesis) window.speechSynthesis.cancel();
                      setIsSpeaking(false);
                      setStep(2);
                    }}
                    className="px-5 py-2.5 bg-black hover:bg-zinc-900 border border-black text-white rounded text-xs font-bold font-mono uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-sm"
                  >
                    <span>Define Today's Goals</span>
                    <ArrowRight className="w-4 h-4 text-white" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 2: Input Extra Goals */}
            {step === 2 && (
              <motion.div
                key="step-2"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="space-y-4"
              >
                <div className="bg-white border border-zinc-200 p-5 rounded-lg space-y-4">
                  <div>
                    <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-zinc-500">Add Extra Achievements</h3>
                    <p className="text-xs text-zinc-600 mt-1">
                      What else do you want to accomplish today apart from existing academic deadlines? Write below or tap the microphone on the phone simulator!
                    </p>
                  </div>

                  {/* Manual goal addition input bar */}
                  <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
                    <input
                      type="text"
                      placeholder="e.g. Gym leg session, Buy consensus books..."
                      value={manualGoalText}
                      onChange={(e) => setManualGoalText(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleAddManualGoal()}
                      className="flex-1 bg-white border border-zinc-300 rounded px-3.5 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-black placeholder-zinc-400 text-black"
                    />
                    
                    <div className="flex items-center gap-1">
                      <select
                        value={manualGoalHours}
                        onChange={(e) => setManualGoalHours(Number(e.target.value))}
                        className="px-2.5 py-2 border border-zinc-300 rounded text-xs font-mono text-zinc-800 bg-white"
                        title="Estimated Hours"
                      >
                        {[0.5, 1, 1.5, 2, 3, 4].map(h => (
                          <option key={h} value={h}>{h} hr</option>
                        ))}
                      </select>

                      <button
                        onClick={handleAddManualGoal}
                        className="p-2 bg-black text-white hover:bg-zinc-800 rounded border border-black flex items-center justify-center shrink-0"
                      >
                        <Plus className="w-4 h-4 text-white" />
                      </button>
                    </div>
                  </div>

                  {/* Added Achievements list */}
                  <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                    <span className="text-[10px] font-mono uppercase text-zinc-400 font-bold block">Extra Achievements Today ({extraGoals.length})</span>
                    {extraGoals.map((goal) => (
                      <div 
                        key={goal.id}
                        className="flex items-center justify-between p-2.5 bg-zinc-50 border border-zinc-200 rounded text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-[#1a73e8]" />
                          <span className="font-semibold text-black">{goal.title}</span>
                          <span className="text-[10px] font-mono text-zinc-400">({goal.estimatedHours}h)</span>
                        </div>
                        <button
                          onClick={() => handleDeleteGoal(goal.id)}
                          className="text-zinc-400 hover:text-red-600 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}

                    {extraGoals.length === 0 && (
                      <div className="p-4 border border-dashed border-zinc-200 rounded text-center text-xs text-zinc-400 italic">
                        No extra goals added yet. Speak or type some!
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex justify-between pt-2">
                  <button
                    onClick={() => setStep(1)}
                    className="px-4 py-2 border border-zinc-300 hover:border-black rounded text-xs font-semibold"
                  >
                    Back to Brief
                  </button>

                  <button
                    onClick={() => setStep(3)}
                    className="px-5 py-2.5 bg-black hover:bg-zinc-900 border border-black text-white rounded text-xs font-bold font-mono uppercase tracking-wider flex items-center gap-1.5 shadow-sm"
                  >
                    <span>Align & Buffer Day</span>
                    <ArrowRight className="w-4 h-4 text-white" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 3: Guarded Day Planner Timeline */}
            {step === 3 && (
              <motion.div
                key="step-3"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="space-y-4"
              >
                <div className="bg-white border border-zinc-200 p-5 rounded-lg space-y-4">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div>
                      <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-[#1a73e8]">Guarded Distraction-Buffered Schedule</h3>
                      <p className="text-xs text-zinc-500 mt-0.5">Every deep work session is padded with recovery slots to prevent straying.</p>
                    </div>

                    {/* Buffer size selection */}
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] font-mono text-zinc-500 font-bold uppercase">Buffer Size:</span>
                      <select
                        value={bufferMinutes}
                        onChange={(e) => setBufferMinutes(Number(e.target.value))}
                        className="px-2 py-1 border border-zinc-300 rounded text-[11px] font-mono bg-white text-zinc-800"
                        title="Set day distraction buffer"
                      >
                        <option value={10}>10 Min</option>
                        <option value={15}>15 Min</option>
                        <option value={20}>20 Min</option>
                      </select>
                    </div>
                  </div>

                  {/* Vertical Timeline preview */}
                  <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                    {alignedSchedule.map((item, idx) => {
                      const isBuffer = item.type === "buffer";
                      const isExtra = item.type === "extra";
                      const isTask = item.type === "task";

                      return (
                        <div 
                          key={item.id}
                          className={`p-3 border rounded-lg text-xs flex items-start gap-3 transition-colors ${
                            isBuffer 
                              ? "bg-emerald-50/70 border-emerald-200 text-emerald-900" 
                              : isExtra 
                                ? "bg-amber-50/50 border-amber-200 text-amber-900"
                                : "bg-zinc-50 border-zinc-200 text-black"
                          }`}
                        >
                          {/* Left Time Badge */}
                          <div className="w-20 shrink-0 font-mono text-[10px] font-bold text-zinc-500">
                            {item.startStr}
                          </div>

                          <div className="space-y-0.5 flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-bold truncate">{item.title}</span>
                              <span className="text-[9px] px-1 bg-white border border-zinc-200 text-zinc-500 rounded font-mono shrink-0">
                                {item.durationMinutes}m
                              </span>
                            </div>
                            {item.bufferDescription && (
                              <p className="text-[10.5px] text-emerald-800 italic font-mono leading-tight">
                                "{item.bufferDescription}"
                              </p>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="flex justify-between pt-2">
                  <button
                    onClick={() => setStep(2)}
                    className="px-4 py-2 border border-zinc-300 hover:border-black rounded text-xs font-semibold"
                  >
                    Back to Goals
                  </button>

                  <button
                    onClick={handleDeployGuardedPlan}
                    className="px-6 py-2.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-950 text-white rounded text-xs font-bold font-mono uppercase tracking-wider flex items-center gap-1.5 shadow-sm"
                  >
                    <Lock className="w-3.5 h-3.5 text-white" />
                    <span>Lock & Deploy Guarded Day</span>
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Distraction pull back warning demonstration box */}
          <div className="border border-zinc-200 p-4 rounded-lg bg-white space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-red-600 font-mono">
                <ShieldAlert className="w-4 h-4 text-red-600 animate-pulse" />
                <span>Prodolar Guard Dog Simulator</span>
              </div>
              <button
                onClick={triggerDistractionSimulation}
                className="text-[10px] font-mono border border-black px-2 py-0.5 rounded uppercase hover:bg-zinc-100 transition-colors"
                title="Test distraction fallback system voice and prompt"
              >
                Test Drifting
              </button>
            </div>
            
            <AnimatePresence>
              {simulatedDistractionActive ? (
                <motion.div
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  className="p-3 bg-red-50 border border-red-300 text-red-900 text-xs rounded space-y-1.5"
                >
                  <p className="font-bold">⚠️ PROACTIVE DISTRACTION SHIELD INTERCEPTED DRIFTS!</p>
                  <p className="text-[10.5px] italic leading-relaxed">
                    "Social feed session blocked. You have {distractionCountdown} minutes remaining in your morning recovery buffer. Put down the mobile screen immediately."
                  </p>
                  <div className="w-full bg-red-200 h-1.5 rounded overflow-hidden">
                    <motion.div 
                      initial={{ width: "100%" }}
                      animate={{ width: "0%" }}
                      transition={{ duration: 15 }}
                      className="bg-red-600 h-full"
                    />
                  </div>
                </motion.div>
              ) : (
                <p className="text-[11px] text-zinc-500 leading-relaxed font-mono">
                  When locked, Prodolar's mobile background interceptor runs in silent guard mode. If you spend time on social apps during work hours, you are warned and guided back to task.
                </p>
              )}
            </AnimatePresence>
          </div>

        </div>

        {/* Right Column: Simulated Mobile Screen viewport with Pulsing Mic (5 cols) */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center" id="phone-app-container">
          
          {/* HIGH-FIDELITY MOBILE PHONE FRAME */}
          <div className="w-[280px] h-[550px] rounded-[42px] border-[8px] border-zinc-900 bg-white shadow-2xl relative overflow-hidden flex flex-col justify-between shrink-0" id="simulated-smartphone-frame">
            
            {/* Glossy bezel effect */}
            <div className="absolute inset-0 border border-white/20 rounded-[34px] pointer-events-none z-10"></div>
            
            {/* Notch / Dynamic Island */}
            <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-28 h-5 bg-black rounded-full z-20 flex items-center justify-center">
              <span className="w-2.5 h-2.5 rounded-full bg-zinc-900 absolute right-4"></span>
              <span className="text-[8px] font-mono text-zinc-600 tracking-tighter">Prodolar Audio</span>
            </div>

            {/* Smartphone status bar */}
            <div className="p-3.5 pt-4 bg-zinc-50 border-b border-zinc-100 flex items-center justify-between text-[10px] font-mono text-zinc-500 font-bold shrink-0">
              <span className="ml-1">9:41 AM</span>
              <div className="flex items-center gap-1.5">
                <Wifi className="w-3 h-3 text-zinc-500" />
                <span className="text-[8px]">5G</span>
                <Battery className="w-3.5 h-3.5 text-zinc-500 fill-zinc-500" />
              </div>
            </div>

            {/* Smartphone screen contents */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col justify-between bg-zinc-50 relative" id="smartphone-screen">
              
              <div className="text-center space-y-1 mt-2">
                <span className="text-[9px] font-mono uppercase tracking-widest bg-zinc-100 border border-zinc-200 px-1.5 py-0.5 rounded text-zinc-600 font-bold">
                  Morning Applet
                </span>
                <h4 className="text-xs font-bold text-black uppercase tracking-tight">Prodolar Mobile Intercept</h4>
                <p className="text-[9.5px] text-zinc-400">Oral goals capturing engine</p>
              </div>

              {/* Speech transcript readout inside phone */}
              <div className="my-3 flex-1 flex flex-col justify-center items-center">
                <AnimatePresence mode="wait">
                  {isRecording ? (
                    <motion.div 
                      key="phone-recording"
                      initial={{ scale: 0.95, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.95, opacity: 0 }}
                      className="flex flex-col items-center space-y-3"
                    >
                      {/* Interactive visual wave */}
                      <div className="flex items-center gap-1.5 h-12">
                        <motion.div animate={{ height: [10, 32, 10] }} transition={{ repeat: Infinity, duration: 0.8, ease: "easeInOut" }} className="w-1 bg-[#1a73e8] rounded"></motion.div>
                        <motion.div animate={{ height: [14, 40, 14] }} transition={{ repeat: Infinity, duration: 0.6, ease: "easeInOut" }} className="w-1 bg-[#1a73e8] rounded"></motion.div>
                        <motion.div animate={{ height: [18, 48, 18] }} transition={{ repeat: Infinity, duration: 1.0, ease: "easeInOut" }} className="w-1 bg-black rounded"></motion.div>
                        <motion.div animate={{ height: [14, 34, 14] }} transition={{ repeat: Infinity, duration: 0.7, ease: "easeInOut" }} className="w-1 bg-[#1a73e8] rounded"></motion.div>
                        <motion.div animate={{ height: [10, 24, 10] }} transition={{ repeat: Infinity, duration: 0.9, ease: "easeInOut" }} className="w-1 bg-[#1a73e8] rounded"></motion.div>
                      </div>

                      <div className="text-[#1a73e8] font-mono text-[9px] font-bold tracking-widest animate-pulse">
                        LISTENING...
                      </div>
                      
                      {speechTranscript ? (
                        <p className="text-[10px] text-zinc-800 text-center italic max-w-[200px] bg-white p-2 border border-zinc-200 rounded shadow-xs font-medium">
                          "{speechTranscript}"
                        </p>
                      ) : (
                        <p className="text-[9px] text-zinc-400 text-center">Speak a goal clearly, e.g. "Add syllabus review for tomorrow"</p>
                      )}
                    </motion.div>
                  ) : (
                    <motion.div 
                      key="phone-idle"
                      initial={{ scale: 0.95, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.95, opacity: 0 }}
                      className="flex flex-col items-center space-y-3"
                    >
                      {/* Huge elegant microphone orb */}
                      <button
                        onClick={toggleRecording}
                        id="phone-screen-microphone"
                        className="w-20 h-20 rounded-full bg-zinc-900 hover:bg-zinc-800 text-white flex items-center justify-center transition-all shadow-lg border-2 border-zinc-700 active:scale-95 group relative"
                        title="Click to dictate morning achievements"
                      >
                        <Mic className="w-8 h-8 text-white group-hover:scale-105 transition-transform" />
                        <span className="absolute -inset-2 rounded-full border border-dashed border-zinc-300 animate-spin opacity-40 group-hover:opacity-100 duration-1000"></span>
                      </button>

                      <div className="text-[10px] font-mono uppercase text-zinc-500 font-bold">
                        Tap Orb to Dictate
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Smartphone bottom quick objectives lists */}
              <div className="bg-white border border-zinc-200 rounded p-2.5 space-y-1.5 shrink-0 max-h-[140px] overflow-y-auto">
                <span className="text-[8px] font-mono uppercase text-zinc-400 font-extrabold block">Extra Tasks ({extraGoals.length})</span>
                {extraGoals.map(g => (
                  <div key={g.id} className="text-[10px] font-bold text-black border-b border-zinc-100 pb-1 flex items-center justify-between">
                    <span>{g.title}</span>
                    <span className="text-zinc-400 font-mono text-[8px]">{g.estimatedHours}h</span>
                  </div>
                ))}
                {extraGoals.length === 0 && (
                  <span className="text-[9px] text-zinc-400 italic block text-center">No extra items added. Tap the mic to record!</span>
                )}
              </div>

            </div>

            {/* Smartphone software bottom home indicator */}
            <div className="p-2.5 bg-zinc-50 flex justify-center items-center shrink-0">
              <div className="w-24 h-1 bg-zinc-400 rounded-full"></div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
