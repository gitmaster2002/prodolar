import React, { useState, useEffect } from "react";
import { 
  Mail, 
  Calendar as CalendarIcon, 
  ListTodo, 
  CheckCircle, 
  RefreshCw, 
  Bot, 
  ArrowLeftRight, 
  Plus, 
  Check, 
  LogOut,
  AlertTriangle,
  Loader2,
  Lock
} from "lucide-react";
import { signInWithPopup, signOut } from "firebase/auth";
import { auth, googleAuthProvider } from "../lib/firebase.ts";
import { Task, CalendarEvent } from "../types.ts";
import { DataService } from "../lib/dataService.ts";

interface GoogleWorkspaceSyncProps {
  tasks: Task[];
  events: CalendarEvent[];
  accessToken: string | null;
  setAccessToken: (token: string | null) => void;
  triggerToast: (msg: string, type: "info" | "warning" | "success") => void;
  onAddTask: (task: Task) => Promise<void>;
  onAddEvent: (event: CalendarEvent) => Promise<void>;
}

export default function GoogleWorkspaceSync({
  tasks,
  events,
  accessToken,
  setAccessToken,
  triggerToast,
  onAddTask,
  onAddEvent
}: GoogleWorkspaceSyncProps) {
  const [loadingEmails, setLoadingEmails] = useState(false);
  const [emails, setEmails] = useState<any[]>([]);
  const [loadingCalendar, setLoadingCalendar] = useState(false);
  const [googleEvents, setGoogleEvents] = useState<any[]>([]);
  const [loadingTasks, setLoadingTasks] = useState(false);
  const [googleTasksLists, setGoogleTasksLists] = useState<any[]>([]);
  const [googleTasks, setGoogleTasks] = useState<any[]>([]);
  const [selectedListId, setSelectedListId] = useState<string>("");
  const [analyzingEmailId, setAnalyzingEmailId] = useState<string | null>(null);

  // Sign In Flow
  const handleConnect = async () => {
    try {
      const result = await signInWithPopup(auth, googleAuthProvider);
      // Retrieve OAuth Access Token
      const credential = (result as any)._tokenResponse?.oauthAccessToken || 
                         (result as any).credential?.accessToken;
      
      if (credential) {
        setAccessToken(credential);
        triggerToast("Google Workspace connected successfully!", "success");
      } else {
        // Fallback for some firebase flow details
        const token = (result as any).user?.stsTokenManager?.accessToken;
        setAccessToken(token || "mock-valid-oauth-token");
        triggerToast("Connected (Sandbox / Mock Token enabled)!", "info");
      }
    } catch (err: any) {
      console.error("OAuth Connection Error:", err);
      triggerToast(`Connection failed: ${err.message}`, "warning");
    }
  };

  const handleDisconnect = async () => {
    try {
      setAccessToken(null);
      setEmails([]);
      setGoogleEvents([]);
      setGoogleTasks([]);
      setGoogleTasksLists([]);
      triggerToast("Google Workspace disconnected.", "info");
    } catch (err: any) {
      console.error("Disconnect Error:", err);
    }
  };

  // --- GMAIL INTEGRATION ---
  const fetchRecentEmails = async () => {
    if (!accessToken) return;
    setLoadingEmails(true);
    try {
      // 1. Fetch recent unread message IDs
      const listRes = await fetch(
        "https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=5&q=is:unread",
        { headers: { Authorization: `Bearer ${accessToken}` } }
      );
      if (!listRes.ok) throw new Error("Failed to fetch message list");
      const listData = await listRes.json();
      
      if (!listData.messages || listData.messages.length === 0) {
        setEmails([]);
        setLoadingEmails(false);
        return;
      }

      // 2. Fetch full content of each message
      const emailDetailPromises = listData.messages.map(async (m: { id: string }) => {
        const detailRes = await fetch(
          `https://gmail.googleapis.com/gmail/v1/users/me/messages/${m.id}`,
          { headers: { Authorization: `Bearer ${accessToken}` } }
        );
        if (!detailRes.ok) return null;
        const detailData = await detailRes.json();
        
        // Parse headers (Subject, From, Date)
        const headers = detailData.payload?.headers || [];
        const subject = headers.find((h: any) => h.name === "Subject")?.value || "No Subject";
        const from = headers.find((h: any) => h.name === "From")?.value || "Unknown Sender";
        const date = headers.find((h: any) => h.name === "Date")?.value || "";
        
        return {
          id: m.id,
          subject,
          from,
          date,
          snippet: detailData.snippet || "",
          body: detailData.snippet // Simple body snippet representation
        };
      });

      const details = await Promise.all(emailDetailPromises);
      setEmails(details.filter(d => d !== null));
      triggerToast("Fetched latest unread emails!", "success");
    } catch (err) {
      console.error("Gmail Fetch Error:", err);
      triggerToast("Could not access Gmail. Reconnect account.", "warning");
    } finally {
      setLoadingEmails(false);
    }
  };

  // Convert Email to Task with Gemini
  const handleAnalyzeEmail = async (email: any) => {
    setAnalyzingEmailId(email.id);
    try {
      const response = await fetch("/api/agent/analyze-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject: email.subject,
          body: email.snippet,
          sender: email.from
        })
      });

      if (!response.ok) throw new Error("AI analysis failed");
      const analyzedTask = await response.json();

      // Formulate complete task object
      const newTask: Task = {
        id: `task-gmail-${email.id}`,
        title: analyzedTask.title || `Action: ${email.subject}`,
        description: analyzedTask.description || `Parsed from email sent by ${email.from}. \n\nSnippet: ${email.snippet}`,
        deadline: new Date(Date.now() + 86400000).toISOString().split("T")[0], // default tomorrow
        priority: analyzedTask.priority || "medium",
        energy: analyzedTask.energy || "medium",
        status: "pending",
        estimatedHours: analyzedTask.estimatedHours || 1,
        actualHours: 0,
        category: analyzedTask.category || "Emails",
        subtasks: (analyzedTask.subtasks || []).map((st: any, idx: number) => ({
          id: `sub-${email.id}-${idx}`,
          title: st.title || "Review email details",
          status: "pending" as const,
          estimatedMinutes: st.estimatedMinutes || 15
        })),
        successProbability: 85,
        dependencies: [],
        timeBlock: null,
        replannedAt: null,
        historicalReplansCount: 0,
        createdAt: new Date().toISOString()
      };

      await onAddTask(newTask);
      triggerToast(`AI generated task from email: "${newTask.title}"`, "success");
    } catch (err: any) {
      console.error(err);
      triggerToast("Gemini failed to analyze email.", "warning");
    } finally {
      setAnalyzingEmailId(null);
    }
  };

  // --- GOOGLE CALENDAR INTEGRATION ---
  const fetchCalendarEvents = async () => {
    if (!accessToken) return;
    setLoadingCalendar(true);
    try {
      const timeMin = new Date().toISOString();
      const res = await fetch(
        `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${timeMin}&maxResults=10&singleEvents=true&orderBy=startTime`,
        { headers: { Authorization: `Bearer ${accessToken}` } }
      );
      if (!res.ok) throw new Error("Failed to fetch calendar");
      const data = await res.json();
      setGoogleEvents(data.items || []);
      triggerToast("Calendar synced!", "success");
    } catch (err) {
      console.error("Calendar Fetch Error:", err);
      triggerToast("Could not access Google Calendar.", "warning");
    } finally {
      setLoadingCalendar(false);
    }
  };

  const handleImportCalendarEvent = async (gEvent: any) => {
    try {
      const newEvent: CalendarEvent = {
        id: `event-${gEvent.id}`,
        title: gEvent.summary || "Google Calendar Event",
        start: gEvent.start?.dateTime || gEvent.start?.date || new Date().toISOString(),
        end: gEvent.end?.dateTime || gEvent.end?.date || new Date(Date.now() + 3600000).toISOString(),
        category: "work"
      };
      await onAddEvent(newEvent);
      triggerToast(`Imported event: "${newEvent.title}"`, "success");
    } catch (err) {
      triggerToast("Failed to import event.", "warning");
    }
  };

  const handleExportTasksToCalendar = async () => {
    if (!accessToken) return;
    let count = 0;
    try {
      for (const t of tasks) {
        if (t.status !== "completed") {
          const body = {
            summary: `Prodolar: ${t.title}`,
            description: t.description,
            start: { dateTime: new Date(t.deadline).toISOString() },
            end: { dateTime: new Date(new Date(t.deadline).getTime() + (t.estimatedHours || 1) * 3600000).toISOString() }
          };
          const res = await fetch(
            "https://www.googleapis.com/calendar/v3/calendars/primary/events",
            {
              method: "POST",
              headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json"
              },
              body: JSON.stringify(body)
            }
          );
          if (res.ok) count++;
        }
      }
      triggerToast(`Exported ${count} pending tasks to Google Calendar!`, "success");
    } catch (err) {
      triggerToast("Export failed.", "warning");
    }
  };

  // --- GOOGLE TASKS INTEGRATION ---
  const fetchGoogleTasksLists = async () => {
    if (!accessToken) return;
    setLoadingTasks(true);
    try {
      const res = await fetch("https://tasks.googleapis.com/tasks/v1/users/@me/lists", {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      if (!res.ok) throw new Error("Failed to fetch task lists");
      const data = await res.json();
      setGoogleTasksLists(data.items || []);
      if (data.items?.length > 0) {
        setSelectedListId(data.items[0].id);
      }
    } catch (err) {
      console.error(err);
      triggerToast("Could not fetch Google Tasks.", "warning");
    } finally {
      setLoadingTasks(false);
    }
  };

  const fetchTasksFromList = async (listId: string) => {
    if (!accessToken || !listId) return;
    setLoadingTasks(true);
    try {
      const res = await fetch(`https://tasks.googleapis.com/tasks/v1/lists/${listId}/tasks`, {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      if (!res.ok) throw new Error("Failed to fetch tasks");
      const data = await res.json();
      setGoogleTasks(data.items || []);
      triggerToast("Google Tasks downloaded!", "success");
    } catch (err) {
      triggerToast("Failed to fetch tasks.", "warning");
    } finally {
      setLoadingTasks(false);
    }
  };

  useEffect(() => {
    if (selectedListId) {
      fetchTasksFromList(selectedListId);
    }
  }, [selectedListId]);

  const handleImportGoogleTask = async (gTask: any) => {
    try {
      const newTask: Task = {
        id: `task-gtasks-${gTask.id}`,
        title: gTask.title,
        description: gTask.notes || "Imported from Google Tasks.",
        deadline: gTask.due ? gTask.due.split("T")[0] : new Date().toISOString().split("T")[0],
        priority: "medium",
        energy: "medium",
        status: gTask.status === "completed" ? "completed" : "pending",
        estimatedHours: 1,
        actualHours: 0,
        category: "Deep Work",
        subtasks: [],
        successProbability: 90,
        dependencies: [],
        timeBlock: null,
        replannedAt: null,
        historicalReplansCount: 0,
        createdAt: new Date().toISOString()
      };
      await onAddTask(newTask);
      triggerToast(`Imported task: "${newTask.title}"`, "success");
    } catch (err) {
      triggerToast("Failed to import task.", "warning");
    }
  };

  const handleExportTasksToGoogleTasks = async () => {
    if (!accessToken || !selectedListId) {
      triggerToast("Select a Google Task list first.", "warning");
      return;
    }
    let count = 0;
    try {
      for (const t of tasks) {
        if (t.status !== "completed") {
          const body = {
            title: t.title,
            notes: t.description || "",
            due: new Date(t.deadline).toISOString()
          };
          const res = await fetch(
            `https://tasks.googleapis.com/tasks/v1/lists/${selectedListId}/tasks`,
            {
              method: "POST",
              headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json"
              },
              body: JSON.stringify(body)
            }
          );
          if (res.ok) count++;
        }
      }
      triggerToast(`Exported ${count} tasks to Google Tasks!`, "success");
      fetchTasksFromList(selectedListId);
    } catch (err) {
      triggerToast("Export failed.", "warning");
    }
  };

  // Auto load lists on token change
  useEffect(() => {
    if (accessToken) {
      fetchRecentEmails();
      fetchCalendarEvents();
      fetchGoogleTasksLists();
    }
  }, [accessToken]);

  return (
    <div id="workspace_sync_container" className="space-y-6 max-w-5xl mx-auto p-4">
      {/* 1. Sync Hero / Control Header */}
      <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-white flex items-center gap-2">
            <ArrowLeftRight className="w-5 h-5 text-indigo-400" />
            Google Workspace Integration Hub
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Bridge your Prodolar day plan with real Gmail, Google Calendar events, and Tasks.
          </p>
        </div>

        {accessToken ? (
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/20 text-xs font-medium text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Connected
            </span>
            <button
              onClick={handleDisconnect}
              className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-medium flex items-center gap-1.5 transition-all"
            >
              <LogOut className="w-3.5 h-3.5" />
              Disconnect
            </button>
          </div>
        ) : (
          <button
            onClick={handleConnect}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-medium text-sm shadow-md hover:shadow-indigo-500/10 flex items-center gap-2 transition-all active:scale-95"
          >
            <Lock className="w-4 h-4" />
            Connect Google Workspace
          </button>
        )}
      </div>

      {!accessToken ? (
        <div className="bg-slate-950/40 border border-dashed border-slate-800 rounded-2xl p-12 text-center max-w-xl mx-auto mt-6">
          <div className="w-12 h-12 rounded-full bg-indigo-500/15 flex items-center justify-center mx-auto mb-4">
            <Lock className="w-6 h-6 text-indigo-400" />
          </div>
          <h3 className="text-base font-medium text-slate-200">Authorization Required</h3>
          <p className="text-sm text-slate-400 mt-2">
            To view emails, load calendars, or sync your checklist, securely authorize Prodolar using your Google account popup.
          </p>
          <button
            onClick={handleConnect}
            className="mt-6 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium transition-all"
          >
            Authorize Workspace
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* A. GMAIL & AI PARSING */}
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 flex flex-col">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-red-500/15 text-red-400">
                  <Mail className="w-4 h-4" />
                </div>
                <h3 className="font-semibold text-slate-100 text-sm">Gmail Inbox</h3>
              </div>
              <button
                onClick={fetchRecentEmails}
                disabled={loadingEmails}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 transition-all"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingEmails ? "animate-spin text-indigo-400" : ""}`} />
              </button>
            </div>

            <div className="flex-1 space-y-3 overflow-y-auto max-h-[360px] pr-1">
              {loadingEmails ? (
                <div className="flex flex-col items-center justify-center py-12 text-slate-500 text-xs gap-2">
                  <Loader2 className="w-5 h-5 animate-spin text-slate-400" />
                  Fetching unread emails...
                </div>
              ) : emails.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-slate-500 text-xs">
                  Inbox clear! No unread emails.
                </div>
              ) : (
                emails.map((email) => (
                  <div key={email.id} className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-3.5 space-y-2 hover:border-indigo-500/30 transition-all">
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-[11px] font-medium text-indigo-400 truncate max-w-[120px]">
                        {email.from.split("<")[0].trim()}
                      </span>
                      <span className="text-[9px] text-slate-500">{new Date(email.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                    </div>
                    <h4 className="text-xs font-semibold text-slate-200 line-clamp-1">{email.subject}</h4>
                    <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">{email.snippet}</p>
                    <div className="pt-2 flex justify-end">
                      <button
                        onClick={() => handleAnalyzeEmail(email)}
                        disabled={analyzingEmailId === email.id}
                        className="px-2 py-1 rounded-md bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/20 text-indigo-400 hover:text-indigo-300 text-[10px] font-medium flex items-center gap-1 transition-all"
                      >
                        {analyzingEmailId === email.id ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <Bot className="w-3 h-3" />
                        )}
                        AI Analyze & Parse
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* B. GOOGLE CALENDAR */}
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 flex flex-col">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-emerald-500/15 text-emerald-400">
                  <CalendarIcon className="w-4 h-4" />
                </div>
                <h3 className="font-semibold text-slate-100 text-sm">Google Calendar</h3>
              </div>
              <button
                onClick={fetchCalendarEvents}
                disabled={loadingCalendar}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 transition-all"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingCalendar ? "animate-spin text-indigo-400" : ""}`} />
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleExportTasksToCalendar}
                className="w-full py-1.5 text-center text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 text-[11px] font-medium rounded-lg border border-slate-700 transition-all"
              >
                Export Tasks to Calendar
              </button>
            </div>

            <div className="flex-1 space-y-3 overflow-y-auto max-h-[300px] pr-1">
              {loadingCalendar ? (
                <div className="flex flex-col items-center justify-center py-12 text-slate-500 text-xs gap-2">
                  <Loader2 className="w-5 h-5 animate-spin text-slate-400" />
                  Syncing events...
                </div>
              ) : googleEvents.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-slate-500 text-xs">
                  No upcoming calendar events.
                </div>
              ) : (
                googleEvents.map((ev) => {
                  const startTime = ev.start?.dateTime || ev.start?.date || "";
                  const eventDate = startTime ? new Date(startTime).toLocaleDateString() : "";
                  const eventTime = startTime ? new Date(startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : "All Day";
                  const isImported = events.some(e => e.id === `event-${ev.id}`);
                  
                  return (
                    <div key={ev.id} className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-3 flex items-start justify-between gap-2 hover:border-emerald-500/20 transition-all">
                      <div className="space-y-1">
                        <h4 className="text-xs font-semibold text-slate-200 line-clamp-1">{ev.summary}</h4>
                        <div className="text-[10px] text-slate-400 flex items-center gap-1.5">
                          <span>{eventDate}</span>
                          <span>•</span>
                          <span>{eventTime}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => handleImportCalendarEvent(ev)}
                        disabled={isImported}
                        className={`p-1 rounded-md transition-all ${
                          isImported 
                            ? "bg-emerald-500/10 text-emerald-400" 
                            : "bg-slate-850 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700"
                        }`}
                      >
                        {isImported ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* C. GOOGLE TASKS */}
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 flex flex-col">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-indigo-500/15 text-indigo-400">
                  <ListTodo className="w-4 h-4" />
                </div>
                <h3 className="font-semibold text-slate-100 text-sm">Google Tasks</h3>
              </div>
              <button
                onClick={fetchGoogleTasksLists}
                disabled={loadingTasks}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 transition-all"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingTasks ? "animate-spin text-indigo-400" : ""}`} />
              </button>
            </div>

            {googleTasksLists.length > 0 && (
              <div className="space-y-1">
                <label className="text-[10px] text-slate-400">Select Task List</label>
                <select
                  value={selectedListId}
                  onChange={(e) => setSelectedListId(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  {googleTasksLists.map(l => (
                    <option key={l.id} value={l.id}>{l.title}</option>
                  ))}
                </select>
              </div>
            )}

            <div className="flex items-center gap-2">
              <button
                onClick={handleExportTasksToGoogleTasks}
                className="w-full py-1.5 text-center text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 text-[11px] font-medium rounded-lg border border-slate-700 transition-all"
              >
                Export Tasks to Google Tasks
              </button>
            </div>

            <div className="flex-1 space-y-3 overflow-y-auto max-h-[250px] pr-1">
              {loadingTasks ? (
                <div className="flex flex-col items-center justify-center py-12 text-slate-500 text-xs gap-2">
                  <Loader2 className="w-5 h-5 animate-spin text-slate-400" />
                  Loading tasks...
                </div>
              ) : googleTasks.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-slate-500 text-xs">
                  No tasks found in list.
                </div>
              ) : (
                googleTasks.map((gt) => {
                  const isImported = tasks.some(t => t.id === `task-gtasks-${gt.id}`);
                  return (
                    <div key={gt.id} className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-3 flex items-start justify-between gap-2 hover:border-indigo-500/20 transition-all">
                      <div className="space-y-1">
                        <h4 className="text-xs font-semibold text-slate-200 line-clamp-1">{gt.title}</h4>
                        {gt.notes && (
                          <p className="text-[10px] text-slate-400 line-clamp-1">{gt.notes}</p>
                        )}
                      </div>
                      <button
                        onClick={() => handleImportGoogleTask(gt)}
                        disabled={isImported}
                        className={`p-1 rounded-md transition-all ${
                          isImported 
                            ? "bg-indigo-500/10 text-indigo-400" 
                            : "bg-slate-850 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700"
                        }`}
                      >
                        {isImported ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
